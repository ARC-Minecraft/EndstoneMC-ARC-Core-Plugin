# -*- coding: utf-8 -*-
"""成就进度统计：player_achievement_stats 表读写，仅供 arc_core 内部与 api_* 对外暴露。"""
from typing import Any, Dict, List, Set


class AchievementStatsSystem:
    """玩家成就击杀/完成进度（SQLite），不对外暴露 DatabaseManager。"""

    TABLE_STATS = "player_achievement_stats"
    TABLE_CONDITION = "achievement_conditions"
    TABLE_LEGACY_DEF = "achievement_definitions"
    TABLE_TITLE_UNLOCK = "player_title_unlock_time"
    ACH_UNLOCK_PREFIX = "ach_unlock:"

    def __init__(self, database_manager):
        self.database_manager = database_manager

    @staticmethod
    def _safe_int(value: Any, default_value: int = 0) -> int:
        try:
            return int(value)
        except Exception:
            return default_value

    @classmethod
    def achievement_unlock_stat_key(cls, unlock_title: str) -> str:
        return cls.ACH_UNLOCK_PREFIX + str(unlock_title or "").strip()

    def ensure_tables(self) -> bool:
        """创建成就统计表及旧版迁移用表（achievement_conditions / achievement_definitions）。"""
        try:
            self.database_manager.execute(
                "CREATE TABLE IF NOT EXISTS player_achievement_stats ("
                "xuid TEXT NOT NULL, "
                "stat_key TEXT NOT NULL, "
                "count INTEGER NOT NULL DEFAULT 0, "
                "PRIMARY KEY (xuid, stat_key)"
                ")"
            )
            self.database_manager.execute(
                "CREATE TABLE IF NOT EXISTS achievement_conditions ("
                "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "unlock_title TEXT NOT NULL, "
                "condition_type TEXT NOT NULL, "
                "target_id TEXT NOT NULL, "
                "required_count INTEGER NOT NULL"
                ")"
            )
            return True
        except Exception:
            return False

    def get_stat_count(self, xuid: str, stat_key: str) -> int:
        xs = str(xuid or "").strip()
        key = str(stat_key or "").strip()
        if not xs or not key:
            return 0
        row = self.database_manager.query_one(
            "SELECT count FROM player_achievement_stats WHERE xuid = ? AND stat_key = ?",
            (xs, key),
        )
        if not row:
            return 0
        return self._safe_int(row.get("count", 0), 0)

    def inc_stat(self, xuid: str, stat_key: str, delta: int = 1) -> int:
        xs = str(xuid or "").strip()
        key = str(stat_key or "").strip()
        delta = self._safe_int(delta, 1)
        if not xs or not key or delta <= 0:
            return self.get_stat_count(xs, key)
        self.database_manager.execute(
            "INSERT OR IGNORE INTO player_achievement_stats (xuid, stat_key, count) VALUES (?, ?, 0)",
            (xs, key),
        )
        self.database_manager.execute(
            "UPDATE player_achievement_stats SET count = count + ? WHERE xuid = ? AND stat_key = ?",
            (delta, xs, key),
        )
        return self.get_stat_count(xs, key)

    def has_achievement_unlock_stat(self, xuid: str, unlock_title: str) -> bool:
        xs = str(xuid or "").strip()
        ut = str(unlock_title or "").strip()
        if not xs or not ut:
            return False
        return self.get_stat_count(xs, self.achievement_unlock_stat_key(ut)) >= 1

    def ensure_achievement_unlock_stat_silent(self, xuid: str, unlock_title: str) -> None:
        xs = str(xuid or "").strip()
        ut = str(unlock_title or "").strip()
        if not xs or not ut:
            return
        key = self.achievement_unlock_stat_key(ut)
        self.database_manager.execute(
            "INSERT OR IGNORE INTO player_achievement_stats (xuid, stat_key, count) VALUES (?, ?, 1)",
            (xs, key),
        )
        self.database_manager.execute(
            "UPDATE player_achievement_stats SET count = 1 WHERE xuid = ? AND stat_key = ? AND count < 1",
            (xs, key),
        )

    def mark_achievement_unlock_stat(self, xuid: str, unlock_title: str) -> bool:
        """写入成就完成标记。返回 True 表示本次为新写入。"""
        before = self.has_achievement_unlock_stat(xuid, unlock_title)
        self.ensure_achievement_unlock_stat_silent(xuid, unlock_title)
        return not before

    def list_backfill_xuids(self) -> List[str]:
        """出现过成就统计或头衔解锁记录的玩家 xuid（用于迁移补全 ach_unlock）。"""
        out: Set[str] = set()
        try:
            for row in self.database_manager.query_all(
                "SELECT DISTINCT xuid FROM player_achievement_stats",
                (),
            ):
                x = str(row.get("xuid") or "").strip()
                if x:
                    out.add(x)
        except Exception:
            pass
        try:
            for row in self.database_manager.query_all(
                "SELECT DISTINCT xuid FROM player_title_unlock_time",
                (),
            ):
                x = str(row.get("xuid") or "").strip()
                if x:
                    out.add(x)
        except Exception:
            pass
        return sorted(out)

    def rename_achievement_unlock_stat_key(self, old_unlock_title: str, new_unlock_title: str) -> bool:
        old_k = self.achievement_unlock_stat_key(old_unlock_title)
        new_k = self.achievement_unlock_stat_key(new_unlock_title)
        if not old_k or not new_k or old_k == new_k:
            return True
        try:
            return bool(
                self.database_manager.execute(
                    "UPDATE player_achievement_stats SET stat_key = ? WHERE stat_key = ?",
                    (new_k, old_k),
                )
            )
        except Exception:
            return False

    def delete_achievement_unlock_stat(self, unlock_title: str) -> bool:
        ut = str(unlock_title or "").strip()
        if not ut:
            return False
        try:
            return bool(
                self.database_manager.execute(
                    "DELETE FROM player_achievement_stats WHERE stat_key = ?",
                    (self.achievement_unlock_stat_key(ut),),
                )
            )
        except Exception:
            return False

    def list_legacy_achievement_definitions(self) -> List[Dict[str, Any]]:
        try:
            rows = self.database_manager.query_all(
                "SELECT name, stat_key, required_count, unlock_title, enabled "
                "FROM achievement_definitions",
                (),
            )
            return list(rows or [])
        except Exception:
            return []

    def list_legacy_achievement_conditions(self) -> List[Dict[str, Any]]:
        try:
            rows = self.database_manager.query_all(
                "SELECT id, unlock_title, condition_type, target_id, required_count "
                "FROM achievement_conditions ORDER BY id ASC",
                (),
            )
            return list(rows or [])
        except Exception:
            return []
