import hashlib
import json
import math
import random
import re
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from endstone import ColorFormat, Player, GameMode
from endstone.form import ActionForm, TextInput, ModalForm, Label
from endstone.command import Command, CommandSender
from endstone.event import event_handler, PlayerJoinEvent, PlayerQuitEvent, PlayerRespawnEvent, BlockBreakEvent, BlockPlaceEvent, PlayerDeathEvent, PlayerInteractEvent, ActorExplodeEvent, PlayerInteractActorEvent, ActorDamageEvent, ActorDeathEvent, PlayerChatEvent 
from endstone.plugin import Plugin

from endstone_arc_core.DatabaseManager import DatabaseManager
from endstone_arc_core.Economy import Economy
from endstone_arc_core.LanguageManager import LanguageManager
from endstone_arc_core.SettingManager import SettingManager
from endstone_arc_core.TeleportSystem import TeleportSystem, generate_tp_command_to_position
from endstone_arc_core.LandSystem import LandSystem
from endstone_arc_core.TitleSystem import TitleSystem
from endstone_arc_core.AchievementSystem import AchievementSystem
from endstone_arc_core.GuildSystem import GuildSystem, ROLE_OWNER, ROLE_MANAGER, ROLE_MEMBER
from endstone_arc_core.EntityDisplayNameManager import EntityDisplayNameManager
from endstone_arc_core.KillRewardConfig import KillRewardConfig, normalize_entity_type_id
from endstone_arc_core.arc_error_log import append_arc_error_log, format_context_lines

MAIN_PATH = 'plugins/ARCCore'
# 领地无权限操作日志目录（按日期分文件），位于弧光核心数据目录下
LAND_INTERACT_LOG_DIR_NAME = 'land_inteteact_log'


class ARCCorePlugin(Plugin):
    api_version = "0.10"
    # 交互圈地：同一次点击 EndStone 可能连发多次 PlayerInteractEvent；上次成功记录选点后的最短间隔（秒），用于防抖
    _land_creation_pick_debounce_sec = 0.12

    commands = {
        "updatespawnpos": {
            "description": "Update spawn position of current dimension.",
            "usages": ["/updatespawnpos"],
            "permissions": ["arc_core.command.op"],
        },
        "arc": {
            "description": "ARC menu; subcommands: op, land, tp, bank, guild.",
            "usages": ["/arc", "/arc op", "/arc land", "/arc tp", "/arc bank", "/arc guild"],
            "permissions": ["arc_core.command.common"],
        },
        "suicide":
            {
            "description": "Kill yourself.",
            "usages": ["/suicide"],
            "permissions": ["arc_core.command.common"],
        },
        "spawn":
        {
            "description": "Teleport to spawn position.",
            "usages": ["/spawn"],
            "permissions": ["arc_core.command.common"],
        },
        "landpos1": {
            "description": "Set new land corner 1.",
            "usages": ["/landpos1"],
            "permissions": ["arc_core.command.common"],
        },
        "landpos2": {
            "description": "Set new land corner 2.",
            "usages": ["/landpos2"],
            "permissions": ["arc_core.command.common"],
        },
        "landbuy": {
            "description": "Buy the pending new land (alias of /land buy).",
            "usages": ["/landbuy"],
            "permissions": ["arc_core.command.common"],
        },
        "land": {
            "description": "Land helpers: pos1, pos2, buy.",
            "usages": ["/land pos1", "/land pos2", "/land buy"],
            "permissions": ["arc_core.command.common"],
        },
        "pos1": {
            "description": "OP only: record current position as coordinate 1.",
            "usages": ["/pos1"],
            "permissions": ["arc_core.command.op"],
        },
        "pos2": {
            "description": "OP only: record current position as coordinate 2 and open OP panel.",
            "usages": ["/pos2"],
            "permissions": ["arc_core.command.op"],
        },
        "connecttoserver": {
            "description": "Cross-server: no args opens picker; else transfer by server name.",
            "usages": ["/connecttoserver", "/connecttoserver <server_name: str>"],
            "permissions": ["arc_core.command.common"],
        }
    }
    permissions = {
        "arc_core.command.common": {
            "description": "Commands for all players (arc, suicide, spawn, land*, landpos*, connecttoserver, /arc guild).",
            "default": True,
        },
        "arc_core.command.op": {
            "description": "OP only: updatespawnpos, pos1, pos2; /arc op still checks is_op in handler.",
            "default": "op",
        },
    }

    def __init__(self):
        # 在__init__中不能使用self.logger打印，因为self.logger还没有初始化
        super().__init__()
        self.setting_manager = SettingManager()
        default_language_dode = self.setting_manager.GetSetting('DEFAULT_LANGUAGE_CODE')
        self.language_manager = LanguageManager(default_language_dode if default_language_dode is not None else 'ZH-CN')
        self.database_manager = DatabaseManager(Path(MAIN_PATH) / self.setting_manager.GetSetting('DATABASE_PATH'))

        # 跨服共享数据库路由：配置非空时，对应表的读写自动路由到指定数据库
        player_db_path = self.setting_manager.GetSetting('PLAYER_DATABASE_PATH')
        economy_db_path = self.setting_manager.GetSetting('PLAYER_ECONOMY_DATABASE_PATH')
        title_db_path = self.setting_manager.GetSetting('PLAYER_TITLE_DATABASE_PATH')
        if player_db_path:
            self.database_manager.add_route('player_basic_info', player_db_path)
        if economy_db_path:
            self.database_manager.add_route('player_economy', economy_db_path)
        if title_db_path:
            for t in ('title_definitions', 'player_title_unlock_time', 'player_title_equipped'):
                self.database_manager.add_route(t, title_db_path)

        guild_db_path = self.setting_manager.GetSetting('GUILD_DATABASE_PATH')
        if guild_db_path:
            for t in ('guilds', 'guild_members', 'guild_invites'):
                self.database_manager.add_route(t, guild_db_path)

        self.economy = Economy(self.database_manager, self.setting_manager)
        self.teleport_system = TeleportSystem(self.database_manager, self.setting_manager)
        self.land_system = LandSystem(self.database_manager, self.setting_manager)
        self.title_system = TitleSystem(self.database_manager, self.setting_manager)
        self.achievement_system = AchievementSystem(
            self.database_manager,
            self.title_system,
            self.language_manager,
            self.api_unlock_title,
            MAIN_PATH,
            self._announce_achievement_unlock,
        )
        self.entity_display_name_manager = EntityDisplayNameManager(Path(MAIN_PATH), logger=None)
        self.kill_reward_config = KillRewardConfig(Path(MAIN_PATH), logger=None)
        self.guild_system = GuildSystem(
            self.database_manager, self.setting_manager, self.economy
        )
        self.init_database()
        self._arc_error_log_path = str(Path(MAIN_PATH) / "error_log.txt")

        # 首富头衔：缓存当前首富 xuid，避免每次都重复发放
        self.current_richest_xuid = None

        self.if_protect_spawn = self.setting_manager.GetSetting('IF_PROTECT_SPAWN')
        if self.if_protect_spawn is None:
            self.if_protect_spawn = False
        self.spawn_pos_dict = self.get_all_spawn_locations()
        self.spawn_protect_range = self.setting_manager.GetSetting('SPAWN_PROTECT_RANGE')
        self.spawn_protect_range = self.setting_manager.GetSetting('SPAWN_PROTECT_RANGE')
        if self.spawn_protect_range is None:
            self.spawn_protect_range = 8
        else:
            try:
                self.spawn_protect_range = int(self.spawn_protect_range)
            except ValueError:
                self.spawn_protect_range = 8

        # 玩家认证
        self.player_authentication_state = {}

        # 玩家圈地
        self.land_min_distance = self.setting_manager.GetSetting('MIN_LAND_DISTANCE')
        try:
            self.land_min_distance = int(self.land_min_distance)
        except (ValueError, TypeError):
            self.land_min_distance = 0
        self.land_price = self.setting_manager.GetSetting('LAND_PRICE')
        try:
            self.land_price = int(self.land_price)
        except (ValueError, TypeError):
            self.land_price = 100
        self.land_sell_refund_coefficient = self.setting_manager.GetSetting('LAND_SELL_REFUND_COEFFICIENT')
        try:
            self.land_sell_refund_coefficient = float(self.land_sell_refund_coefficient)
        except (ValueError, TypeError):
            self.land_sell_refund_coefficient = 0.9
        self.land_min_size = self.setting_manager.GetSetting('LAND_MIN_SIZE')
        try:
            self.land_min_size = int(self.land_min_size)
        except (ValueError, TypeError):
            self.land_min_size = 5  # 默认最小尺寸为5
        self._land_only_place_block_ids = frozenset()
        self._disabled_block_ids = frozenset()
        self._refresh_disabled_blocks()
        self._refresh_land_only_place_blocks()
        self.player_new_land_creation_info = {}  # {name: {'dimension': str, 'min_x': int, 'max_x': int, 'min_y': int, 'max_y': int, 'min_z': int, 'max_z': int}}
        self.player_land_pos1 = {}  # {name: {'dimension': str, 'x': int, 'y': int, 'z': int}} 暂存/landpos1
        # 交互式圈地：rect_a → rect_b → y_min → y_max，值为 dict(step=..., dimension=..., ...)
        self.player_land_creation_pick: Dict[str, Dict[str, Any]] = {}
        # 上次成功写入一次选点的时间，用于防抖（与 player_land_creation_pick 同步清理）
        self.player_land_pick_last_event_ts: Dict[str, float] = {}

        # OP坐标记录与上次执行指令（空输入时重复执行）
        self.op_coordinate1_dict = {}
        self.op_coordinate2_dict = {}
        self.op_last_command_dict = {}

        # OP 调试模式（开启后触发方块/生物相关事件时向该 OP 发送调试信息）
        self.op_debug_mode = set()

        # 玩家出入领地
        self.player_in_land_id_dict = {}
        
        # 多线程位置检测相关
        self.position_thread = None
        self.position_thread_running = False
        self.position_thread_lock = threading.Lock()
        self._land_interact_log_lock = threading.Lock()
        self.position_check_interval = 0.5  # 每0.5秒检查一次，比原来的1.25秒更快


        # 公告系统
        self.broadcast_messages = []  # 存储公告消息列表
        self.current_broadcast_index = 0  # 当前公告索引
        self.broadcast_interval = self.setting_manager.GetSetting('BROADCAST_INTERVAL')
        try:
            self.broadcast_interval = int(self.broadcast_interval)
        except (ValueError, TypeError):
            self.broadcast_interval = 300  # 默认5分钟（300秒）
        self.small_horn_price_per_hour = self.setting_manager.GetSetting('SMALL_HORN_PRICE_PER_HOUR')
        try:
            self.small_horn_price_per_hour = int(self.small_horn_price_per_hour)
            if self.small_horn_price_per_hour < 0:
                self.small_horn_price_per_hour = 60
        except (ValueError, TypeError):
            self.small_horn_price_per_hour = 60

        # 新人欢迎系统
        self.newbie_welcome_file = Path(MAIN_PATH) / "newbie_welcome.txt"
        self.newbie_commands_file = Path(MAIN_PATH) / "newbie_commands.txt"
        self._ensure_newbie_files_exist()

        # 金钱排行榜设置
        self.hide_op_in_money_ranking = self.setting_manager.GetSetting('HIDE_OP_IN_MONEY_RANKING')
        if self.hide_op_in_money_ranking is None:
            self.hide_op_in_money_ranking = True
        else:
            try:
                self.hide_op_in_money_ranking = self.hide_op_in_money_ranking.lower() in ['true', '1', 'yes']
            except (ValueError, AttributeError):
                self.hide_op_in_money_ranking = True

        # 强制登录
        self.force_login = self.setting_manager.GetSetting('FORCE_LOGIN')
        if self.force_login is None:
            self.force_login = False
        else:
            try:
                self.force_login = str(self.force_login).lower() in ['true', '1', 'yes']
            except (ValueError, AttributeError):
                self.force_login = False

        # 清道夫系统变量初始化
        self.enable_cleaner = False
        self.cleaner_interval = 600

    def on_load(self) -> None:
        self.logger.info(f"{ColorFormat.YELLOW}[ARC Core]Plugin loaded!")

    def _safe_log(self, level: str, message: str):
        """
        安全的日志记录方法，在logger未初始化时使用print
        :param level: 日志级别 (info, warning, error)
        :param message: 日志消息
        """
        if hasattr(self, 'logger') and self.logger is not None:
            if level.lower() == 'info':
                self.logger.info(message)
            elif level.lower() == 'warning':
                self.logger.warning(message)
            elif level.lower() == 'error':
                self.logger.error(message)
            else:
                self.logger.info(message)
        else:
            # 如果logger未初始化，使用print
            print(f"[{level.upper()}] {message}")

    def _ensure_newbie_files_exist(self):
        """确保新人欢迎相关文件存在"""
        try:
            # 确保目录存在
            Path(MAIN_PATH).mkdir(exist_ok=True)
            
            # 创建新人欢迎消息文件
            if not self.newbie_welcome_file.exists():
                default_welcome = "欢迎来到我们的服务器！\n希望你在这里玩得愉快！\n如有疑问请联系管理员。"
                self.newbie_welcome_file.write_text(default_welcome, encoding='utf-8')
                # 在__init__期间不能使用self.logger，使用print代替
                print(f"[ARC Core]Created default newbie welcome file: {self.newbie_welcome_file}")
            
            # 创建新人指令文件
            if not self.newbie_commands_file.exists():
                default_commands = "# 新人指令文件\n# 每行一个指令，{player} 会被替换为玩家名称\n# 示例：\n# gamemode 0 {player}\n# give {player} minecraft:bread 16\n# clear {player}"
                self.newbie_commands_file.write_text(default_commands, encoding='utf-8')
                # 在__init__期间不能使用self.logger，使用print代替
                print(f"[ARC Core]Created default newbie commands file: {self.newbie_commands_file}")
                
        except Exception as e:
            # 在__init__期间不能使用self.logger，使用print代替
            print(f"[ARC Core]Failed to create newbie files: {str(e)}")

    def _send_newbie_welcome_message(self, player: Player):
        """发送新人欢迎消息"""
        try:
            if self.newbie_welcome_file.exists():
                welcome_content = self.newbie_welcome_file.read_text(encoding='utf-8').strip()
                if welcome_content:
                    # 将换行符分割成多条消息
                    messages = welcome_content.split('\n')
                    for message in messages:
                        if message.strip():  # 跳过空行
                            player.send_message(f"§e[欢迎] §f{message.strip()}")
                    self.logger.info(f"[ARC Core]Sent welcome message to new player: {player.name}")
                else:
                    self.logger.warning(f"[ARC Core]Welcome file is empty: {self.newbie_welcome_file}")
            else:
                self.logger.warning(f"[ARC Core]Welcome file not found: {self.newbie_welcome_file}")
        except Exception as e:
            self.logger.error(f"[ARC Core]Failed to send welcome message to {player.name}: {str(e)}")

    def _execute_newbie_commands(self, player: Player):
        """执行新人指令"""
        try:
            if self.newbie_commands_file.exists():
                commands_content = self.newbie_commands_file.read_text(encoding='utf-8').strip()
                if commands_content:
                    lines = commands_content.split('\n')
                    executed_count = 0
                    for line in lines:
                        line = line.strip()
                        # 跳过空行和注释行
                        if line and not line.startswith('#'):
                            # 替换玩家名称占位符
                            command = line.replace('{player}', player.name)
                            # 执行指令
                            try:
                                self.server.dispatch_command(self.server.command_sender, command)
                                executed_count += 1
                                self.logger.info(f"[ARC Core]Executed newbie command for {player.name}: {command}")
                            except Exception as cmd_e:
                                self.logger.error(f"[ARC Core]Failed to execute command '{command}' for {player.name}: {str(cmd_e)}")
                    
                    if executed_count > 0:
                        self.logger.info(f"[ARC Core]Executed {executed_count} newbie commands for {player.name}")
                else:
                    self.logger.warning(f"[ARC Core]Commands file is empty: {self.newbie_commands_file}")
            else:
                self.logger.warning(f"[ARC Core]Commands file not found: {self.newbie_commands_file}")
        except Exception as e:
            self.logger.error(f"[ARC Core]Failed to execute newbie commands for {player.name}: {str(e)}")

    def on_enable(self) -> None:
        self.register_events(self)
        self.logger.info(f"{ColorFormat.YELLOW}[ARC Core]Plugin enabled!")
        self.economy.set_logger(self.logger)

        def _on_arc_persistent_error(error_code: str, detail: str, exc):
            self._arc_persistent_error(error_code, detail, exc)

        self.economy.set_persistent_error_callback(_on_arc_persistent_error)
        self.land_system.set_persistent_error_callback(_on_arc_persistent_error)
        self.teleport_system.set_server(self.server)
        self.teleport_system.set_logger(self.logger)
        self.land_system.set_logger(self.logger)
        self.land_system.reload_config()
        self.entity_display_name_manager.logger = self.logger
        self.kill_reward_config.logger = self.logger

        # 初始化公告系统和清道夫系统
        self._load_broadcast_messages()
        self._init_cleaner_system()

        # 启动多线程位置检测系统
        self.start_position_thread()

        # Scheduler tasks
        # 移除了原有的 player_position_listener，现在使用多线程方式
        self.server.scheduler.run_task(self, self.teleport_system.cleanup_expired_requests, delay=0, period=100)  # 每5秒清理一次过期请求
        
        # 公告系统定时任务
        if self.broadcast_messages:
            broadcast_period = self.broadcast_interval * 20  # 转换为ticks (1秒 = 20 ticks)
            self.server.scheduler.run_task(self, self.send_broadcast_message, delay=broadcast_period, period=broadcast_period)
            self.logger.info(f"[ARC Core]Broadcast system started, interval: {self.broadcast_interval} seconds")
        small_horn_period = 10 * 60 * 20  # 每10分钟
        self.server.scheduler.run_task(self, self.send_small_horn_messages, delay=small_horn_period, period=small_horn_period)
        self.logger.info("[ARC Core]Small horn system started, interval: 600 seconds")

        # 清道夫系统定时任务
        if self.enable_cleaner:
            cleaner_period = self.cleaner_interval * 20  # 转换为ticks
            self.server.scheduler.run_task(self, self.start_cleaner_warning, delay=cleaner_period, period=cleaner_period)
            self.logger.info(f"[ARC Core]Cleaner system started, interval: {self.cleaner_interval} seconds")
        
        # 别踩白块接入
        self.dtwt_plugin = self.server.plugin_manager.get_plugin('arc_dtwt')
        print('[ARC Core]DTWT plugin loaded:', self.dtwt_plugin is not None)

        # 首富头衔：启动时加载缓存并与财富榜核对（xuid 未变则不撤销，避免清掉已佩戴的首富头衔）
        try:
            self._ensure_richest_title_definition()
            self._load_current_richest_xuid_from_db()
            self._update_richest_title_if_needed()
        except Exception:
            pass

    def on_disable(self) -> None:
        # 停止位置检测线程
        self.stop_position_thread()
        self.logger.info(f"{ColorFormat.YELLOW}[ARC Core]Plugin disabled!")

    def _arc_persistent_error(
        self,
        error_code: str,
        detail: str,
        exception=None,
        extra_context: Optional[Dict[str, Any]] = None,
    ) -> None:
        """写入 error_log.txt 并打 logger（不向玩家发消息）。"""
        append_arc_error_log(
            self._arc_error_log_path,
            error_code,
            detail,
            exception,
            format_context_lines(extra_context),
        )
        if self.logger:
            suffix = f" | {exception}" if exception else ""
            self.logger.error(
                f"{ColorFormat.RED}[ARC Core][{error_code}] {detail}{suffix}"
            )

    def report_arc_error(
        self,
        error_code: str,
        detail: str,
        player_for_notify=None,
        exception=None,
        **extra_context,
    ) -> None:
        """恶性错误：落盘 + 控制台 + 可选通知在线玩家（带错误代码）。"""
        ctx = extra_context if extra_context else None
        self._arc_persistent_error(error_code, detail, exception, ctx)
        if player_for_notify is not None:
            try:
                msg = self.language_manager.GetText("SYSTEM_ERROR_WITH_CODE")
                if not msg or not str(msg).strip():
                    msg = (
                        "[弧光核心]系统异常 ({0})，请将错误代码告知管理员，"
                        "并将 plugins/ARCCore/error_log.txt 中的对应记录发给弧光核心作者。"
                    )
                player_for_notify.send_message(msg.format(error_code))
            except Exception:
                pass

    def on_command(self, sender: CommandSender, command: Command, args: list[str]) -> bool:
        if command.name == 'updatespawnpos':
            if not isinstance(sender, Player):
                sender.send_message(f'[ARC Core]This command only works for players.')
                return True
            dimension_name = sender.location.dimension.name
            new_spawn_pos = (sender.location.x, sender.location.y, sender.location.z)
            r = self.update_spawn_location(dimension_name, new_spawn_pos)
            if r:
                self.spawn_pos_dict[dimension_name] = new_spawn_pos
                sender.send_message(self.language_manager.GetText('UPDATE_SPAWN_POS_SUCCESSFUL').format(dimension_name, new_spawn_pos))
            else:
                sender.send_message(self.language_manager.GetText('UPDATE_SPAWN_POS_FAILED'))
            return True
        if command.name == "arc":
            player = self._resolve_player_for_command_sender(sender)
            if player is None:
                return True
            if args and len(args) >= 1:
                head = args[0].lower()
                if head == "op":
                    if not player.is_op:
                        player.send_message(self.language_manager.GetText("OP_PANEL_NO_PERMISSION"))
                        return True
                    self.show_op_main_panel(player)
                    return True
                if head == "land":
                    if not self.if_player_logined(player):
                        self.show_main_menu(player)
                        return True
                    self.show_land_main_menu(player)
                    return True
                if head == "tp":
                    if not self.if_player_logined(player):
                        self.show_main_menu(player)
                        return True
                    self.show_teleport_menu(player)
                    return True
                if head == "bank":
                    if not self.if_player_logined(player):
                        self.show_main_menu(player)
                        return True
                    self.show_bank_main_menu(player)
                    return True
                if head == "guild":
                    if not self.if_player_logined(player):
                        self.show_main_menu(player)
                        return True
                    self.show_guild_main_menu(player)
                    return True
            self.show_main_menu(player)
            return True
        if command.name == "suicide":
            if not isinstance(sender, Player):
                sender.send_message(f'[ARC Core]This command only works for players.')
                return True
            self.server.dispatch_command(self.server.command_sender, f'kill {sender.name}')
            self.server.broadcast_message(self.language_manager.GetText('PLAYER_SUICIDE_MESSAGE').format(sender.name))
            return True
        if command.name == "spawn":
            if not isinstance(sender, Player):
                sender.send_message(f'[ARC Core]This command only works for players.')
                return True
            if sender.location.dimension.name in self.spawn_pos_dict:
                self.server.dispatch_command(self.server.command_sender,
                                             f'tp {sender.name} {int(self.spawn_pos_dict[sender.location.dimension.name][0])} {int(self.spawn_pos_dict[sender.location.dimension.name][1])} {int(self.spawn_pos_dict[sender.location.dimension.name][2])}')
                sender.send_message(self.language_manager.GetText('PLAYER_TELEPORTED_TO_SPAWN_HINT'))
            else:
                sender.send_message(self.language_manager.GetText('NO_SPAWN_POSITION_SET_MESSAGE'))
            return True
        if command.name == "land":
            player = self._resolve_player_for_command_sender(sender)
            if player is None:
                return True
            if not self.if_player_logined(player):
                self.show_main_menu(player)
                return True
            if not args:
                player.send_message(self.language_manager.GetText("LAND_COMMAND_USAGE"))
                return True
            sub = args[0].lower()
            if sub == "pos1":
                self._run_land_pos1_for_player(player)
                return True
            if sub == "pos2":
                self._run_land_pos2_for_player(player)
                return True
            if sub == "buy":
                self._run_land_buy_for_player(player)
                return True
            player.send_message(self.language_manager.GetText("LAND_COMMAND_USAGE"))
            return True
        if command.name == "landpos1":
            player = self._resolve_player_for_command_sender(sender)
            if player is None:
                return True
            if not self.if_player_logined(player):
                self.show_main_menu(player)
                return True
            self._run_land_pos1_for_player(player)
            return True
        if command.name == "landpos2":
            player = self._resolve_player_for_command_sender(sender)
            if player is None:
                return True
            if not self.if_player_logined(player):
                self.show_main_menu(player)
                return True
            self._run_land_pos2_for_player(player)
            return True
        if command.name == "landbuy":
            player = self._resolve_player_for_command_sender(sender)
            if player is None:
                return True
            if not self.if_player_logined(player):
                self.show_main_menu(player)
                return True
            self._run_land_buy_for_player(player)
            return True
        if command.name == 'pos1':
            if not isinstance(sender, Player):
                sender.send_message(f'[ARC Core]This command only works for players.')
                return True
            if not sender.is_op:
                sender.send_message(self.language_manager.GetText('OP_PANEL_NO_PERMISSION'))
                return True
            self.record_coordinate_1(sender)
            sender.send_message(self.language_manager.GetText('POS1_RECORDED'))
            return True
        if command.name == 'pos2':
            if not isinstance(sender, Player):
                sender.send_message(f'[ARC Core]This command only works for players.')
                return True
            if not sender.is_op:
                sender.send_message(self.language_manager.GetText('OP_PANEL_NO_PERMISSION'))
                return True
            self.record_coordinate_2(sender)
            return True
        if command.name == 'connecttoserver':
            sender_type_name = type(sender).__name__
            sender_name = str(getattr(sender, 'name', '') or '')
            sender_has_is_player = hasattr(sender, 'is_player')
            sender_is_player_attr = getattr(sender, 'is_player', None)
            sender_has_xuid = hasattr(sender, 'xuid')
            args_text = " ".join(args) if args else ""
            if not isinstance(sender, Player):
                fallback_player = self._resolve_player_from_sender_name(sender_name)
                self._safe_log(
                    "warning",
                    (
                        "[ARC Core][connecttoserver debug] non-player sender blocked: "
                        f"type={sender_type_name}, name={sender_name or '-'}, "
                        f"has_is_player={sender_has_is_player}, is_player={sender_is_player_attr}, "
                        f"has_xuid={sender_has_xuid}, args={args_text or '-'}, "
                        f"fallback_player={getattr(fallback_player, 'name', '-')}"
                    ),
                )
                if fallback_player is None:
                    return True
                sender = fallback_player
            self._safe_log(
                "info",
                (
                    "[ARC Core][connecttoserver debug] player sender accepted: "
                    f"name={sender.name}, xuid={sender.xuid}, args={args_text or '-'}"
                ),
            )
            if not args or not str(" ".join(args)).strip():
                if not self.if_player_logined(sender):
                    self.show_main_menu(sender)
                    return True
                self.show_cross_server_menu(sender, on_close=self.show_main_menu)
                return True
            server_name = " ".join(args).strip()
            target = self._get_cross_server_target_by_name(server_name)
            if not target:
                sender.send_message(self.language_manager.GetText('CONNECT_TO_SERVER_NOT_FOUND').format(server_name))
                return True
            self.transfer_player_to_server(
                sender,
                str(target.get('server_host') or ''),
                int(target.get('server_port') or 19132),
                str(target.get('server_name') or server_name),
            )
            return True
        return False

    @staticmethod
    def _strip_minecraft_format_codes(text: str) -> str:
        return re.sub(r"§.", "", str(text or ""))

    def _extract_player_name_from_sender_name(self, sender_name: str) -> str:
        normalized_sender_name = str(sender_name or "").strip()
        if not normalized_sender_name:
            return ""
        if "§r" in normalized_sender_name:
            normalized_sender_name = normalized_sender_name.rsplit("§r", 1)[-1]
        return self._strip_minecraft_format_codes(normalized_sender_name).strip()

    def _resolve_player_from_sender_name(self, sender_name: str) -> Optional[Player]:
        extracted_player_name = self._extract_player_name_from_sender_name(sender_name)
        if not extracted_player_name:
            return None
        try:
            resolved_player = self.server.get_player(extracted_player_name)
            if resolved_player is not None:
                return resolved_player
        except Exception:
            pass
        for online_player in list(getattr(self.server, "online_players", []) or []):
            online_player_name = str(getattr(online_player, "name", "") or "").strip()
            if online_player_name.lower() == extracted_player_name.lower():
                return online_player
        return None

    def _resolve_player_for_command_sender(self, sender: CommandSender) -> Optional[Player]:
        """真实玩家直接返回；控制台/命令方块等从 sender 名称解析在线玩家（与 connecttoserver 一致）。"""
        if isinstance(sender, Player):
            return sender
        return self._resolve_player_from_sender_name(str(getattr(sender, "name", "") or ""))

    def _run_land_pos1_for_player(self, player: Player) -> None:
        self.player_land_pos1[player.name] = {
            "dimension": player.location.dimension.name,
            "x": math.floor(player.location.x),
            "y": math.floor(player.location.y),
            "z": math.floor(player.location.z),
        }
        pos = self.player_land_pos1[player.name]
        player.send_message(
            self.language_manager.GetText("CREATE_NEW_LAND_POS1_SET").format(
                pos["dimension"],
                (pos["x"], pos["y"], pos["z"]),
            )
        )

    def _run_land_pos2_for_player(self, player: Player) -> None:
        if player.name not in self.player_land_pos1:
            player.send_message(self.language_manager.GetText("CREATE_NEW_LAND_POS2_SET_FAIL_POS1_NOT_SET"))
            return
        pos1 = self.player_land_pos1[player.name]
        if player.location.dimension.name != pos1["dimension"]:
            player.send_message(self.language_manager.GetText("CREATE_NEW_LAND_POS2_SET_FAIL_DIMENSION_CHANGED"))
            return
        x2 = math.floor(player.location.x)
        y2 = math.floor(player.location.y)
        z2 = math.floor(player.location.z)
        self.player_new_land_creation_info[player.name] = {
            "dimension": pos1["dimension"],
            "min_x": min(pos1["x"], x2),
            "max_x": max(pos1["x"], x2),
            "min_y": min(pos1["y"], y2),
            "max_y": max(pos1["y"], y2),
            "min_z": min(pos1["z"], z2),
            "max_z": max(pos1["z"], z2),
        }
        del self.player_land_pos1[player.name]
        player.send_message(self.language_manager.GetText("CREATE_NEW_LAND_POS2_SET").format((x2, y2, z2)))
        self._visualize_pending_land(player)
        self.show_pending_land_purchase_panel(player)

    def _run_land_buy_for_player(self, player: Player) -> None:
        self._execute_land_buy(player)

    # Event handlers
    @event_handler
    def on_player_join(self, event: PlayerJoinEvent):
        # 在玩家加入时立即初始化玩家数据（基本信息和经济数据）
        success, is_new_player = self.ensure_player_data_initialized(event.player)
        
        # 如果是新玩家，执行新人欢迎功能
        if is_new_player and success:
            # 发送新人欢迎消息
            self._send_newbie_welcome_message(event.player)
            # 执行新人指令
            self._execute_newbie_commands(event.player)
        
        self.server.broadcast_message(self.language_manager.GetText('PLAYER_JOIN_MESSAGE').format(event.player.name))
        self.player_authentication_state[event.player.name] = False
        event.player.send_message(self.language_manager.GetText('PLAYER_JOIN_HINT'))

        # 登录时提示可领取的邀请奖励次数
        try:
            player_xuid = str(event.player.xuid)
            pending_info = self.database_manager.query_one(
                "SELECT pending_invite_reward_times FROM player_basic_info WHERE xuid = ?",
                (player_xuid,)
            )
            if pending_info is not None:
                try:
                    pending_times = int(pending_info.get('pending_invite_reward_times', 0) or 0)
                except (ValueError, TypeError):
                    pending_times = 0
                if pending_times > 0:
                    event.player.send_message(
                        self.language_manager.GetText('INVITE_REWARD_PENDING_HINT').format(pending_times)
                    )
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Check pending invite rewards on join error: {str(e)}")

        self.title_system.on_player_join(event.player)
        self._auto_equip_highest_title_if_needed(event.player)
        self._update_player_name_tag(event.player)

        # 通知 qqsync 发送加入消息到 QQ 群
        try:
            equipped = self.title_system.get_equipped_title(event.player)
            display_name = self.format_player_display_label_with_guild(
                event.player.name, equipped, str(event.player.xuid)
            )
            self._notify_qqsync("join", display_name, event.player.name)
        except Exception as e:
            self.logger.error(f"[ARC Core]Notify qqsync join error: {e}")

        if self.force_login and not self.if_player_logined(event.player):
            self.server.scheduler.run_task(
                self,
                lambda p=event.player: self._show_force_login_menu_with_delay(p),
                delay=20,
            )

    def _show_force_login_menu_with_delay(self, player: Player):
        if player is None:
            return
        if not self.force_login:
            return
        if self.if_player_logined(player):
            return
        if player not in self.server.online_players:
            return
        self.show_main_menu(player)

    @event_handler
    def on_player_respawn(self, event: PlayerRespawnEvent):
        """玩家重生后重新设置 name_tag 为 [头衔]名字，防止重生后头顶名被重置。"""
        self._update_player_name_tag(event.player)

    @event_handler
    def on_player_chat(self, event: PlayerChatEvent):
        """远古 QQ 风格：首行 [头衔]玩家名(年.月.日-时:分)：，下一行消息内容。取消原事件并自行广播。"""
        try:
            raw_message = event.message
            now = datetime.now()
            time_str = f"{now.year}.{now.month}.{now.day}-{now.hour}:{now.minute:02d}"
            equipped = self.title_system.get_equipped_title(event.player)
            name = event.player.name
            base = self.format_player_display_label_with_guild(
                name, equipped, str(event.player.xuid)
            )
            line1 = f"{base}({time_str})："
            formatted = line1 + "\n" + raw_message
            event.is_cancelled = True
            self.server.broadcast_message(formatted)

            # 通知 qqsync 发送聊天消息到 QQ 群
            try:
                display_name = self.format_player_display_label_with_guild(
                    name, equipped, str(event.player.xuid)
                )
                self._notify_qqsync("chat", display_name, name, raw_message)
            except Exception as e:
                self.logger.error(f"[ARC Core]Notify qqsync chat error: {e}")
        except Exception as e:
            if self.logger:
                self.logger.error(f"[ARC Core]Chat title format error: {e}")

    @event_handler
    def on_player_quit(self, event: PlayerQuitEvent):
        self.server.broadcast_message(self.language_manager.GetText('PLAYER_QUIT_MESSAGE').format(event.player.name))
        self.player_authentication_state[event.player.name] = False

        # 通知 qqsync 发送离开消息到 QQ 群
        try:
            equipped = self.title_system.get_equipped_title(event.player)
            display_name = self.format_player_display_label_with_guild(
                event.player.name, equipped, str(event.player.xuid)
            )
            self._notify_qqsync("quit", display_name, event.player.name)
        except Exception as e:
            self.logger.error(f"[ARC Core]Notify qqsync quit error: {e}")
        
        # 线程安全地清理玩家领地位置记录
        with self.position_thread_lock:
            if event.player.name in self.player_in_land_id_dict:
                del self.player_in_land_id_dict[event.player.name]
        self.player_land_creation_pick.pop(event.player.name, None)
        self.player_land_pick_last_event_ts.pop(event.player.name, None)

    @event_handler
    def on_block_break(self, event: BlockBreakEvent):
        block_loc = event.block.location
        target_desc = getattr(event.block, 'identifier', getattr(event.block, 'type', 'block'))
        self._send_op_debug_message(
            event.player, 'BlockBreak', str(target_desc),
            block_loc.dimension.name, block_loc.x, block_loc.y, block_loc.z
        )
        if event.player.is_op:
            return

        if self.dtwt_plugin is not None and self.dtwt_plugin.api_judge_if_start_block(event.block.location.x, event.block.location.y, event.block.location.z, event.block.dimension.name):
            # print('DTWT block break, ignore')
            return

        if not self.land_operation_check(event.player, event.block.location.dimension.name,
                                    (event.block.location.x, event.block.location.y, event.block.location.z)):
            event.is_cancelled = True
            self._append_land_permission_denied_log(
                "block_break",
                event.player,
                event.block.location.dimension.name,
                (event.block.location.x, event.block.location.y, event.block.location.z),
                target_description=str(target_desc),
            )
        if not event.is_cancelled and self._is_frame_block(event.block):
            land_id = self.get_land_at_pos(
                event.block.location.dimension.name,
                int(event.block.location.x), int(event.block.location.z),
                int(event.block.location.y)
            )
            if land_id is not None:
                land_info = self.get_land_info(land_id)
                if land_info and not land_info.get('allow_frame', False):
                    event.is_cancelled = True
                    event.player.send_message(self.language_manager.GetText('LAND_FRAME_PROTECT_HINT'))
                    self._append_land_permission_denied_log(
                        "frame_block_break",
                        event.player,
                        event.block.location.dimension.name,
                        (event.block.location.x, event.block.location.y, event.block.location.z),
                        land_id=land_id,
                        target_description=str(target_desc),
                        note="allow_frame_disabled",
                    )
        if not self.spawn_protect_check(event.player, event.block.location.dimension.name,
                                    (event.block.location.x, event.block.location.y, event.block.location.z)):
            event.is_cancelled = True

        if not event.is_cancelled:
            try:
                block_id = getattr(event.block, 'identifier', getattr(event.block, 'type', 'block'))
                self.achievement_system.record_block_break(event.player, str(block_id))
            except Exception:
                pass
        return

    def _is_frame_block(self, block) -> bool:
        """是否属于与 allow_frame 联动的方块（见 PUBLIC_LAND_INTERACT_BLOCK_BLACKLIST，默认含展示框与各材质展示架）"""
        bid = str(
            getattr(block, 'identifier', None) or getattr(block, 'type', None) or ''
        ).lower()
        if not bid:
            return False
        return bid in self.land_system.get_public_land_interact_block_blacklist()

    def _arc_block_type_descriptor(self, block) -> Optional[str]:
        """从 Block 解析类型 ID（官方 Block API 以 type 为准；identifier / data.type 作补充）"""
        if block is None:
            return None
        raw_type = getattr(block, 'type', None)
        if raw_type is not None:
            text = str(raw_type).strip()
            if text:
                return text
        ident = getattr(block, 'identifier', None)
        if ident is not None:
            text = str(ident).strip()
            if text:
                return text
        data = getattr(block, 'data', None)
        if data is not None:
            dt = getattr(data, 'type', None)
            if dt is not None:
                text = str(dt).strip()
                if text:
                    return text
        return None

    @staticmethod
    def _arc_is_air_block_type(desc: Optional[str]) -> bool:
        if not desc:
            return True
        normalized = str(desc).lower().strip()
        return normalized in ('air', 'minecraft:air')

    def _arc_block_place_event_location(self, event: BlockPlaceEvent):
        """放置坐标优先取 block_placed（与官方 BlockPlaceEvent 一致），否则 BlockEvent.block。"""
        placed = getattr(event, 'block_placed', None)
        if placed is not None and getattr(placed, 'location', None) is not None:
            return placed.location
        fallback = getattr(event, 'block', None)
        if fallback is not None and getattr(fallback, 'location', None) is not None:
            return fallback.location
        return None

    def _arc_placed_block_type_from_place_event(self, event: BlockPlaceEvent) -> str:
        """
        BlockPlaceEvent：block_placed 为「放置后的方块」；若绑定层仍为空气则依次尝试
        block_placed_state、主手物品 ItemType.id、BlockEvent.block。
        """
        placed = getattr(event, 'block_placed', None)
        desc = self._arc_block_type_descriptor(placed)
        if desc is not None and not self._arc_is_air_block_type(desc):
            return desc

        placed_state = getattr(event, 'block_placed_state', None)
        if placed_state is not None:
            st_type = getattr(placed_state, 'type', None)
            if st_type is not None:
                text = str(st_type).strip()
                if text and not self._arc_is_air_block_type(text):
                    return text
            state_block = getattr(placed_state, 'block', None)
            desc = self._arc_block_type_descriptor(state_block)
            if desc is not None and not self._arc_is_air_block_type(desc):
                return desc

        player = getattr(event, 'player', None)
        if player is not None:
            inv = getattr(player, 'inventory', None)
            if inv is not None:
                stack = getattr(inv, 'item_in_main_hand', None)
                if stack is not None:
                    item_type = getattr(stack, 'type', None)
                    if item_type is not None:
                        item_id = getattr(item_type, 'id', None)
                        if item_id:
                            return str(item_id)
                        if isinstance(item_type, str) and item_type.strip():
                            return item_type.strip()

        eb = getattr(event, 'block', None)
        desc = self._arc_block_type_descriptor(eb)
        if desc is not None:
            return desc
        return 'block'

    @event_handler
    def on_block_place(self, event: BlockPlaceEvent):
        block_loc = self._arc_block_place_event_location(event)
        if block_loc is None:
            return
        target_desc = self._arc_placed_block_type_from_place_event(event)
        self._send_op_debug_message(
            event.player, 'BlockPlace', str(target_desc),
            block_loc.dimension.name, block_loc.x, block_loc.y, block_loc.z
        )
        if event.player.is_op:
            return
        dimension_name = block_loc.dimension.name
        place_pos = (block_loc.x, block_loc.y, block_loc.z)
        if self._is_disabled_block(target_desc):
            event.is_cancelled = True
            event.player.send_message(self.language_manager.GetText("DISABLED_BLOCK_DENIED_HINT"))
            self._append_land_permission_denied_log(
                "block_place_disabled",
                event.player,
                dimension_name,
                place_pos,
                target_description=str(target_desc),
            )
            return
        if not self.land_only_place_wilderness_check(
            event.player,
            dimension_name,
            place_pos,
            target_desc,
        ):
            event.is_cancelled = True
            self._append_land_permission_denied_log(
                "block_place_land_only",
                event.player,
                dimension_name,
                place_pos,
                target_description=str(target_desc),
                note="wilderness",
            )
        if not self.land_operation_check(event.player, dimension_name, place_pos):
            event.is_cancelled = True
            self._append_land_permission_denied_log(
                "block_place",
                event.player,
                dimension_name,
                place_pos,
                target_description=str(target_desc),
            )
        if not self.spawn_protect_check(event.player, dimension_name, place_pos):
            event.is_cancelled = True
        return
    
    @event_handler
    def on_player_death(self, event: PlayerDeathEvent):
        # 记录玩家死亡位置
        self.teleport_system.record_death_location(
            event.player.name,
            event.player.location.dimension.name,
            event.player.location.x,
            event.player.location.y,
            event.player.location.z,
        )
        event.player.send_message(self.language_manager.GetText('DEATH_LOCATION_RECORDED'))
        
        # 发送死亡播报
        self._send_death_broadcast(event)

    @event_handler
    def on_player_interact(self, event: PlayerInteractEvent):
        """处理玩家交互事件，保护领地免受非法交互"""
        try:
            # 玩家或OP判定
            if not hasattr(event, 'player') or event.player is None:
                return
            if getattr(event, 'has_block', False) and self._try_consume_land_creation_pick(event):
                return
            # 调试模式：有方块时发送方块交互信息
            if getattr(event, 'has_block', False):
                block = getattr(event, 'block', None)
                if block is not None and hasattr(block, 'location') and block.location is not None:
                    bl = block.location
                    target_desc = getattr(block, 'identifier', getattr(block, 'type', 'block'))
                    dim_name = bl.dimension.name if hasattr(bl, 'dimension') and bl.dimension else getattr(event.player.location.dimension, 'name', '')
                    self._send_op_debug_message(event.player, 'BlockInteract', str(target_desc), dim_name, bl.x, bl.y, bl.z)
            if getattr(event.player, 'is_op', False):
                return

            # 只检查有方块的交互事件
            if not getattr(event, 'has_block', False):
                return

            block = getattr(event, 'block', None)
            if block is None or not hasattr(block, 'location') or block.location is None:
                return

            block_location = block.location

            # DTWT 设施判定（若可用）
            try:
                if (
                    self.dtwt_plugin is not None and
                    hasattr(block, 'dimension') and block.dimension is not None and hasattr(block.dimension, 'name') and
                    self.dtwt_plugin.api_judge_if_start_block(block_location.x, block_location.y, block_location.z, block.dimension.name)
                ):
                    return
            except Exception:
                # 外部插件异常不影响主流程
                pass

            # 维度与坐标
            if hasattr(block, 'dimension') and block.dimension is not None and hasattr(block.dimension, 'name'):
                dimension = block.dimension.name
            else:
                # 回退到玩家维度
                dimension = event.player.location.dimension.name if hasattr(event.player, 'location') and event.player.location else ''

            pos = (block_location.x, block_location.y, block_location.z)

            # 检查是否在领地内且不是领地主人
            block_target_desc = str(
                getattr(block, 'identifier', getattr(block, 'type', 'block'))
            )
            if self._is_disabled_block(block_target_desc):
                event.is_cancelled = True
                event.player.send_message(self.language_manager.GetText("DISABLED_BLOCK_DENIED_HINT"))
                self._append_land_permission_denied_log(
                    "block_interact_disabled",
                    event.player,
                    dimension,
                    pos,
                    target_description=block_target_desc,
                )
                return
            if not self.land_interact_check(event.player, dimension, pos):
                event.is_cancelled = True
                self._append_land_permission_denied_log(
                    "block_interact",
                    event.player,
                    dimension,
                    pos,
                    target_description=block_target_desc,
                )
            elif self._is_frame_block(block):
                land_id = self.get_land_at_pos(dimension, int(block_location.x), int(block_location.z), int(block_location.y))
                if land_id is not None:
                    land_info = self.get_land_info(land_id)
                    if land_info and not land_info.get('allow_frame', False):
                        event.is_cancelled = True
                        event.player.send_message(self.language_manager.GetText('LAND_FRAME_PROTECT_HINT'))
                        self._append_land_permission_denied_log(
                            "frame_interact",
                            event.player,
                            dimension,
                            pos,
                            land_id=land_id,
                            target_description=block_target_desc,
                            note="allow_frame_disabled",
                        )
        except Exception as e:
            pass
            # self.logger.error(f"[ARC Core] on_player_interact error: {str(e)}")

    @event_handler
    def on_actor_explode(self, event: ActorExplodeEvent):
        """处理爆炸事件，保护领地免受爆炸伤害"""
        try:
            explosion_location = event.location
            dimension = explosion_location.dimension.name
            
            # 检查爆炸位置是否在任何领地内
            land_id = self.get_land_at_pos(dimension, math.floor(explosion_location.x), math.floor(explosion_location.z))
            if land_id is not None:
                land_info = self.get_land_info(land_id)
                if land_info and not land_info.get('allow_explosion', False):
                    # 如果领地不允许爆炸，则取消爆炸事件
                    event.is_cancelled = True
                    return
                    
            # 检查爆炸影响的方块是否在领地内
            filtered_blocks = []
            for block in event.block_list:
                block_land_id = self.get_land_at_pos(dimension, math.floor(block.location.x), math.floor(block.location.z))
                if block_land_id is not None:
                    block_land_info = self.get_land_info(block_land_id)
                    if block_land_info and block_land_info.get('allow_explosion', False):
                        # 如果该领地允许爆炸，保留这个方块在爆炸列表中
                        filtered_blocks.append(block)
                    # 如果不允许爆炸，则不添加到列表中（移除）
                else:
                    # 不在领地内的方块保持原样
                    filtered_blocks.append(block)
            
            # 更新爆炸影响的方块列表
            event.block_list = filtered_blocks
            
        except Exception as e:
            self.logger.error(f"Handle actor explode event error: {str(e)}")

    @event_handler
    def on_player_interact_actor(self, event: PlayerInteractActorEvent):
        """处理玩家与生物交互事件，保护领地内生物免受非法交互"""
        actor_location = event.actor.location
        target_desc = getattr(event.actor, 'identifier', getattr(event.actor, 'type', 'actor'))
        self._send_op_debug_message(
            event.player, 'ActorInteract', str(target_desc),
            actor_location.dimension.name, actor_location.x, actor_location.y, actor_location.z
        )
        # OP玩家跳过检查
        if event.player.is_op:
            return

        # 获取生物位置
        actor_location = event.actor.location
        dimension = actor_location.dimension.name
        ax = math.floor(actor_location.x)
        ay = math.floor(actor_location.y)
        az = math.floor(actor_location.z)

        # 检查生物是否在领地内
        land_id = self.get_land_at_pos(dimension, ax, az, ay)
        if land_id is not None:
            # 先检查子领地权限
            sub_land_id = self.get_sub_land_at_pos(land_id, ax, ay, az)
            if sub_land_id is not None:
                sub_info = self.get_sub_land_info(sub_land_id)
                if sub_info and self._check_sub_land_permission(event.player, sub_info):
                    return
            land_info = self.get_land_info(land_id)
            if land_info and not land_info.get('allow_actor_interaction', False):
                # 检查玩家是否有权限（领地主人或授权用户）
                if not self._check_land_permission(event.player, land_info):
                    event.is_cancelled = True
                    event.player.send_message(self.language_manager.GetText('LAND_ACTOR_INTERACTION_DENIED'))
                    self._append_land_permission_denied_log(
                        "actor_interact",
                        event.player,
                        dimension,
                        (float(ax), float(ay), float(az)),
                        land_id=land_id,
                        target_description=str(target_desc),
                    )

    @event_handler
    def on_actor_damage(self, event: ActorDamageEvent):
        """处理生物受伤事件，保护领地内生物免受攻击"""
        # 检查攻击者是否为玩家
        attacker = event.damage_source.actor
        if attacker is None or attacker.type != "minecraft:player":
            return

        actor_location = event.actor.location
        target_desc = getattr(event.actor, 'identifier', getattr(event.actor, 'type', 'actor'))
        self._send_op_debug_message(
            attacker, 'ActorDamage', str(target_desc),
            actor_location.dimension.name, actor_location.x, actor_location.y, actor_location.z
        )
        # 如果玩家是op则不判断
        if attacker.is_op:
            return

        # 获取被攻击生物位置
        actor_location = event.actor.location
        dimension = actor_location.dimension.name
        ax = math.floor(actor_location.x)
        ay = math.floor(actor_location.y)
        az = math.floor(actor_location.z)

        # 检查生物是否在领地内
        land_id = self.get_land_at_pos(dimension, ax, az, ay)
        if land_id is not None:
            # 先检查子领地权限：有子领地权限则直接放行
            sub_land_id = self.get_sub_land_at_pos(land_id, ax, ay, az)
            if sub_land_id is not None:
                sub_info = self.get_sub_land_info(sub_land_id)
                if sub_info and self._check_sub_land_permission(attacker, sub_info):
                    return
            land_info = self.get_land_info(land_id)
            if not land_info:
                return
            # 公共领地：禁止生物伤害时一律拦截；开放生物伤害时仅保护白名单生物
            if self.is_public_land(land_id):
                if not land_info.get('allow_actor_damage', False):
                    event.is_cancelled = True
                    attacker.send_message(self.language_manager.GetText('LAND_ACTOR_DAMAGE_DENIED'))
                    self._append_land_permission_denied_log(
                        "actor_damage",
                        attacker,
                        dimension,
                        (float(ax), float(ay), float(az)),
                        land_id=land_id,
                        target_description=str(target_desc),
                        note="public_land_actor_damage_disabled",
                    )
                    return
                protected = self._get_public_land_protected_entities()
                # print("entity",event.actor.type, "public land protected entities", protected)
                damaged_entity_type = event.actor.type
                if damaged_entity_type and damaged_entity_type in protected:
                    event.is_cancelled = True
                    attacker.send_message(self.language_manager.GetText('LAND_ACTOR_DAMAGE_DENIED'))
                    self._append_land_permission_denied_log(
                        "actor_damage",
                        attacker,
                        dimension,
                        (float(ax), float(ay), float(az)),
                        land_id=land_id,
                        target_description=str(target_desc),
                        note="public_land_protected_entity",
                    )
                return
            # 非公共领地：未开放生物伤害时仅主人/授权用户可造成伤害（与方块互动等统一走权限判定）
            if not land_info.get('allow_actor_damage', False):
                if not self._check_land_permission(attacker, land_info):
                    event.is_cancelled = True
                    attacker.send_message(self.language_manager.GetText('LAND_ACTOR_DAMAGE_DENIED'))
                    self._append_land_permission_denied_log(
                        "actor_damage",
                        attacker,
                        dimension,
                        (float(ax), float(ay), float(az)),
                        land_id=land_id,
                        target_description=str(target_desc),
                        note="private_land_no_actor_damage_permission",
                    )

    @event_handler
    def on_actor_death(self, event: ActorDeathEvent):
        """统计玩家击杀生物：击杀总数 + 按生物类型击杀数。"""
        try:
            damage_source = getattr(event, "damage_source", None)
            killer = getattr(damage_source, "actor", None) if damage_source is not None else None
            if killer is None:
                return
            if getattr(killer, "type", None) != "minecraft:player":
                return

            dead_actor = getattr(event, "actor", None)
            if dead_actor is None:
                return
            if getattr(dead_actor, "type", None) == "minecraft:player":
                return

            dead_type = getattr(dead_actor, "type", None) or getattr(dead_actor, "identifier", None) or ""
            if not dead_type:
                return

            dead_type_key = normalize_entity_type_id(str(dead_type))
            self.achievement_system.record_kill(killer, dead_type_key)

            reward = self.kill_reward_config.get_reward_and_ensure_key(dead_type_key)
            if reward > 0:
                if self.increase_player_money_by_name(killer.name, reward, notify=False):
                    display_name = self.entity_display_name_manager.get_display_name_for_entity_type(dead_type_key)
                    killer.send_message(
                        self.language_manager.GetText("KILL_REWARD_MESSAGE").format(
                            display_name,
                            self._format_money_display(reward),
                        )
                    )
        except Exception:
            return

    def _check_sub_land_permission(self, player: Player, sub_land_info: dict) -> bool:
        """检查玩家是否拥有子领地权限（主人或授权用户）"""
        try:
            owner_xuid = sub_land_info.get('owner_xuid', '')
            shared_users = sub_land_info.get('shared_users', [])
            return owner_xuid == str(player.xuid) or str(player.xuid) in shared_users
        except Exception as e:
            self.logger.error(f"Check sub land permission error: {str(e)}")
            return False

    def _check_land_permission(self, player: Player, land_info: dict) -> bool:
        """
        检查玩家是否有领地权限（领地主人或授权用户）；公共领地仅 OP 有权限
        :param player: 玩家对象
        :param land_info: 领地信息字典
        :return: 是否有权限
        """
        try:
            owner_xuid = land_info['owner_xuid']
            if owner_xuid == self.PUBLIC_LAND_OWNER_XUID:
                return player.is_op
            shared_users = land_info.get('shared_users', [])
            return owner_xuid == str(player.xuid) or str(player.xuid) in shared_users
        except Exception as e:
            self.logger.error(f"Check land permission error: {str(e)}")
            return False

    def _append_land_permission_denied_log(
        self,
        action_kind: str,
        player: Player,
        dimension: str,
        pos: tuple,
        *,
        land_id: Optional[int] = None,
        target_description: str = "",
        note: str = "",
    ) -> None:
        """无权限领地操作被拒绝时写入日志：plugins/ARCCore/land_inteteact_log/YYYY-MM-DD.txt"""
        try:
            if not player or not dimension:
                return
            x = pos[0] if len(pos) > 0 else 0.0
            y = pos[1] if len(pos) > 1 else None
            z = pos[2] if len(pos) > 2 else 0.0
            if land_id is None:
                if y is not None:
                    land_id = self.get_land_at_pos(
                        dimension, int(math.floor(x)), int(math.floor(z)), int(math.floor(y))
                    )
                else:
                    land_id = self.get_land_at_pos(
                        dimension, int(math.floor(x)), int(math.floor(z))
                    )
            player_name = getattr(player, "name", "") or "?"
            player_xuid = str(getattr(player, "xuid", "") or "")
            ts = datetime.now().isoformat(timespec="seconds")
            pos_y = "-" if y is None else str(y)
            line = (
                f"{ts}\t{action_kind}\tplayer={player_name}\txuid={player_xuid}\t"
                f"dim={dimension}\tpos=({x},{pos_y},{z})\tland_id={land_id if land_id is not None else '-'}\t"
                f"target={target_description or '-'}"
            )
            if note:
                line += f"\tnote={note}"
            line += "\n"
            log_dir = Path(MAIN_PATH) / LAND_INTERACT_LOG_DIR_NAME
            log_dir.mkdir(parents=True, exist_ok=True)
            date_filename = datetime.now().strftime("%Y-%m-%d") + ".txt"
            log_path = log_dir / date_filename
            payload = line.encode("utf-8")
            with self._land_interact_log_lock:
                with open(log_path, "ab") as log_file:
                    log_file.write(payload)
        except Exception:
            pass

    def _refresh_land_only_place_blocks(self):
        """从 LAND_ONLY_PLACE_BLOCKS 解析「仅允许在领地内放置」的方块 ID 集合（与 PUBLIC_LAND_INTERACT_BLOCK_BLACKLIST 相同的规范化规则）"""
        raw = self.setting_manager.GetSetting("LAND_ONLY_PLACE_BLOCKS")
        if raw is None or not str(raw).strip():
            self._land_only_place_block_ids = frozenset()
            return
        parsed = set()
        for part in str(raw).split(","):
            part = part.strip()
            if not part:
                continue
            normalized = part.lower()
            if ":" not in normalized:
                normalized = "minecraft:" + normalized
            parsed.add(normalized)
        self._land_only_place_block_ids = frozenset(parsed)

    @staticmethod
    def _normalize_block_id(block_identifier: str) -> str:
        normalized = str(block_identifier or "").lower().strip()
        if not normalized:
            return ""
        if ":" not in normalized:
            normalized = "minecraft:" + normalized
        return normalized

    def _refresh_disabled_blocks(self):
        """从 DISABLED_BLOCKS 解析「全局禁用方块」ID 集合（禁放置与禁交互）。"""
        raw = self.setting_manager.GetSetting("DISABLED_BLOCKS")
        if raw is None or not str(raw).strip():
            self._disabled_block_ids = frozenset()
            return
        parsed = set()
        for part in str(raw).split(","):
            normalized = self._normalize_block_id(part)
            if normalized:
                parsed.add(normalized)
        self._disabled_block_ids = frozenset(parsed)

    def _is_disabled_block(self, block_identifier: str) -> bool:
        return self._normalize_block_id(block_identifier) in self._disabled_block_ids

    def land_only_place_wilderness_check(
        self, player: Player, dimension: str, pos: tuple, block_identifier: str
    ) -> bool:
        """配置的方块禁止在荒野放置；是否允许建造/授权由 land_operation_check 判定。"""
        bid = str(block_identifier or "").lower().strip()
        if not bid:
            return True
        if ":" not in bid:
            bid = "minecraft:" + bid
        if bid not in self._land_only_place_block_ids:
            return True
        x, y, z = pos[0], (pos[1] if len(pos) > 1 else None), pos[2]
        land_id = self.get_land_at_pos(dimension, x, z, y)
        if land_id is None:
            player.send_message(self.language_manager.GetText("LAND_ONLY_PLACE_WILDERNESS_HINT"))
            return False
        return True

    def land_operation_check(self, player: Player, dimension: str, pos: tuple):
        x, y, z = pos[0], (pos[1] if len(pos) > 1 else None), pos[2]
        land_id = self.get_land_at_pos(dimension, x, z, y)
        if land_id is not None:
            # 先检查子领地权限
            if y is not None:
                sub_land_id = self.get_sub_land_at_pos(land_id, int(x), int(y), int(z))
                if sub_land_id is not None:
                    sub_info = self.get_sub_land_info(sub_land_id)
                    if sub_info and self._check_sub_land_permission(player, sub_info):
                        return True
            # 回落到父领地权限检查
            land_info = self.get_land_info(land_id)
            if not land_info:
                return True
            owner_xuid = land_info['owner_xuid']
            if owner_xuid == self.PUBLIC_LAND_OWNER_XUID:
                if not player.is_op:
                    player.send_message(self.language_manager.GetText('LAND_PROTECT_HINT').format(self.language_manager.GetText('PUBLIC_LAND_NAME')))
                    return False
                return True
            shared_users = land_info['shared_users']
            if owner_xuid != str(player.xuid) and str(player.xuid) not in shared_users:
                player.send_message(self.language_manager.GetText('LAND_PROTECT_HINT').format(self.get_player_name_by_xuid(owner_xuid)))
                return False
        return True

    def land_interact_check(self, player: Player, dimension: str, pos: tuple):
        """检查玩家是否有权限在领地内进行方块互动"""
        x, y, z = pos[0], (pos[1] if len(pos) > 1 else None), pos[2]
        land_id = self.get_land_at_pos(dimension, x, z, y)
        if land_id is not None:
            # 先检查子领地权限
            if y is not None:
                sub_land_id = self.get_sub_land_at_pos(land_id, int(x), int(y), int(z))
                if sub_land_id is not None:
                    sub_info = self.get_sub_land_info(sub_land_id)
                    if sub_info and self._check_sub_land_permission(player, sub_info):
                        return True
            # 回落到父领地权限检查
            land_info = self.get_land_info(land_id)
            if not land_info:
                return True
            if land_info.get('allow_public_interact', False):
                return True
            owner_xuid = land_info['owner_xuid']
            if owner_xuid == self.PUBLIC_LAND_OWNER_XUID:
                if not player.is_op:
                    player.send_message(self.language_manager.GetText('LAND_PROTECT_HINT').format(self.language_manager.GetText('PUBLIC_LAND_NAME')))
                    return False
                return True
            shared_users = land_info['shared_users']
            if owner_xuid != str(player.xuid) and str(player.xuid) not in shared_users:
                player.send_message(self.language_manager.GetText('LAND_PROTECT_HINT').format(self.get_player_name_by_xuid(owner_xuid)))
                return False
        return True
    
    def spawn_protect_check(self, player: Player, dimension: str, pos: tuple):
        if self.if_protect_spawn and len(self.spawn_pos_dict):
            if not self.spawn_protect_check(dimension, pos[0], pos[2]):
                player.send_message(self.language_manager.GetText('SPAWN_PROTECT_HINT').format(self.spawn_protect_range))
                return False
        return True

    # Listener
    def _threaded_position_listener(self):
        """多线程位置检测方法"""
        self.logger.info(f"{ColorFormat.GREEN}[ARC Core]Position detection thread started")
        
        while self.position_thread_running:
            try:
                # 检查是否有在线玩家，如果没有则跳过此次检测
                if not self.server.online_players:
                    time.sleep(self.position_check_interval)
                    continue
                
                # 批量处理所有在线玩家
                players_to_process = list(self.server.online_players)
                
                for player in players_to_process:
                    if not self.position_thread_running:  # 提前退出检查
                        break
                        
                    try:
                        # 获取玩家位置信息
                        player_pos = self.get_player_position_vector(player)
                        dimension = player.location.dimension.name
                        land_id = self.get_land_at_pos(dimension, player_pos[0], player_pos[2], player_pos[1])
                        
                        # 使用锁保护共享数据
                        with self.position_thread_lock:
                            # 初始化玩家领地记录
                            if player.name not in self.player_in_land_id_dict:
                                self.player_in_land_id_dict[player.name] = None
                            
                            # 检查领地变化
                            old_land_id = self.player_in_land_id_dict[player.name]
                            if self.is_land_id_changed(old_land_id, land_id):
                                self.player_in_land_id_dict[player.name] = land_id
                                
                                # 进入新领地时发送提示
                                if land_id is not None:
                                    try:
                                        new_land_name = self.get_land_name(land_id)
                                        land_owner = self.get_land_display_owner_name(land_id)
                                        
                                        # 创建固定参数的闭包，避免循环变量捕获问题
                                        def create_land_message_sender(target_player, land_name, owner_name, land_id):
                                            def send_land_message():
                                                try:
                                                    # 发送领地信息字幕（公共领地只显示「公共领地」，不显示「领主：公共领地」）
                                                    if self.is_public_land(land_id):
                                                        subtitle = self.language_manager.GetText('PUBLIC_LAND_NAME')
                                                    else:
                                                        subtitle = self.language_manager.GetText('STEP_IN_LAND_SUBTITLE').format(owner_name)
                                                    target_player.send_popup(
                                                        f'{self.language_manager.GetText("STEP_IN_LAND_TITLE").format(land_name)}\n{subtitle}'
                                                    )
                                                    # 显示领地边界粒子效果
                                                    land_info = self.get_land_info(land_id)
                                                    if land_info:
                                                        self.display_land_particle_boundary(target_player, land_info)
                                                    
                                                except Exception as e:
                                                    self.logger.warning(f"[ARC Core]Failed to send land message to {target_player.name}: {str(e)}")
                                            return send_land_message
                                        
                                        # 创建消息发送器，固定当前玩家和领地信息
                                        message_sender = create_land_message_sender(player, new_land_name, land_owner, land_id)
                                        
                                        # 在主线程中执行UI操作
                                        if hasattr(self.server, 'scheduler'):
                                            self.server.scheduler.run_task(self, message_sender, delay=0)
                                        
                                    except Exception as e:
                                        self.logger.warning(f"[ARC Core]Error processing land change for {player.name}: {str(e)}")
                                        
                    except Exception as e:
                        self.logger.warning(f"[ARC Core]Error processing player {player.name} position: {str(e)}")
                        continue
                
                # 等待下次检测
                time.sleep(self.position_check_interval)
                
            except Exception as e:
                self.logger.error(f"[ARC Core]Position detection thread error: {str(e)}")
                time.sleep(1)  # 发生错误时等待1秒再继续
        
        self.logger.info(f"{ColorFormat.YELLOW}[ARC Core]Position detection thread stopped")

    def start_position_thread(self):
        """启动位置检测线程"""
        if self.position_thread is None or not self.position_thread.is_alive():
            self.position_thread_running = True
            self.position_thread = threading.Thread(
                target=self._threaded_position_listener,
                daemon=True,  # 设为守护线程，主程序退出时自动结束
                name="ARCCore-PositionDetection"
            )
            self.position_thread.start()
            self.logger.info(f"{ColorFormat.GREEN}[ARC Core]Position detection thread initialized")
        else:
            self.logger.warning(f"{ColorFormat.YELLOW}[ARC Core]Position detection thread already running")

    def stop_position_thread(self):
        """停止位置检测线程"""
        if self.position_thread and self.position_thread.is_alive():
            self.position_thread_running = False
            try:
                self.position_thread.join(timeout=2.0)  # 等待最多2秒让线程正常结束
                if self.position_thread.is_alive():
                    self.logger.warning(f"{ColorFormat.YELLOW}[ARC Core]Position detection thread did not stop gracefully")
                else:
                    self.logger.info(f"{ColorFormat.GREEN}[ARC Core]Position detection thread stopped successfully")
            except Exception as e:
                self.logger.error(f"[ARC Core]Error stopping position detection thread: {str(e)}")
        self.position_thread = None

    @staticmethod
    def is_land_id_changed(old_land_id: int | None, new_land_id: int | None) -> bool:
        """
        判断玩家所在领地ID是否发生变化
        :param old_land_id: 玩家之前所在的领地ID（可能为None）
        :param new_land_id: 玩家当前所在的领地ID（可能为None）
        :return: 是否发生变化
        """
        # 都是None则未变化
        if old_land_id is None and new_land_id is None:
            return False

        # 一个是None另一个不是,说明进入或离开了领地
        if (old_land_id is None) != (new_land_id is None):
            return True

        # 都不是None,直接比较数值是否相同
        return old_land_id != new_land_id

    # Database
    def init_database(self):
        self.init_player_basic_table()
        self.init_spawn_locations_table()
        self.init_small_horn_orders_table()
        self.init_cross_server_table()
        self.economy.init_economy_table()
        self.economy.upgrade_player_economy_table_to_float()
        self.land_system.init_land_tables()
        self.land_system.init_sub_land_table()
        self.teleport_system.init_teleport_tables()
        self.title_system.ensure_tables()
        self.achievement_system.ensure_tables()
        self.guild_system.ensure_tables()
        self._init_richest_title_state_table()

    def _get_richest_title_name(self) -> str:
        name = self.setting_manager.GetSetting("RICHEST_TITLE_NAME")
        name = (str(name).strip() if name is not None else "").strip()
        return name if name else "首富"

    def _ensure_richest_title_definition(self) -> None:
        richest_title_name = self._get_richest_title_name()
        # 默认：传奇头衔，描述固定，奖励为空
        self.title_system.set_title_definition(
            richest_title_name,
            "传奇",
            "服务器里最富有玩家",
            0.0,
            [],
        )

    def _init_richest_title_state_table(self) -> None:
        try:
            self.database_manager.execute(
                "CREATE TABLE IF NOT EXISTS richest_title_state (k TEXT PRIMARY KEY, v TEXT)"
            )
            self.database_manager.execute(
                "INSERT OR IGNORE INTO richest_title_state (k, v) VALUES ('current_xuid', '')"
            )
        except Exception:
            pass

    def _load_current_richest_xuid_from_db(self) -> None:
        try:
            row = self.database_manager.query_one(
                "SELECT v FROM richest_title_state WHERE k = 'current_xuid'"
            )
            v = (row.get("v") if row else "") or ""
            v = str(v).strip()
            self.current_richest_xuid = v if v else None
        except Exception:
            self.current_richest_xuid = None

    def _save_current_richest_xuid_to_db(self, xuid: Optional[str]) -> None:
        try:
            v = (str(xuid).strip() if xuid else "")
            self.database_manager.execute(
                "UPDATE richest_title_state SET v = ? WHERE k = 'current_xuid'",
                (v,),
            )
        except Exception:
            pass

    def _query_current_richest_xuid(self) -> Optional[str]:
        """按配置决定是否隐藏 OP，然后查询财富榜第一名 xuid。"""
        try:
            if self.hide_op_in_money_ranking:
                row = self.database_manager.query_one(
                    "SELECT e.xuid, e.money "
                    "FROM player_economy e "
                    "LEFT JOIN player_basic_info b ON e.xuid = b.xuid "
                    "WHERE (b.is_op IS NULL OR b.is_op = 0) "
                    "ORDER BY e.money DESC LIMIT 1"
                )
            else:
                row = self.database_manager.query_one(
                    "SELECT xuid, money FROM player_economy ORDER BY money DESC LIMIT 1"
                )
            if not row or not row.get("xuid"):
                return None
            return str(row["xuid"]).strip()
        except Exception:
            return None

    def _update_richest_title_if_needed(self) -> None:
        """金钱变化后调用：首富变化才迁移头衔；不变化则不做任何事（含插件启动：禁止因 force 重复撤销同一首富）。"""
        richest_title_name = self._get_richest_title_name()
        if not richest_title_name:
            return

        self._ensure_richest_title_definition()
        new_richest_xuid = self._query_current_richest_xuid()
        old_richest_xuid = self.current_richest_xuid

        if new_richest_xuid == old_richest_xuid:
            return

        # 旧首富移除头衔（并取消佩戴）
        if old_richest_xuid:
            try:
                self.title_system.revoke_title_by_xuid(old_richest_xuid, richest_title_name)
                old_name = self.get_player_name_by_xuid(old_richest_xuid, return_with_title=False)
                if old_name:
                    old_online = self.server.get_player(old_name)
                    if old_online is not None:
                        self._update_player_name_tag(old_online)
            except Exception:
                pass

        # 新首富发放头衔（在线则走 api_unlock_title 以便自动佩戴逻辑；离线则仅写入解锁记录）
        if new_richest_xuid:
            try:
                new_name = self.get_player_name_by_xuid(new_richest_xuid, return_with_title=False)
                new_online = self.server.get_player(new_name) if new_name else None
                if new_online is not None:
                    self.api_unlock_title(new_online, richest_title_name)
                else:
                    _, _ = self.title_system.unlock_title_by_xuid(new_richest_xuid, richest_title_name)
            except Exception:
                pass

        self.current_richest_xuid = new_richest_xuid
        self._save_current_richest_xuid_to_db(new_richest_xuid)

    # Player basic info
    def _column_exists(self, table: str, column: str) -> bool:
        """
        检查表中是否存在指定列
        :param table: 表名
        :param column: 列名
        :return: 列是否存在
        """
        try:
            result = self.database_manager.query_one(f"PRAGMA table_info({table})")
            if not result:
                return False
            
            # PRAGMA table_info 返回所有列的信息
            columns_info = self.database_manager.query_all(f"PRAGMA table_info({table})")
            for col_info in columns_info:
                if col_info['name'] == column:
                    return True
            return False
        except Exception as e:
            # 在__init__期间不能使用self.logger，使用print代替
            print(f"[ARC Core]Check column exists error: {str(e)}")
            return False

    def _add_column_if_not_exists(self, table: str, column: str, column_type: str) -> bool:
        """
        如果列不存在则添加列
        :param table: 表名
        :param column: 列名
        :param column_type: 列类型定义
        :return: 是否成功
        """
        try:
            if not self._column_exists(table, column):
                sql = f"ALTER TABLE {table} ADD COLUMN {column} {column_type}"
                success = self.database_manager.execute(sql)
                if success:
                    # 在__init__期间不能使用self.logger，使用print代替
                    print(f"[ARC Core]Added column '{column}' to table '{table}'")
                else:
                    print(f"[ARC Core]Failed to add column '{column}' to table '{table}'")
                return success
            return True  # 列已存在，返回成功
        except Exception as e:
            # 在__init__期间不能使用self.logger，使用print代替
            print(f"[ARC Core]Add column error: {str(e)}")
            return False

    def _upgrade_player_basic_table(self) -> bool:
        """
        升级玩家基本信息表结构
        """
        try:
            success = True
            # 检查并添加 is_op 列
            if not self._add_column_if_not_exists('player_basic_info', 'is_op', 'INTEGER DEFAULT 0'):
                success = False
            
            # 检查并添加 remaining_free_land_blocks 列
            default_free_blocks = self.setting_manager.GetSetting('DEFAULT_FREE_LAND_BLOCKS') or '100'
            if not self._add_column_if_not_exists('player_basic_info', 'remaining_free_land_blocks', f'INTEGER DEFAULT {default_free_blocks}'):
                success = False

            # 检查并添加 inviter_xuid 列（邀请人 XUID，允许为空）
            if not self._add_column_if_not_exists('player_basic_info', 'inviter_xuid', 'TEXT'):
                success = False

            # 检查并添加 pending_invite_reward_times 列（待领取邀请奖励次数，默认为 0）
            if not self._add_column_if_not_exists('player_basic_info', 'pending_invite_reward_times', 'INTEGER DEFAULT 0'):
                success = False

            # 每日签到：上次签到日期（YYYY-MM-DD，空表示从未签到）
            if not self._add_column_if_not_exists('player_basic_info', 'last_checkin_date', 'TEXT'):
                success = False

            # 是否已完成进服自动佩戴最高稀有度头衔（0 否 1 是）
            if not self._add_column_if_not_exists('player_basic_info', 'default_title_auto_equipped', 'INTEGER DEFAULT 0'):
                success = False

            # 签到：累计次数、最近一次签到时刻（ISO，用于当日先后排序）
            if not self._add_column_if_not_exists('player_basic_info', 'total_checkin_count', 'INTEGER DEFAULT 0'):
                success = False
            if not self._add_column_if_not_exists('player_basic_info', 'last_checkin_at', 'TEXT'):
                success = False
            # 签到：连续签到天数（按自然日连续）
            if not self._add_column_if_not_exists('player_basic_info', 'continuous_checkin_days', 'INTEGER DEFAULT 0'):
                success = False
            
            return success
        except Exception as e:
            # 在__init__期间不能使用self.logger，使用print代替
            print(f"[ARC Core]Upgrade player basic table error: {str(e)}")
            return False

    def init_player_basic_table(self) -> bool:
        """初始化玩家基本信息表"""
        # 从配置文件获取默认免费领地格子数
        default_free_blocks = self.setting_manager.GetSetting('DEFAULT_FREE_LAND_BLOCKS') or '100'
        
        fields = {
            'uuid': 'TEXT PRIMARY KEY',  # 玩家UUID作为主键
            'xuid': 'TEXT NOT NULL',  # 玩家XUID
            'name': 'TEXT NOT NULL',  # 玩家名称
            'password': 'TEXT',  # 玩家密码(加密后的)，允许为NULL
            'is_op': 'INTEGER DEFAULT 0',  # 玩家是否为OP，默认为0(false)
            'remaining_free_land_blocks': f'INTEGER DEFAULT {default_free_blocks}',  # 剩余免费领地格子数
            'inviter_xuid': 'TEXT',  # 邀请人 XUID，允许为空
            'pending_invite_reward_times': 'INTEGER DEFAULT 0',  # 待领取邀请奖励次数
            'last_checkin_date': 'TEXT',  # 上次签到日期 YYYY-MM-DD
            'default_title_auto_equipped': 'INTEGER DEFAULT 0',  # 是否已做过进服自动佩戴头衔
            'total_checkin_count': 'INTEGER DEFAULT 0',  # 累计签到次数
            'last_checkin_at': 'TEXT',  # 最近一次签到时间 ISO8601
            'continuous_checkin_days': 'INTEGER DEFAULT 0'  # 连续签到天数
        }
        result = self.database_manager.create_table('player_basic_info', fields)
        
        # 对于已存在的表，执行升级操作
        if result:
            self._upgrade_player_basic_table()
        
        return result

    def _hash_password(self, password: str) -> str:
        """
        对密码进行加密
        :param password: 原始密码
        :return: 加密后的密码
        """
        # 使用SHA-256进行加密
        return hashlib.sha256(password.encode()).hexdigest()

    def init_player_basic_info(self, player: Player) -> bool:
        """
        初始化玩家基本信息
        :param player: 玩家对象
        :return: 是否初始化成功
        """
        try:
            # 获取默认免费领地格子数
            default_free_blocks = int(self.setting_manager.GetSetting('DEFAULT_FREE_LAND_BLOCKS') or '100')
            
            player_data = {
                'uuid': str(player.unique_id),
                'xuid': str(player.xuid),
                'name': player.name,
                'password': None,  # 初始密码为空
                'is_op': 1 if player.is_op else 0,  # 根据玩家当前OP状态设置
                'remaining_free_land_blocks': default_free_blocks,  # 设置默认免费格子数
                'inviter_xuid': None,  # 初始无邀请人
                'pending_invite_reward_times': 0,  # 初始无待领取邀请奖励
                'default_title_auto_equipped': 0,
                'total_checkin_count': 0,
                'continuous_checkin_days': 0,
            }
            return self.database_manager.insert('player_basic_info', player_data)
        except Exception as e:
            self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Init player basic info error: {str(e)}")
            return False

    def init_player_economy_info(self, player: Player) -> bool:
        """初始化玩家经济信息（委托 Economy）"""
        return self.economy.init_player_economy_by_xuid(str(player.xuid))

    def ensure_player_data_initialized(self, player: Player) -> tuple[bool, bool]:
        """
        确保玩家数据已完全初始化（基本信息和经济数据）
        :param player: 玩家对象
        :return: (是否初始化成功, 是否为新玩家)
        """
        try:
            player_xuid = str(player.xuid)
            success = True
            is_new_player = False

            # 检查并初始化玩家基本信息（使用XUID作为主键）
            basic_info = self.database_manager.query_one(
                "SELECT xuid FROM player_basic_info WHERE xuid = ?",
                (player_xuid,)
            )
            if not basic_info:
                is_new_player = True  # 没有基本信息说明是新玩家
                if not self.init_player_basic_info(player):
                    self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Failed to init basic info for player {player.name}")
                    success = False
                else:
                    self._safe_log('info', f"{ColorFormat.GREEN}[ARC Core]Initialized basic info for new player {player.name}")

            # 更新玩家名称（如果发生变化）
            self.update_player_name(player)

            # 更新玩家OP状态
            self.update_player_op_status(player)

            # 检查并初始化玩家经济信息
            if not self.init_player_economy_info(player):
                self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Failed to init economy info for player {player.name}")
                success = False
            else:
                # 获取初始化后的金钱数量用于日志
                money = self.get_player_money(player)
                if is_new_player:
                    self._safe_log('info', f"{ColorFormat.GREEN}[ARC Core]Initialized economy data for new player {player.name}, balance: {money}")
                else:
                    self._safe_log('info', f"{ColorFormat.GREEN}[ARC Core]Ensured economy data for player {player.name}, balance: {money}")

            return success, is_new_player
        except Exception as e:
            self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Ensure player data initialized error: {str(e)}")
            return False, False

    def get_player_basic_info(self, player: Player) -> Optional[Dict[str, Any]]:
        """
        获取玩家基本信息
        :param player: 玩家对象
        :return: 玩家信息字典或None(如果发生错误)
        """
        try:
            result = self.database_manager.query_one(
                "SELECT * FROM player_basic_info WHERE xuid = ?",
                (str(player.xuid),)
            )
            if result is None:
                # 玩家第一次进入服务器，初始化信息
                if self.init_player_basic_info(player):
                    return {
                        'uuid': str(player.unique_id),
                        'xuid': str(player.xuid),
                        'name': player.name,
                        'password': None,
                        'default_title_auto_equipped': 0
                    }
                return None
            return result
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Get player basic info error: {str(e)}")
            return None

    def set_player_password(self, player: Player, password: str) -> bool:
        """
        设置玩家密码
        :param player: 玩家对象
        :param password: 原始密码
        :return: 是否设置成功
        """
        try:
            hashed_password = self._hash_password(password)
            return self.database_manager.update(
                table='player_basic_info',
                data={'password': hashed_password},
                where='xuid = ?',
                params=(str(player.xuid),)
            )
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Set player password error: {str(e)}")
            return False

    def verify_player_password(self, player: Player, password: str) -> bool:
        """
        验证玩家密码
        :param player: 玩家对象
        :param password: 待验证的密码
        :return: 密码是否正确
        """
        try:
            result = self.database_manager.query_one(
                "SELECT password FROM player_basic_info WHERE xuid = ?",
                (str(player.xuid),)
            )
            if not result or not result['password']:
                return False
            return result['password'] == self._hash_password(password)
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Verify player password error: {str(e)}")
            return False

    def update_player_name(self, player: Player) -> bool:
        """
        更新玩家名称（如果发生变化）
        :param player: 玩家对象
        :return: 是否需要更新以及更新是否成功
        """
        try:
            current_info = self.database_manager.query_one(
                "SELECT name FROM player_basic_info WHERE xuid = ?",
                (str(player.xuid),)
            )

            if not current_info:
                return False

            if current_info['name'] != player.name:
                # 名称发生变化，需要更新
                success = self.database_manager.update(
                    table='player_basic_info',
                    data={'name': player.name},
                    where='xuid = ?',
                    params=(str(player.xuid),)
                )
                if success:
                    self._safe_log('info', f"Player {current_info['name']} changed name to {player.name}")
                return success

            return True  # 名称没有变化，视为成功
        except Exception as e:
            self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Update player name error: {str(e)}")
            return False

    def update_player_op_status(self, player: Player) -> bool:
        """
        更新玩家OP状态
        :param player: 玩家对象
        :return: 是否更新成功
        """
        try:
            current_op_status = 1 if player.is_op else 0
            
            # 检查当前数据库中的OP状态
            current_info = self.database_manager.query_one(
                "SELECT is_op FROM player_basic_info WHERE xuid = ?",
                (str(player.xuid),)
            )
            
            if current_info is not None:
                stored_op_status = current_info.get('is_op', 0)
                if stored_op_status != current_op_status:
                    # OP状态发生变化，更新数据库
                    success = self.database_manager.update(
                        table='player_basic_info',
                        data={'is_op': current_op_status},
                        where='xuid = ?',
                        params=(str(player.xuid),)
                    )
                    if success:
                        status_text = "OP" if current_op_status else "非OP"
                        self._safe_log('info', f"{ColorFormat.GREEN}[ARC Core]Updated player OP status: {player.name} -> {status_text}")
                    return success
            return True  # 状态未变化或记录不存在，返回成功
        except Exception as e:
            self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Update player OP status error: {str(e)}")
            return False

    def get_offline_player_op_status(self, player_name: str) -> Optional[bool]:
        """
        获取离线玩家的OP状态
        :param player_name: 玩家名称
        :return: OP状态，如果玩家不存在则返回None
        """
        try:
            player_xuid = self.get_player_xuid_by_name(player_name)
            if not player_xuid:
                return None
            return self.get_offline_player_op_status_by_xuid(player_xuid)
        except Exception as e:
            self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Get offline player OP status error: {str(e)}")
            return None

    def get_offline_player_op_status_by_xuid(self, player_xuid: str) -> Optional[bool]:
        """
        通过XUID获取离线玩家的OP状态
        :param player_xuid: 玩家XUID
        :return: OP状态，如果玩家不存在则返回None
        """
        try:
            result = self.database_manager.query_one(
                "SELECT is_op FROM player_basic_info WHERE xuid = ?",
                (player_xuid,)
            )
            if result is not None:
                return bool(result['is_op'])
            return None
        except Exception as e:
            self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Get offline player OP status by XUID error: {str(e)}")
            return None

    def get_offline_player_op_status_by_uuid(self, player_uuid: str) -> Optional[bool]:
        """
        通过UUID获取离线玩家的OP状态 (兼容性方法, 建议使用get_offline_player_op_status_by_xuid)
        :param player_uuid: 玩家UUID
        :return: OP状态，如果玩家不存在则返回None
        """
        try:
            result = self.database_manager.query_one(
                "SELECT is_op FROM player_basic_info WHERE uuid = ?",
                (player_uuid,)
            )
            if result is not None:
                return bool(result['is_op'])
            return None
        except Exception as e:
            self._safe_log('error', f"{ColorFormat.RED}[ARC Core]Get offline player OP status by UUID error: {str(e)}")
            return None

    def get_player_name_by_xuid(
        self, player_xuid: str, return_with_title: bool = True
    ) -> Optional[str]:
        """
        通过 XUID 获取玩家名称。
        :param player_xuid: 玩家 XUID
        :param return_with_title: 为 True（默认）时返回展示名：§白[无公会]§r 或 §普通色[公会名]§r，再接 [头衔]§r 与名字（与聊天、头顶名一致）；为 False 时返回库中裸名，适合指令参数等。
        """
        try:
            result = self.database_manager.query_one(
                "SELECT name FROM player_basic_info WHERE xuid = ?",
                (player_xuid,),
            )
            if not result or result.get("name") is None:
                return None
            raw = str(result["name"]).strip()
            if not raw:
                return None
            if not return_with_title:
                return raw
            try:
                equipped = self.title_system.get_equipped_title_by_xuid(str(player_xuid).strip())
            except Exception:
                equipped = None
            return self.format_player_display_label_with_guild(
                raw, equipped, str(player_xuid).strip()
            )
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Get player name by XUID error: {str(e)}")
            return None

    def format_player_display_label_with_guild(
        self,
        raw_player_name: str,
        equipped_title: Optional[str],
        xuid: str,
    ) -> str:
        """
        展示用：§白[无公会]§r 或 §普通色[公会名]§r，再接 [头衔]§r，最后为游戏名。
        与聊天、头顶 name_tag、死亡播报及 get_player_name_by_xuid(..., True) 保持一致。
        """
        name = (raw_player_name or "").strip() or "?"
        xs = str(xuid or "").strip()
        no_guild_label = self.language_manager.GetText("GUILD_DISPLAY_NO_GUILD_SHORT")
        if no_guild_label is None or not str(no_guild_label).strip():
            no_guild_label = "[无公会]"
        else:
            no_guild_label = str(no_guild_label).strip()
        guild_prefix = ""
        try:
            if xs and getattr(self, "guild_system", None):
                mem = self.guild_system.get_membership(xs)
                if mem:
                    g = self.guild_system.get_guild(int(mem["guild_id"]))
                    if g and g.get("name"):
                        gc = self.title_system.get_normal_rarity_color()
                        gname = str(g["name"]).strip()
                        if gname:
                            guild_prefix = f"{gc}[{gname}]§r"
        except Exception:
            guild_prefix = ""
        if not guild_prefix:
            guild_prefix = f"§f{no_guild_label}§r"
        et = (equipped_title or "").strip() if equipped_title else ""
        if et:
            tc = self.title_system.get_title_rarity_color(et)
            title_part = f"{tc}[{et}]§r"
        else:
            title_part = ""
        return guild_prefix + title_part + name

    def _refresh_player_name_tag_by_xuid(self, xuid: Optional[str]) -> None:
        if not xuid:
            return
        p = self._find_online_player_by_xuid(str(xuid).strip())
        if p:
            self._update_player_name_tag(p)

    def get_player_xuid_by_name(self, player_name: str) -> Optional[str]:
        """
        通过玩家名称获取 XUID。
        使用在线玩家列表 + 大小写不敏感、去空白的 DB 查询，避免 name 与调用方字符串仅差大小写/空格时查不到。
        """
        if player_name is None:
            return None
        normalized_name = str(player_name).strip()
        if not normalized_name:
            return None
        try:
            # 1) 在线玩家优先：与运行时 player.name 一致，可规避 DB 未及时同步或第三方传入名与库不完全一致
            server = getattr(self, "server", None)
            if server is not None:
                try:
                    online_players = server.online_players
                    if online_players:
                        key_lower = normalized_name.lower()
                        for online_player in online_players:
                            on_name = (online_player.name or "").strip()
                            if on_name.lower() == key_lower:
                                return str(online_player.xuid)
                except Exception:
                    pass
            # 2) 数据库：TRIM + 大小写不敏感（SQLite 默认 BINARY 下 name = ? 对英文大小写敏感）
            result = self.database_manager.query_one(
                "SELECT xuid FROM player_basic_info WHERE LOWER(TRIM(name)) = LOWER(?)",
                (normalized_name,),
            )
            if not result or result.get("xuid") is None:
                return None
            return str(result["xuid"])
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Get player XUID by name error: {str(e)}")
            return None

    def _rank_display_name_from_row(self, row: Dict[str, Any]) -> str:
        """排行榜等展示用：row 含 xuid、name 时优先返回带头衔的展示名。"""
        xuid_s = str(row.get("xuid") or "").strip()
        raw = (row.get("name") or "?").strip() or "?"
        if not xuid_s:
            return raw
        labeled = self.get_player_name_by_xuid(xuid_s, return_with_title=True)
        return labeled if labeled else raw

    # Spawn protect
    def init_spawn_locations_table(self) -> bool:
        """初始化出生点表格"""
        fields = {
            'dimension': 'TEXT PRIMARY KEY',  # 维度名称作为主键
            'spawn_x': 'INTEGER NOT NULL',
            'spawn_y': 'INTEGER NOT NULL',
            'spawn_z': 'INTEGER NOT NULL'
        }
        return self.database_manager.create_table('spawn_locations', fields)

    def init_small_horn_orders_table(self) -> bool:
        """初始化小喇叭订单表。"""
        fields = {
            'id': 'INTEGER PRIMARY KEY AUTOINCREMENT',
            'xuid': 'TEXT NOT NULL',
            'content': 'TEXT NOT NULL',
            'start_time': 'TEXT NOT NULL',
            'valid_hours': 'INTEGER NOT NULL',
            'end_time': 'TEXT NOT NULL',
            'created_at': 'TEXT NOT NULL',
        }
        return self.database_manager.create_table('small_horn_orders', fields)

    def init_cross_server_table(self) -> bool:
        """初始化跨服传送目标表。"""
        fields = {
            'id': 'INTEGER PRIMARY KEY AUTOINCREMENT',
            'server_name': 'TEXT NOT NULL',
            'server_host': 'TEXT NOT NULL',
            'server_port': 'INTEGER NOT NULL',
            'created_at': 'TEXT NOT NULL',
        }
        return self.database_manager.create_table('cross_server_targets', fields)

    def update_spawn_location(self, dimension: str, coordinates: tuple) -> bool:
        """
        更新出生地信息
        :param db: 数据库管理器
        :param dimension: 维度名称
        :param coordinates: (x, y, z) 坐标元组
        :return: 是否更新成功
        """
        x, y, z = coordinates
        data = {
            'spawn_x': x,
            'spawn_y': y,
            'spawn_z': z
        }

        existing = self.database_manager.query_one("SELECT * FROM spawn_locations WHERE dimension = ?", (dimension,))

        if existing:
            return self.database_manager.update('spawn_locations', data, 'dimension = ?', (dimension,))
        else:
            data['dimension'] = dimension
            return self.database_manager.insert('spawn_locations', data)

    def get_all_spawn_locations(self) -> Dict[str, tuple]:
        """
        获取所有出生地信息
        :return: 字典，键为维度名称，值为坐标元组(x, y, z)
        """
        result = self.database_manager.query_all("SELECT * FROM spawn_locations")
        return {
            row['dimension']: (row['spawn_x'], row['spawn_y'], row['spawn_z'])
            for row in result
        }

    def spawn_protect_check(self, dimension_name: str, pos_x: float, pos_z: float) -> bool:
        if dimension_name in self.spawn_pos_dict:
            if math.fabs(pos_x - self.spawn_pos_dict[dimension_name][0]) <= self.spawn_protect_range and \
                    math.fabs(pos_z - self.spawn_pos_dict[dimension_name][2]) <= self.spawn_protect_range:
                return False
        return True

    # UI Main menu
    def show_main_menu(self, player: Player):
        if not self.if_player_logined(player):
            player_basic_info = self.get_player_basic_info(player)
            if player_basic_info is None:
                self.report_arc_error(
                    "INFO0",
                    f"show_main_menu (pre-login) get_player_basic_info returned None player={player.name!r}",
                    player,
                )
                return
            self.update_player_name(player)
            if player_basic_info['password'] is None:
                self.show_register_panel(player)
            else:
                self.show_login_panel(player)
        else:
            arc_menu = ActionForm(
                title=self.language_manager.GetText('MAIN_MENU_TITLE'),
            )
            arc_menu.add_button(self.language_manager.GetText('NEWBIE_GUIDE_BUTTON'), on_click=self.show_newbie_welcome_panel)
            arc_menu.add_button(self.language_manager.GetText('TELEPORT_MENU_NAME'), on_click=self.show_teleport_menu)
            arc_menu.add_button(self.language_manager.GetText('LAND_MENU_NAME'), on_click=self.show_land_main_menu)
            arc_menu.add_button(self.language_manager.GetText('BANK_MENU_NAME'), on_click=self.show_bank_main_menu)
            arc_menu.add_button(self.language_manager.GetText('GUILD_MENU_NAME'), on_click=self.show_guild_main_menu)
            arc_menu.add_button(self.language_manager.GetText('CHECKIN_MENU_BUTTON'), on_click=self.show_daily_checkin_panel)
            arc_menu.add_button(self.language_manager.GetText('MAIN_MENU_MY_INFO_NAME'), on_click=self.show_my_info_panel)
            arc_menu.add_button(self.language_manager.GetText('MAIN_MENU_TOOLS_BUTTON'), on_click=self.show_arc_tools_menu)
            if self.server.plugin_manager.get_plugin('ushop'):
                arc_menu.add_button(self.language_manager.GetText('SHOP_MENU_NAME'), on_click=self.show_shop_menu)
            if self.server.plugin_manager.get_plugin('arc_button_shop'):
                arc_menu.add_button(self.language_manager.GetText('BUTTON_SHOP_MENU_NAME'), on_click=self.show_button_shop_menu)
            if self.server.plugin_manager.get_plugin('arc_dtwt'):
                arc_menu.add_button(self.language_manager.GetText('DTWT_MENU_NAME'), on_click=self.show_dtwt_panel)
            if self.server.plugin_manager.get_plugin('up_and_down'):
                arc_menu.add_button(self.language_manager.GetText('STOCK_MARKET_NAME'), on_click=self.show_stock_ui)
            if player.is_op:
                arc_menu.add_button(self.language_manager.GetText('OP_PANEL_NAME'), on_click=self.show_op_main_panel)
            arc_menu.on_close = None
            player.send_form(arc_menu)

    def show_arc_tools_menu(self, player: Player):
        """小喇叭、重生等快捷功能入口。"""
        tools_form = ActionForm(
            title=self.language_manager.GetText("MAIN_MENU_TOOLS_TITLE"),
            content=self.language_manager.GetText("MAIN_MENU_TOOLS_CONTENT"),
            on_close=self.show_main_menu,
        )
        tools_form.add_button(
            self.language_manager.GetText("SMALL_HORN_MENU_BUTTON"),
            on_click=lambda p: self.show_small_horn_buy_panel(p, on_panel_close=self.show_arc_tools_menu),
        )
        tools_form.add_button(self.language_manager.GetText("SUICIDE_FUNC_BUTTON"), on_click=self.execute_suicide)
        tools_form.add_button(self.language_manager.GetText("RETURN_BUTTON_TEXT"), on_click=self.show_main_menu)
        player.send_form(tools_form)

    def execute_suicide(self, player: Player):
        player.perform_command('suicide')

    def show_newbie_welcome_panel(self, player: Player):
        """显示新手引导面板，内容来自 newbie_welcome.txt"""
        try:
            if self.newbie_welcome_file.exists():
                welcome_content = self.newbie_welcome_file.read_text(encoding='utf-8')
            else:
                welcome_content = self.language_manager.GetText('NEWBIE_GUIDE_PANEL_TITLE') + "\n\n（引导文件暂未配置）"
        except Exception:
            welcome_content = self.language_manager.GetText('NEWBIE_GUIDE_PANEL_TITLE') + "\n\n（读取引导内容失败）"
        newbie_form = ActionForm(
            title=self.language_manager.GetText('NEWBIE_GUIDE_PANEL_TITLE'),
            content=welcome_content,
            on_close=self.show_main_menu
        )
        newbie_form.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_main_menu
        )
        player.send_form(newbie_form)

    # Player info & invite system UI
    def show_my_info_panel(self, player: Player):
        """显示玩家自己的信息面板"""
        player_basic_info = self.get_player_basic_info(player)
        if player_basic_info is None:
            self.report_arc_error(
                "INFO1",
                f"show_my_info_panel get_player_basic_info returned None player={player.name!r}",
                player,
            )
            return

        player_name = player.name
        player_xuid = str(player.xuid)
        player_money = self.get_player_money(player)
        player_land_count = self.get_player_land_count(player_xuid)
        remaining_free_blocks = self.get_player_free_land_blocks(player)

        inviter_xuid = player_basic_info.get('inviter_xuid')
        if inviter_xuid:
            inviter_name = self.get_player_name_by_xuid(inviter_xuid) or inviter_xuid
        else:
            inviter_name = self.language_manager.GetText('INVITER_NONE_TEXT')

        pending_info = self.database_manager.query_one(
            "SELECT pending_invite_reward_times FROM player_basic_info WHERE xuid = ?",
            (player_xuid,)
        )
        pending_times = 0
        if pending_info is not None:
            try:
                pending_times = int(pending_info.get('pending_invite_reward_times', 0) or 0)
            except (ValueError, TypeError):
                pending_times = 0

        info_content = self.language_manager.GetText('MY_INFO_PANEL_CONTENT').format(
            player_name,
            player_xuid,
            self._format_money_display(player_money),
            player_land_count,
            remaining_free_blocks,
            inviter_name,
            pending_times
        )

        my_info_panel = ActionForm(
            title=self.language_manager.GetText('MY_INFO_PANEL_TITLE'),
            content=info_content,
            on_close=self.show_main_menu
        )

        # 未填写邀请人时显示“填写邀请人”按钮
        if not inviter_xuid:
            my_info_panel.add_button(
                self.language_manager.GetText('MY_INFO_FILL_INVITER_BUTTON'),
                on_click=self.show_fill_inviter_panel
            )

        # 有待领取邀请奖励时显示“领取邀请奖励”按钮
        if pending_times > 0:
            my_info_panel.add_button(
                self.language_manager.GetText('MY_INFO_CLAIM_INVITE_REWARD_BUTTON'),
                on_click=self.claim_invite_rewards
            )

        # 头衔管理
        my_info_panel.add_button(
            self.language_manager.GetText('TITLE_MANAGE_BUTTON'),
            on_click=self.show_title_manage_panel
        )

        # 我的成就
        my_info_panel.add_button(
            self.language_manager.GetText('MY_ACHIEVEMENTS_BUTTON'),
            on_click=self.show_my_achievements_hub
        )

        # 返回主菜单
        my_info_panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_main_menu
        )

        player.send_form(my_info_panel)

    def show_my_achievements_hub(self, player: Player):
        """我的成就：已解锁 / 未解锁。"""
        panel = ActionForm(
            title=self.language_manager.GetText('MY_ACHIEVEMENTS_HUB_TITLE'),
            content=self.language_manager.GetText('MY_ACHIEVEMENTS_HUB_CONTENT'),
            on_close=self.show_my_info_panel,
        )
        panel.add_button(
            self.language_manager.GetText('MY_ACHIEVEMENTS_UNLOCKED_LIST_BUTTON'),
            on_click=self.show_my_achievements_unlocked_list,
        )
        panel.add_button(
            self.language_manager.GetText('MY_ACHIEVEMENTS_LOCKED_LIST_BUTTON'),
            on_click=self.show_my_achievements_locked_list,
        )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_my_info_panel,
        )
        player.send_form(panel)

    def show_my_achievements_unlocked_list(self, player: Player):
        rows = self.achievement_system.list_unlocked_achievements_for_player_ui(str(player.xuid))
        panel = ActionForm(
            title=self.language_manager.GetText('MY_ACHIEVEMENTS_UNLOCKED_TITLE'),
            content=self.language_manager.GetText('MY_ACHIEVEMENTS_UNLOCKED_CONTENT'),
            on_close=self.show_my_achievements_hub,
        )
        for achievement_row in rows:
            unlock_title = str(achievement_row.get("unlock_title") or "").strip()
            name = str(achievement_row.get("name") or unlock_title).strip()
            enabled = bool(achievement_row.get("enabled", True))
            if_hidden = bool(achievement_row.get("if_hidden", False))
            hidden_tag = self.language_manager.GetText('MY_ACHIEVEMENTS_TAG_HIDDEN') if if_hidden else ""
            status = self.language_manager.GetText('MY_ACHIEVEMENTS_STATUS_UNLOCKED')
            disabled_tag = "" if enabled else self.language_manager.GetText('MY_ACHIEVEMENTS_TAG_DISABLED')
            label = self.language_manager.GetText('MY_ACHIEVEMENTS_BUTTON_LABEL').format(
                name,
                unlock_title,
                hidden_tag + disabled_tag + status,
            )
            panel.add_button(
                label,
                on_click=lambda p, ut=unlock_title: self.show_my_achievement_detail(p, ut, "unlocked"),
            )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_my_achievements_hub,
        )
        player.send_form(panel)

    def show_my_achievements_locked_list(self, player: Player):
        rows = self.achievement_system.list_locked_achievements_for_player_ui(str(player.xuid))
        panel = ActionForm(
            title=self.language_manager.GetText('MY_ACHIEVEMENTS_LOCKED_TITLE'),
            content=self.language_manager.GetText('MY_ACHIEVEMENTS_LOCKED_CONTENT'),
            on_close=self.show_my_achievements_hub,
        )
        for achievement_row in rows:
            unlock_title = str(achievement_row.get("unlock_title") or "").strip()
            name = str(achievement_row.get("name") or unlock_title).strip()
            enabled = bool(achievement_row.get("enabled", True))
            status = self.language_manager.GetText('MY_ACHIEVEMENTS_STATUS_LOCKED')
            disabled_tag = "" if enabled else self.language_manager.GetText('MY_ACHIEVEMENTS_TAG_DISABLED')
            label = self.language_manager.GetText('MY_ACHIEVEMENTS_BUTTON_LABEL').format(
                name,
                unlock_title,
                disabled_tag + status,
            )
            panel.add_button(
                label,
                on_click=lambda p, ut=unlock_title: self.show_my_achievement_detail(p, ut, "locked"),
            )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_my_achievements_hub,
        )
        player.send_form(panel)

    def _achievement_entity_label_for_player(self, entity_type_id: str) -> str:
        raw = str(entity_type_id or "").strip()
        if raw == "*":
            return self.language_manager.GetText('ACHIEVEMENT_ENTITY_ANY_LABEL')
        return self.entity_display_name_manager.get_display_name_or_identifier(raw)

    def _format_player_achievement_condition_line(self, condition_data: dict) -> str:
        if not isinstance(condition_data, dict):
            return ""
        achievement_system = self.achievement_system
        ct = str(condition_data.get("condition_type") or condition_data.get("type") or "").strip()
        try:
            req = int(condition_data.get("required_count") or 0)
        except (TypeError, ValueError):
            req = 0
        if ct == achievement_system.condition_type_kill_entity_sum:
            target_ids = achievement_system._normalize_target_ids_list(condition_data.get("target_ids"))
            labels = [self._achievement_entity_label_for_player(x) for x in target_ids if str(x).strip()]
            sep = self.language_manager.GetText('ACHIEVEMENT_CONDITION_NAME_LIST_SEP')
            joined = sep.join(labels)
            return self.language_manager.GetText('ACHIEVEMENT_CONDITION_KILL_SUM').format(req, joined)
        if ct == achievement_system.condition_type_kill_entity:
            tid = str(condition_data.get("target_id") or "").strip()
            if tid == "*":
                return self.language_manager.GetText('ACHIEVEMENT_CONDITION_KILL_ANY').format(req)
            label = self._achievement_entity_label_for_player(tid)
            return self.language_manager.GetText('ACHIEVEMENT_CONDITION_KILL_ONE').format(label, req)
        return self.language_manager.GetText('ACHIEVEMENT_CONDITION_UNKNOWN').format(ct, req)

    def _build_my_achievement_detail_body(
        self,
        achievement_data: dict,
        is_unlocked: bool,
    ) -> str:
        name = str(achievement_data.get("name") or "").strip()
        unlock_title = str(achievement_data.get("unlock_title") or "").strip()
        enabled = bool(achievement_data.get("enabled", True))
        if_hidden = bool(achievement_data.get("if_hidden", False))
        lines = []
        lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_LINE_NAME').format(name))
        lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_LINE_UNLOCK_TITLE').format(unlock_title))
        if if_hidden:
            lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_LINE_HIDDEN_TAG'))
        st_key = (
            'ACHIEVEMENT_DETAIL_STATUS_UNLOCKED_LINE'
            if is_unlocked
            else 'ACHIEVEMENT_DETAIL_STATUS_LOCKED_LINE'
        )
        lines.append(self.language_manager.GetText(st_key))
        if not enabled:
            lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_DISABLED_LINE'))
        lines.append("")
        lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_CONDITIONS_HEADER'))
        cond_list = achievement_data.get("conditions") or []
        if not cond_list:
            lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_NO_CONDITIONS'))
        else:
            idx = 1
            for cond in cond_list:
                line = self._format_player_achievement_condition_line(cond)
                lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_CONDITION_BULLET').format(idx, line))
                idx += 1
        defn = self.title_system.get_title_definition(unlock_title)
        if defn:
            rarity = str(defn.get("rarity") or "").strip()
            desc = str(defn.get("description") or "").strip()
            reward_money = defn.get("reward_money")
            if rarity:
                lines.append("")
                lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_LINE_RARITY').format(rarity))
            if desc:
                lines.append(self.language_manager.GetText('ACHIEVEMENT_DETAIL_LINE_DESC').format(desc))
            try:
                rm = float(reward_money or 0)
                if rm > 0:
                    lines.append(
                        self.language_manager.GetText('ACHIEVEMENT_DETAIL_LINE_REWARD_MONEY').format(
                            self._format_money_display(rm)
                        )
                    )
            except (TypeError, ValueError):
                pass
        return "\n".join(lines)

    def show_my_achievement_detail(self, player: Player, unlock_title: str, return_mode: str):
        achievement_row = self.achievement_system.get_achievement(unlock_title)
        if not achievement_row:
            player.send_message(self.language_manager.GetText('MY_ACHIEVEMENT_NOT_FOUND'))
            if return_mode == "locked":
                return self.show_my_achievements_locked_list(player)
            return self.show_my_achievements_unlocked_list(player)

        is_unlocked = self.achievement_system.player_has_unlocked_title(str(player.xuid), unlock_title)
        body = self._build_my_achievement_detail_body(achievement_row, is_unlocked)
        back_cb = (
            self.show_my_achievements_locked_list
            if return_mode == "locked"
            else self.show_my_achievements_unlocked_list
        )
        panel = ActionForm(
            title=self.language_manager.GetText('MY_ACHIEVEMENT_DETAIL_TITLE').format(
                str(achievement_row.get("name") or unlock_title).strip()
            ),
            content=body,
            on_close=back_cb,
        )
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=back_cb)
        player.send_form(panel)

    def show_title_manage_panel(self, player: Player):
        """头衔管理：选择佩戴的头衔或取消佩戴"""
        unlocked = self.title_system.get_unlocked_titles(player)
        equipped = self.title_system.get_equipped_title(player)
        equipped_display = equipped if equipped else self.language_manager.GetText('TITLE_NONE')
        content = self.language_manager.GetText('TITLE_MANAGE_CONTENT').format(equipped_display)
        panel = ActionForm(
            title=self.language_manager.GetText('TITLE_MANAGE_TITLE'),
            content=content,
            on_close=self.show_my_info_panel
        )
        panel.add_button(self.language_manager.GetText('TITLE_UNEQUIP_BUTTON'), on_click=lambda p: self._title_set_equipped_and_back(p, None))
        for t in unlocked:
            label = self._format_title_button_label(t, t == equipped)
            panel.add_button(label, on_click=lambda pl, title=t: self._title_set_equipped_and_back(pl, title))
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_my_info_panel)
        player.send_form(panel)

    def _format_title_button_label(self, title_name: str, is_equipped: bool) -> str:
        """头衔按钮两行显示：第一行名称（按稀有度颜色+加粗），第二行介绍（若有）。"""
        color = self.title_system.get_title_rarity_color(title_name)
        defn = self.title_system.get_title_definition(title_name)
        desc = (defn.get("description") or "").strip() if defn else ""
        prefix = ("§a" + self.language_manager.GetText('TITLE_EQUIPPED_CURRENT').format("") + "§r ") if is_equipped else ""
        line1 = prefix + "§l" + color + title_name + "§r"
        if desc:
            return line1 + "\n§r§f" + desc
        return line1

    def _auto_equip_highest_title_if_needed(self, player: Player) -> None:
        """进服一次：若未标记完成且当前未佩戴，则佩戴已解锁中稀有度最高的头衔并写标记；已有佩戴则仅同步标记。"""
        try:
            player_xuid = str(player.xuid)
            row = self.database_manager.query_one(
                "SELECT default_title_auto_equipped FROM player_basic_info WHERE xuid = ?",
                (player_xuid,),
            )
            if row is None:
                return
            try:
                flag = int(row.get("default_title_auto_equipped", 0) or 0)
            except (ValueError, TypeError):
                flag = 0
            if flag != 0:
                return
            equipped = self.title_system.get_equipped_title(player)
            if equipped:
                self.database_manager.update(
                    table="player_basic_info",
                    data={"default_title_auto_equipped": 1},
                    where="xuid = ?",
                    params=(player_xuid,),
                )
                return
            unlocked = self.title_system.get_unlocked_titles(player)
            if not unlocked:
                return
            best_title = self.title_system.pick_highest_rarity_title(unlocked)
            if not best_title:
                return
            if not self.title_system.set_equipped_title(player, best_title):
                return
            self.database_manager.update(
                table="player_basic_info",
                data={"default_title_auto_equipped": 1},
                where="xuid = ?",
                params=(player_xuid,),
            )
        except Exception as e:
            if self.logger:
                self.logger.error(f"{ColorFormat.RED}[ARC Core]Auto equip title on join error: {str(e)}")

    def _update_player_name_tag(self, player: Player) -> None:
        """将玩家 name_tag 设为 [公会][头衔]名字（与聊天、接口展示一致）。"""
        try:
            equipped = self.title_system.get_equipped_title(player)
            name = player.name or ""
            xuid = str(player.xuid)
            player.name_tag = self.format_player_display_label_with_guild(
                name, equipped, xuid
            )
        except Exception as e:
            if self.logger:
                self.logger.error(f"[ARC Core]Update player name_tag error: {str(e)}")

    def _title_set_equipped_and_back(self, player: Player, title: Optional[str]):
        if title is None:
            self.title_system.set_equipped_title(player, None)
        else:
            self.title_system.set_equipped_title(player, title)
        self._update_player_name_tag(player)
        self.show_title_manage_panel(player)

    def api_unlock_title(self, player: Player, title: str) -> bool:
        """供其他插件调用的接口：为玩家解锁头衔，并发放解锁奖励（若在线）。"""
        equipped_before = None
        try:
            equipped_before = self.title_system.get_equipped_title(player)
        except Exception:
            equipped_before = None
        unlock_ok, was_new_unlock = self.title_system.unlock_title(player, title)
        if not unlock_ok:
            return False
        if was_new_unlock:
            self._grant_title_unlock_reward(player, title)
            # 若玩家当前未佩戴任何头衔，则自动佩戴刚解锁的头衔
            if not equipped_before:
                try:
                    self.title_system.set_equipped_title(player, title)
                    self._update_player_name_tag(player)
                except Exception:
                    pass
        return True

    def api_get_newbie_guide_text(self) -> str:
        """供其他插件调用：返回新手引导文本全文（与 `plugins/ARCCore/newbie_welcome.txt`、主菜单新手引导一致）。"""
        try:
            if self.newbie_welcome_file.exists():
                raw_text = self.newbie_welcome_file.read_text(encoding="utf-8")
                return raw_text.strip() if raw_text else ""
        except Exception:
            pass
        return ""

    def _grant_title_unlock_reward(self, player: Player, title: str) -> None:
        """若头衔定义中有解锁奖励，则给该玩家发放金钱与物品（仅当玩家在线时）。"""
        defn = self.title_system.get_title_definition(title)
        if not defn:
            return
        money = defn.get("reward_money") or 0
        if money > 0:
            try:
                self.increase_player_money(player, money)
            except Exception:
                pass
        items = defn.get("reward_items") or []
        for it in items:
            item_name = it.get("item_name") or it.get("id") or ""
            count = int(it.get("count", 1))
            if item_name and count > 0:
                try:
                    self.server.dispatch_command(self.server.command_sender, f"give {player.name} {item_name} {count}")
                except Exception:
                    pass

    def show_fill_inviter_panel(self, player: Player, hint_message: Optional[str] = None):
        """显示填写邀请人面板"""
        panel_title = self.language_manager.GetText('FILL_INVITER_PANEL_TITLE') if hint_message is None else hint_message

        inviter_input = TextInput(
            label=self.language_manager.GetText('FILL_INVITER_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('FILL_INVITER_INPUT_PLACEHOLDER')
        )

        def try_set_inviter(player: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception as parse_exc:
                self.report_arc_error(
                    "INV1",
                    "fill_inviter json.loads failed",
                    player,
                    exception=parse_exc,
                )
                self.show_fill_inviter_panel(player, self.language_manager.GetText('FILL_INVITER_FAIL_SYSTEM_ERROR'))
                return

            if len(data) == 0 or not str(data[0]).strip():
                self.show_fill_inviter_panel(player, self.language_manager.GetText('FILL_INVITER_FAIL_PLAYER_NOT_FOUND'))
                return

            inviter_name_input = str(data[0]).strip()
            player_xuid = str(player.xuid)

            # 再次检查自己是否已经填写过邀请人
            basic_info = self.database_manager.query_one(
                "SELECT inviter_xuid FROM player_basic_info WHERE xuid = ?",
                (player_xuid,)
            )
            if basic_info is None:
                self.report_arc_error(
                    "INV2",
                    f"fill_inviter SELECT inviter_xuid returned None xuid={player_xuid!r}",
                    player,
                )
                self.show_my_info_panel(player)
                return

            if basic_info.get('inviter_xuid'):
                player.send_message(self.language_manager.GetText('FILL_INVITER_FAIL_ALREADY_HAS_INVITER'))
                self.show_my_info_panel(player)
                return

            inviter_xuid = self.get_player_xuid_by_name(inviter_name_input)
            if not inviter_xuid:
                self.show_fill_inviter_panel(player, self.language_manager.GetText('FILL_INVITER_FAIL_PLAYER_NOT_FOUND'))
                return

            if inviter_xuid == player_xuid:
                self.show_fill_inviter_panel(player, self.language_manager.GetText('FILL_INVITER_FAIL_CANNOT_INVITE_SELF'))
                return

            # 写入邀请人信息
            try:
                update_success = self.database_manager.update(
                    table='player_basic_info',
                    data={'inviter_xuid': inviter_xuid},
                    where='xuid = ?',
                    params=(player_xuid,)
                )
            except Exception:
                update_success = False

            if not update_success:
                self.report_arc_error(
                    "INV3",
                    f"fill_inviter UPDATE inviter_xuid failed xuid={player_xuid!r}",
                    player,
                )
                self.show_my_info_panel(player)
                return

            # 给自己发放一次邀请奖励
            self.grant_invite_reward_to_player(player, 1)

            # 给邀请人累加一份待领取奖励
            self.add_pending_invite_rewards(inviter_xuid, 1)

            player.send_message(self.language_manager.GetText('FILL_INVITER_SUBMIT_SUCCESS').format(inviter_name_input))

            inviter_player = self.server.get_player(inviter_name_input)
            if inviter_player is not None:
                inviter_player.send_message(self.language_manager.GetText('INVITE_REWARD_GIVE_INVITER_HINT').format(player.name))

            self.show_my_info_panel(player)

        fill_inviter_panel = ModalForm(
            title=panel_title,
            controls=[inviter_input],
            on_close=self.show_my_info_panel,
            on_submit=try_set_inviter
        )
        player.send_form(fill_inviter_panel)

    def claim_invite_rewards(self, player: Player):
        """领取玩家待领取的邀请奖励"""
        player_xuid = str(player.xuid)
        pending_info = self.database_manager.query_one(
            "SELECT pending_invite_reward_times FROM player_basic_info WHERE xuid = ?",
            (player_xuid,)
        )

        pending_times = 0
        if pending_info is not None:
            try:
                pending_times = int(pending_info.get('pending_invite_reward_times', 0) or 0)
            except (ValueError, TypeError):
                pending_times = 0

        if pending_times <= 0:
            no_reward_panel = ActionForm(
                title=self.language_manager.GetText('INVITE_REWARD_CLAIM_RESULT_TITLE'),
                content=self.language_manager.GetText('INVITE_REWARD_CLAIM_NOTHING'),
                on_close=self.show_my_info_panel
            )
            player.send_form(no_reward_panel)
            return

        # 发放奖励（按照累计次数一次性发放）
        self.grant_invite_reward_to_player(player, pending_times)

        # 清零数据库中的待领取次数
        try:
            self.database_manager.update(
                table='player_basic_info',
                data={'pending_invite_reward_times': 0},
                where='xuid = ?',
                params=(player_xuid,)
            )
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Clear pending invite reward times error: {str(e)}")

        result_content = self.language_manager.GetText('INVITE_REWARD_CLAIM_RESULT_CONTENT').format(pending_times)
        result_panel = ActionForm(
            title=self.language_manager.GetText('INVITE_REWARD_CLAIM_RESULT_TITLE'),
            content=result_content,
            on_close=self.show_my_info_panel
        )
        player.send_form(result_panel)

    # Register and login
    def login_successfully(self, player: Player):
        self.player_authentication_state[player.name] = True
        self.show_main_menu(player) # 登录成功后自动弹出主菜单

    def _on_login_form_closed(self, player: Player, is_register: bool):
        """登录/注册表单被关闭时的回调；若未登录且开启强制登录则再次执行 /arc 逻辑强制打开菜单"""
        if self.if_player_logined(player):
            return
        if self.force_login:
            self.show_main_menu(player)
        else:
            if is_register:
                self.show_register_panel(player)
            else:
                self.show_login_panel(player)

    def show_register_panel(self, player: Player, hint_message=None):
        password_input = TextInput(
            label=self.language_manager.GetText('REGISTER_PANEL_PASSWORD_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('REGISTER_PANEL_PASSWORD_INPUT_PLACEHOLDER')
        )
        confirm_password_input = TextInput(
            label=self.language_manager.GetText('REGISTER_PANEL_CONFIRM_PASSWORD_LABEL'),
            placeholder=self.language_manager.GetText('REGISTER_PANEL_CONFIRM_PASSWORD_PLACEHOLDER')
        )
        panel_title = self.language_manager.GetText('REGISTER_PANEL_TITLE') if hint_message is None else hint_message

        def try_register(player: Player, json_str: str):
            data = json.loads(json_str)
            if len(data) < 2:
                self.show_register_panel(player, self.language_manager.GetText('REGISTER_FAIL_PASSWORD_NOT_INPUT'))
                return
            password = data[0]
            confirm_password = data[1]
            if not password:
                self.show_register_panel(player, self.language_manager.GetText('REGISTER_FAIL_PASSWORD_NOT_INPUT'))
                return
            if password != confirm_password:
                self.show_register_panel(player, self.language_manager.GetText('REGISTER_FAIL_PASSWORD_MISMATCH'))
                return
            r = self.set_player_password(player, password)
            if r:
                player.send_message(self.language_manager.GetText('REGISTER_SUCCESS'))
                self.login_successfully(player)
            else:
                player.send_message(self.language_manager.GetText('REGISTER_FAIL'))

        register_panel = ModalForm(
            title=panel_title,
            controls=[password_input, confirm_password_input],
            on_close=lambda p: self._on_login_form_closed(p, True),
            on_submit=try_register
        )
        player.send_form(register_panel)

    def show_login_panel(self, player: Player, hint_message=None):
        password_input = TextInput(
            label=self.language_manager.GetText('LOGIN_PANEL_PASSWORD_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('LOGIN_PANEL_PASSWORD_INPUT_PLACEHOLDER')
        )
        panel_title = self.language_manager.GetText('LOGIN_PANEL_TITLE') if hint_message is None else hint_message

        def try_login(player: Player, json_str: str):
            data = json.loads(json_str)
            if len(data) == 0:
                # 密码未输入，重新显示登录面板并提示
                self.show_login_panel(player, self.language_manager.GetText('LOGIN_FAIL_PASSWORD_NOT_INPUT'))
            else:
                # 验证密码
                if self.verify_player_password(player, data[0]):
                    player.send_message(self.language_manager.GetText('LOGIN_SUCCESS'))
                    self.login_successfully(player)
                else:
                    # 密码错误，重新显示登录面板
                    self.show_login_panel(player, self.language_manager.GetText('LOGIN_FAIL_WRONG_PASSWORD'))

        login_panel = ModalForm(
            title=panel_title,
            controls=[password_input],
            on_close=lambda p: self._on_login_form_closed(p, False),
            on_submit=try_login
        )
        player.send_form(login_panel)

    def if_player_logined(self, player: Player):
        if not player.name in self.player_authentication_state:
            self.player_authentication_state[player.name] = False
        return self.player_authentication_state[player.name]

    # Economy system（委托 Economy 模块，金钱以 float 存储，精确到分）
    def _round_money(self, value: float) -> float:
        return self.economy.round_money(value)

    def _format_money_display(self, value: float) -> str:
        return self.economy.format_money_display(value)

    def _set_player_money_by_name(self, player_name: str, amount: float) -> bool:
        player_xuid = self.get_player_xuid_by_name(player_name)
        if not player_xuid:
            if self.logger:
                self.logger.error(f"{ColorFormat.RED}[ARC Core]Player {player_name} not found")
            return False
        success = self.economy.set_player_money_by_xuid(player_xuid, amount)
        if success:
            try:
                self._update_richest_title_if_needed()
            except Exception:
                pass
        return success

    def _set_player_money(self, player: Player, amount: float) -> bool:
        return self._set_player_money_by_name(player.name, amount)

    def get_player_money_by_name(self, player_name: str) -> float:
        player_xuid = self.get_player_xuid_by_name(player_name)
        return self.economy.get_player_money_by_xuid(player_xuid) if player_xuid else 0.0

    def get_player_money(self, player: Player) -> float:
        return self.economy.get_player_money_by_xuid(str(player.xuid))

    def increase_player_money_by_name(self, player_name: str, amount: float, notify: bool = True) -> bool:
        player_xuid = self.get_player_xuid_by_name(player_name)
        if not player_xuid:
            online_player = self.server.get_player(player_name)
            self.report_arc_error(
                "BANK15",
                f"increase_player_money_by_name cannot resolve xuid for name={player_name!r}",
                online_player,
            )
            return False
        success = self.economy.increase_player_money_by_xuid(player_xuid, amount)
        if not success:
            online_player = self.server.get_player(player_name)
            self.report_arc_error(
                "BANK10",
                f"increase_player_money_by_name failed name={player_name!r} amount={amount!r}",
                online_player,
            )
        if success and notify:
            online_player = self.server.get_player(player_name)
            if online_player is not None:
                new_money = self.economy.get_player_money_by_xuid(player_xuid)
                online_player.send_message(
                    self.language_manager.GetText('MONEY_ADD_HINT').format(
                        self._format_money_display(amount),
                        self._format_money_display(new_money)
                    )
                )
        if success:
            try:
                self._update_richest_title_if_needed()
            except Exception:
                pass
        return success

    def decrease_player_money_by_name(self, player_name: str, amount: float, notify: bool = True) -> bool:
        player_xuid = self.get_player_xuid_by_name(player_name)
        if not player_xuid:
            online_player = self.server.get_player(player_name)
            self.report_arc_error(
                "BANK16",
                f"decrease_player_money_by_name cannot resolve xuid for name={player_name!r}",
                online_player,
            )
            return False
        success = self.economy.decrease_player_money_by_xuid(player_xuid, amount)
        if not success:
            online_player = self.server.get_player(player_name)
            self.report_arc_error(
                "BANK11",
                f"decrease_player_money_by_name failed name={player_name!r} amount={amount!r}",
                online_player,
            )
        if success and notify:
            online_player = self.server.get_player(player_name)
            if online_player is not None:
                new_money = self.economy.get_player_money_by_xuid(player_xuid)
                online_player.send_message(
                    self.language_manager.GetText('MONEY_REDUCE_HINT').format(
                        self._format_money_display(amount),
                        self._format_money_display(new_money)
                    )
                )
        if success:
            try:
                self._update_richest_title_if_needed()
            except Exception:
                pass
        return success

    def change_player_money_by_name(self, player_name: str, money_to_change: float, notify: bool = True) -> bool:
        m = self._round_money(money_to_change)
        if m == 0:
            return True
        if m > 0:
            return self.increase_player_money_by_name(player_name, m, notify)
        return self.decrease_player_money_by_name(player_name, abs(m), notify)

    def increase_player_money(self, player: Player, amount: float) -> bool:
        return self.increase_player_money_by_name(player.name, amount)

    def decrease_player_money(self, player: Player, amount: float) -> bool:
        return self.decrease_player_money_by_name(player.name, amount)

    def _today_checkin_date_str(self) -> str:
        return datetime.now().date().isoformat()

    def _parse_checkin_reward_list_raw(self, raw: Optional[str]) -> list:
        """解析配置中的 CHECKIN_REWARD_LIST（JSON 数组），每项 [物品ID, 数量, 权重]。"""
        if raw is None or not str(raw).strip():
            return []
        try:
            data = json.loads(str(raw).strip())
        except Exception:
            return []
        if not isinstance(data, list):
            return []
        result = []
        for row in data:
            if not isinstance(row, (list, tuple)) or len(row) < 3:
                continue
            item_id = str(row[0]).strip()
            try:
                item_count = int(row[1])
            except (ValueError, TypeError):
                continue
            try:
                weight = int(row[2])
            except (ValueError, TypeError):
                continue
            if not item_id or item_count <= 0 or weight <= 0:
                continue
            result.append({"item_id": item_id, "item_count": item_count, "weight": weight})
        return result

    def _save_checkin_reward_list_entries(self, entries: list) -> None:
        """将奖励条目写回 CHECKIN_REWARD_LIST（每项 [物品ID, 数量, 权重]）。"""
        payload = [[e["item_id"], int(e["item_count"]), int(e["weight"])] for e in entries]
        self.setting_manager.SetSetting(
            "CHECKIN_REWARD_LIST", json.dumps(payload, ensure_ascii=False)
        )

    def _get_checkin_pick_range(self) -> tuple:
        """随机物品抽取条数区间 [最小, 最大]；未配置 MIN/MAX 时沿用 CHECKIN_REWARD_PICK_COUNT。"""
        raw_min = self.setting_manager.GetSetting("CHECKIN_REWARD_PICK_MIN")
        raw_max = self.setting_manager.GetSetting("CHECKIN_REWARD_PICK_MAX")

        def parse_int_safe(raw_value, default_value: int) -> int:
            try:
                return int(str(raw_value).strip())
            except (ValueError, TypeError, AttributeError):
                return default_value

        min_empty = raw_min is None or str(raw_min).strip() == ""
        max_empty = raw_max is None or str(raw_max).strip() == ""
        if min_empty and max_empty:
            legacy = parse_int_safe(self.setting_manager.GetSetting("CHECKIN_REWARD_PICK_COUNT"), 0)
            pick_min = max(0, legacy)
            pick_max = max(0, legacy)
        else:
            pick_min = max(0, parse_int_safe(raw_min, 0))
            pick_max = max(0, parse_int_safe(raw_max, pick_min))
        if pick_min > pick_max:
            pick_min, pick_max = pick_max, pick_min
        return pick_min, pick_max

    def _get_checkin_non_negative_int_setting(self, setting_key: str, default_value: int = 0) -> int:
        raw_value = self.setting_manager.GetSetting(setting_key)
        try:
            parsed_value = int(str(raw_value).strip())
        except (ValueError, TypeError, AttributeError):
            parsed_value = default_value
        return max(0, parsed_value)

    def _get_checkin_non_negative_money_setting(self, setting_key: str, default_value: float = 0.0) -> float:
        raw_value = self.setting_manager.GetSetting(setting_key)
        try:
            parsed_value = float(str(raw_value).strip())
        except (ValueError, TypeError, AttributeError):
            parsed_value = default_value
        return self._round_money(max(0.0, parsed_value))

    @staticmethod
    def _compute_next_continuous_checkin_days(last_checkin_date: str, current_days: int, today: str) -> int:
        if not last_checkin_date:
            return 1
        try:
            today_date = datetime.fromisoformat(today).date()
            yesterday = (today_date - timedelta(days=1)).isoformat()
        except ValueError:
            return 1
        if last_checkin_date == yesterday:
            return max(1, int(current_days) + 1)
        return 1

    @staticmethod
    def _calculate_checkin_top_rank_bonus_money(today_rank: int, top_rank_limit: int, step_money: float) -> float:
        if today_rank <= 0 or top_rank_limit <= 0 or today_rank > top_rank_limit or step_money <= 0:
            return 0.0
        reward_multiplier = top_rank_limit - today_rank + 1
        return round(step_money * reward_multiplier, 2)

    def get_checkin_config(self) -> Dict[str, Any]:
        raw_money = self.setting_manager.GetSetting("CHECKIN_DAILY_MONEY")
        try:
            daily_money = float(raw_money)
        except (ValueError, TypeError):
            daily_money = 0.0
        daily_money = self._round_money(daily_money)

        pick_min, pick_max = self._get_checkin_pick_range()
        top_rank_limit = self._get_checkin_non_negative_int_setting("CHECKIN_TOP_RANK_LIMIT", 0)
        top_rank_bonus_item_count = self._get_checkin_non_negative_int_setting(
            "CHECKIN_TOP_RANK_BONUS_ITEM_COUNT", 0
        )
        top_rank_bonus_money_step = self._get_checkin_non_negative_money_setting(
            "CHECKIN_TOP_RANK_BONUS_MONEY_STEP", 0.0
        )
        continuous_checkin_money_increment = self._get_checkin_non_negative_money_setting(
            "CHECKIN_CONTINUOUS_DAYS_MONEY_INCREMENT", 0.0
        )

        reward_list = self._parse_checkin_reward_list_raw(self.setting_manager.GetSetting("CHECKIN_REWARD_LIST"))
        return {
            "daily_money": daily_money,
            "pick_min": pick_min,
            "pick_max": pick_max,
            "top_rank_limit": top_rank_limit,
            "top_rank_bonus_item_count": top_rank_bonus_item_count,
            "top_rank_bonus_money_step": top_rank_bonus_money_step,
            "continuous_checkin_money_increment": continuous_checkin_money_increment,
            "reward_list": reward_list,
        }

    @staticmethod
    def _weighted_sample_checkin_rewards(entries: list, pick_count: int) -> list:
        """按权重不放回抽取若干条奖励配置。"""
        pool = [e for e in entries if int(e.get("weight", 0) or 0) > 0]
        if not pool or pick_count <= 0:
            return []
        k = min(int(pick_count), len(pool))
        chosen = []
        for _ in range(k):
            total_w = sum(int(x["weight"]) for x in pool)
            if total_w <= 0:
                break
            r = random.uniform(0, total_w)
            acc = 0.0
            pick_idx = 0
            for i, x in enumerate(pool):
                acc += int(x["weight"])
                if r <= acc:
                    pick_idx = i
                    break
            chosen.append(pool.pop(pick_idx))
        return chosen

    def _broadcast_chat_lines(self, message: str) -> None:
        """将多行文本按行分别广播，避免聊天栏把换行挤成一行看不清。"""
        if not (message or "").strip():
            return
        for line in message.replace("\r\n", "\n").split("\n"):
            stripped = line.strip()
            if stripped:
                self.server.broadcast_message(stripped)

    def _build_checkin_rank_texts(self, today: str):
        """
        构建签到排行榜文本：
        - 今日最早签到前 10 名（使用 CHECKIN_CHAT_TODAY_RANK_EARLY）
        - 累计签到前 10 名（使用 CHECKIN_CHAT_TOTAL_RANK）
        返回 (today_text or None, total_text or None)
        """
        rank_limit = 10
        today_text = None
        total_text = None

        try:
            order_by_time = (
                "(last_checkin_at IS NULL OR trim(last_checkin_at) = ''), last_checkin_at "
            )
            sep = self.language_manager.GetText("CHECKIN_CHAT_RANK_SEPARATOR")
            slot_key = "CHECKIN_CHAT_TODAY_RANK_SLOT"

            # 今日最早签到前 10 名
            today_rows = self.database_manager.query_all(
                "SELECT xuid, name FROM player_basic_info WHERE last_checkin_date = ? "
                "ORDER BY " + order_by_time + "ASC LIMIT ?",
                (today, rank_limit),
            )
            if today_rows:
                early_parts = []
                for index, row in enumerate(today_rows, start=1):
                    display_name = self._rank_display_name_from_row(row)
                    early_parts.append(
                        self.language_manager.GetText(slot_key).format(
                            index, display_name
                        )
                    )
                today_text = self.language_manager.GetText(
                    "CHECKIN_CHAT_TODAY_RANK_EARLY"
                ).format(sep.join(early_parts))
        except Exception as e:
            if self.logger:
                self.logger.error(
                    f"{ColorFormat.RED}[ARC Core]build checkin today rank text error: {e}"
                )

        try:
            # 累计签到前 10 名
            total_rows = self.database_manager.query_all(
                "SELECT xuid, name, total_checkin_count FROM player_basic_info "
                "WHERE COALESCE(total_checkin_count, 0) > 0 "
                "ORDER BY total_checkin_count DESC, xuid ASC LIMIT ?",
                (rank_limit,),
            )
            if total_rows:
                times_unit = self.language_manager.GetText(
                    "CHECKIN_RANK_TIMES_SUFFIX"
                )
                total_parts = []
                for index, row in enumerate(total_rows, start=1):
                    display_name = self._rank_display_name_from_row(row)
                    try:
                        checkin_times = int(row.get("total_checkin_count") or 0)
                    except (ValueError, TypeError):
                        checkin_times = 0
                    total_parts.append(
                        self.language_manager.GetText(
                            "CHECKIN_CHAT_TOTAL_RANK_SLOT"
                        ).format(index, display_name, checkin_times, times_unit)
                    )
                total_text = self.language_manager.GetText(
                    "CHECKIN_CHAT_TOTAL_RANK"
                ).format(
                    self.language_manager.GetText(
                        "CHECKIN_CHAT_RANK_SEPARATOR"
                    ).join(total_parts)
                )
        except Exception as e:
            if self.logger:
                self.logger.error(
                    f"{ColorFormat.RED}[ARC Core]build checkin total rank text error: {e}"
                )

        return today_text, total_text

    def _broadcast_checkin_rankings(self, player_display_name: str, today: str) -> None:
        """签到成功后全服广播：完成提示、今日最早前 10 名、累计前 10 名（与面板复用同一套文本逻辑）。"""
        try:
            self.server.broadcast_message(
                self.language_manager.GetText("CHECKIN_CHAT_ANNOUNCE").format(
                    player_display_name
                )
            )
        except Exception as e:
            if self.logger:
                self.logger.error(
                    f"{ColorFormat.RED}[ARC Core]checkin broadcast announce error: {e}"
                )
            return

        today_text, total_text = self._build_checkin_rank_texts(today)
        if today_text:
            self._broadcast_chat_lines(today_text)
        if total_text:
            self._broadcast_chat_lines(total_text)

    def show_daily_checkin_panel(self, player: Player):
        """每日签到：同一天仅一次，发放配置中的金钱与加权随机物品。"""
        if not self.if_player_logined(player):
            self.show_main_menu(player)
            return
        player_xuid = str(player.xuid)
        today = self._today_checkin_date_str()
        row = self.database_manager.query_one(
            "SELECT last_checkin_date, continuous_checkin_days FROM player_basic_info WHERE xuid = ?",
            (player_xuid,),
        )
        last_date = (row.get("last_checkin_date") if row else None) or ""
        last_date = str(last_date).strip()
        if last_date == today:
            # 已签到玩家：在提示文案下方附带签到排行榜（只显示今日前 10 名 + 累计前 10 名）
            content_lines = [self.language_manager.GetText("CHECKIN_ALREADY_DONE")]
            try:
                today_text, total_text = self._build_checkin_rank_texts(today)
                if today_text:
                    content_lines.append(today_text)
                if total_text:
                    content_lines.append(total_text)
            except Exception as e:
                if self.logger:
                    self.logger.error(
                        f"{ColorFormat.RED}[ARC Core]show_daily_checkin_panel rank build error: {e}"
                    )

            panel = ActionForm(
                title=self.language_manager.GetText("CHECKIN_PANEL_TITLE"),
                content="\n\n".join(content_lines),
                on_close=self.show_main_menu,
            )
            panel.add_button(
                self.language_manager.GetText("RETURN_BUTTON_TEXT"),
                on_click=self.show_main_menu,
            )
            player.send_form(panel)
            return

        cfg = self.get_checkin_config()
        daily_money = cfg["daily_money"]
        pick_min = cfg["pick_min"]
        pick_max = cfg["pick_max"]
        top_rank_limit = cfg["top_rank_limit"]
        top_rank_bonus_item_count = cfg["top_rank_bonus_item_count"]
        top_rank_bonus_money_step = cfg["top_rank_bonus_money_step"]
        continuous_checkin_money_increment = cfg["continuous_checkin_money_increment"]
        reward_list = cfg["reward_list"]

        today_rank = 1
        try:
            signed_count_row = self.database_manager.query_one(
                "SELECT COUNT(1) AS cnt FROM player_basic_info WHERE last_checkin_date = ?",
                (today,),
            )
            today_signed_count = int((signed_count_row or {}).get("cnt") or 0)
            today_rank = max(1, today_signed_count + 1)
        except (ValueError, TypeError):
            today_rank = 1

        try:
            current_continuous_days = int((row or {}).get("continuous_checkin_days") or 0)
        except (ValueError, TypeError):
            current_continuous_days = 0
        next_continuous_days = self._compute_next_continuous_checkin_days(
            last_date, current_continuous_days, today
        )

        rank_bonus_money = self._calculate_checkin_top_rank_bonus_money(
            today_rank, top_rank_limit, top_rank_bonus_money_step
        )
        continuous_bonus_money = self._round_money(
            max(0, next_continuous_days - 1) * continuous_checkin_money_increment
        )
        total_money = self._round_money(daily_money + rank_bonus_money + continuous_bonus_money)

        pick_count = random.randint(pick_min, pick_max) if pick_max >= pick_min else 0
        picked = self._weighted_sample_checkin_rewards(reward_list, pick_count)
        bonus_picked = []
        if (
            top_rank_limit > 0
            and today_rank <= top_rank_limit
            and top_rank_bonus_item_count > 0
            and reward_list
        ):
            bonus_picked = self._weighted_sample_checkin_rewards(
                reward_list, top_rank_bonus_item_count
            )

        if total_money > 0:
            self.increase_player_money(player, total_money)

        item_lines = []
        for it in picked:
            item_id = it["item_id"]
            cnt = int(it["item_count"])
            if cnt <= 0:
                continue
            try:
                self.server.dispatch_command(
                    self.server.command_sender, f"give {player.name} {item_id} {cnt}"
                )
            except Exception:
                pass
            item_lines.append(f"{item_id} x{cnt}")

        bonus_item_lines = []
        for it in bonus_picked:
            item_id = it["item_id"]
            cnt = int(it["item_count"])
            if cnt <= 0:
                continue
            try:
                self.server.dispatch_command(
                    self.server.command_sender, f"give {player.name} {item_id} {cnt}"
                )
            except Exception:
                pass
            bonus_item_lines.append(f"{item_id} x{cnt}")

        now_iso = datetime.now().replace(microsecond=0).isoformat()
        ok = self.database_manager.execute(
            "UPDATE player_basic_info SET last_checkin_date = ?, last_checkin_at = ?, "
            "total_checkin_count = COALESCE(total_checkin_count, 0) + 1, continuous_checkin_days = ?, "
            "name = ? WHERE xuid = ?",
            (today, now_iso, next_continuous_days, player.name, player_xuid),
        )
        if not ok:
            self.report_arc_error(
                "CHK1",
                f"checkin update stats failed xuid={player_xuid!r} date={today!r}",
                player,
            )
        else:
            announcer = self.get_player_name_by_xuid(player_xuid, return_with_title=True) or player.name
            self._broadcast_checkin_rankings(announcer, today)

        if total_money > 0:
            money_line = self.language_manager.GetText("CHECKIN_SUCCESS_MONEY_LINE").format(
                self._format_money_display(daily_money),
                self._format_money_display(rank_bonus_money),
                self._format_money_display(continuous_bonus_money),
                self._format_money_display(total_money),
            )
        else:
            money_line = self.language_manager.GetText("CHECKIN_SUCCESS_NO_MONEY_LINE")
        items_text = "、".join(item_lines) if item_lines else self.language_manager.GetText("CHECKIN_NO_ITEM_REWARD")
        content = self.language_manager.GetText("CHECKIN_SUCCESS_CONTENT").format(money_line, items_text)
        if bonus_item_lines:
            content = (
                content
                + "\n\n"
                + self.language_manager.GetText("CHECKIN_TOP_RANK_BONUS_ITEM_NOTICE").format(
                    top_rank_limit, "、".join(bonus_item_lines)
                )
            )

        result_panel = ActionForm(
            title=self.language_manager.GetText("CHECKIN_PANEL_TITLE"),
            content=content,
            on_close=self.show_main_menu,
        )
        result_panel.add_button(self.language_manager.GetText("RETURN_BUTTON_TEXT"), on_click=self.show_main_menu)
        player.send_form(result_panel)

    def show_checkin_config_panel(self, player: Player):
        """OP：签到配置入口（存款/条数 与 物品奖励列表分步配置）。"""
        cfg = self.get_checkin_config()
        hub_content = self.language_manager.GetText("CHECKIN_CONFIG_HUB_CONTENT").format(
            self._format_money_display(cfg["daily_money"]),
            cfg["pick_min"],
            cfg["pick_max"],
            cfg["top_rank_limit"],
            cfg["top_rank_bonus_item_count"],
            self._format_money_display(cfg["top_rank_bonus_money_step"]),
            self._format_money_display(cfg["continuous_checkin_money_increment"]),
            len(cfg["reward_list"]),
        )
        hub = ActionForm(
            title=self.language_manager.GetText("CHECKIN_CONFIG_TITLE"),
            content=hub_content,
            on_close=self.show_op_main_panel,
        )
        hub.add_button(
            self.language_manager.GetText("CHECKIN_CONFIG_MONEY_PICK_BUTTON"),
            on_click=self.show_checkin_money_pick_modal,
        )
        hub.add_button(
            self.language_manager.GetText("CHECKIN_CONFIG_REWARD_LIST_BUTTON"),
            on_click=self.show_checkin_reward_list_panel,
        )
        hub.add_button(
            self.language_manager.GetText("RETURN_BUTTON_TEXT"),
            on_click=self.show_op_main_panel,
        )
        player.send_form(hub)

    def show_checkin_money_pick_modal(self, player: Player):
        """OP：编辑签到存款与随机抽取条数区间（每日在最小～最大之间随机）。"""
        cfg = self.get_checkin_config()
        money_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_CONFIG_MONEY_LABEL"),
            placeholder="0",
            default_value=str(cfg["daily_money"]),
        )
        pick_min_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_CONFIG_PICK_MIN_LABEL"),
            placeholder="0",
            default_value=str(cfg["pick_min"]),
        )
        pick_max_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_CONFIG_PICK_MAX_LABEL"),
            placeholder="0",
            default_value=str(cfg["pick_max"]),
        )
        top_rank_limit_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_CONFIG_TOP_RANK_LIMIT_LABEL"),
            placeholder="0",
            default_value=str(cfg["top_rank_limit"]),
        )
        top_rank_bonus_item_count_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_CONFIG_TOP_RANK_BONUS_ITEM_COUNT_LABEL"),
            placeholder="0",
            default_value=str(cfg["top_rank_bonus_item_count"]),
        )
        top_rank_bonus_money_step_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_CONFIG_TOP_RANK_BONUS_MONEY_STEP_LABEL"),
            placeholder="0",
            default_value=str(cfg["top_rank_bonus_money_step"]),
        )
        continuous_checkin_money_increment_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_CONFIG_CONTINUOUS_MONEY_INCREMENT_LABEL"),
            placeholder="0",
            default_value=str(cfg["continuous_checkin_money_increment"]),
        )

        def try_save(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                p.send_message(self.language_manager.GetText("CHECKIN_CONFIG_SAVE_FAIL"))
                return self.show_checkin_config_panel(p)
            if not data or len(data) < 7:
                p.send_message(self.language_manager.GetText("CHECKIN_CONFIG_SAVE_FAIL"))
                return self.show_checkin_config_panel(p)
            try:
                money_v = self._round_money(float(str(data[0]).strip()))
            except (ValueError, TypeError):
                money_v = 0.0
            try:
                pick_min_v = int(str(data[1]).strip())
            except (ValueError, TypeError):
                pick_min_v = 0
            try:
                pick_max_v = int(str(data[2]).strip())
            except (ValueError, TypeError):
                pick_max_v = 0
            try:
                top_rank_limit_v = int(str(data[3]).strip())
            except (ValueError, TypeError):
                top_rank_limit_v = 0
            try:
                top_rank_bonus_item_count_v = int(str(data[4]).strip())
            except (ValueError, TypeError):
                top_rank_bonus_item_count_v = 0
            try:
                top_rank_bonus_money_step_v = self._round_money(float(str(data[5]).strip()))
            except (ValueError, TypeError):
                top_rank_bonus_money_step_v = 0.0
            try:
                continuous_checkin_money_increment_v = self._round_money(float(str(data[6]).strip()))
            except (ValueError, TypeError):
                continuous_checkin_money_increment_v = 0.0
            if pick_min_v < 0:
                pick_min_v = 0
            if pick_max_v < 0:
                pick_max_v = 0
            if top_rank_limit_v < 0:
                top_rank_limit_v = 0
            if top_rank_bonus_item_count_v < 0:
                top_rank_bonus_item_count_v = 0
            if top_rank_bonus_money_step_v < 0:
                top_rank_bonus_money_step_v = 0.0
            if continuous_checkin_money_increment_v < 0:
                continuous_checkin_money_increment_v = 0.0
            if pick_min_v > pick_max_v:
                pick_min_v, pick_max_v = pick_max_v, pick_min_v
            reward_entries = self.get_checkin_config()["reward_list"]
            if (pick_max_v > 0 or (top_rank_limit_v > 0 and top_rank_bonus_item_count_v > 0)) and not reward_entries:
                p.send_message(self.language_manager.GetText("CHECKIN_CONFIG_LIST_INVALID"))
                return self.show_checkin_config_panel(p)
            self.setting_manager.SetSetting("CHECKIN_DAILY_MONEY", money_v)
            self.setting_manager.SetSetting("CHECKIN_REWARD_PICK_MIN", pick_min_v)
            self.setting_manager.SetSetting("CHECKIN_REWARD_PICK_MAX", pick_max_v)
            self.setting_manager.SetSetting("CHECKIN_REWARD_PICK_COUNT", pick_max_v)
            self.setting_manager.SetSetting("CHECKIN_TOP_RANK_LIMIT", top_rank_limit_v)
            self.setting_manager.SetSetting("CHECKIN_TOP_RANK_BONUS_ITEM_COUNT", top_rank_bonus_item_count_v)
            self.setting_manager.SetSetting("CHECKIN_TOP_RANK_BONUS_MONEY_STEP", top_rank_bonus_money_step_v)
            self.setting_manager.SetSetting(
                "CHECKIN_CONTINUOUS_DAYS_MONEY_INCREMENT", continuous_checkin_money_increment_v
            )
            p.send_message(self.language_manager.GetText("CHECKIN_CONFIG_SAVED"))
            self.show_checkin_config_panel(p)

        form = ModalForm(
            title=self.language_manager.GetText("CHECKIN_CONFIG_MONEY_PICK_MODAL_TITLE"),
            controls=[
                money_input,
                pick_min_input,
                pick_max_input,
                top_rank_limit_input,
                top_rank_bonus_item_count_input,
                top_rank_bonus_money_step_input,
                continuous_checkin_money_increment_input,
            ],
            on_close=self.show_checkin_config_panel,
            on_submit=try_save,
        )
        player.send_form(form)

    def show_checkin_reward_list_panel(self, player: Player):
        """OP：查看/增删改签到物品奖励（带编号）。"""
        reward_entries = self.get_checkin_config()["reward_list"]
        if reward_entries:
            lines = []
            for idx, e in enumerate(reward_entries, start=1):
                lines.append(
                    self.language_manager.GetText("CHECKIN_REWARD_LIST_LINE").format(
                        idx, e["item_id"], e["item_count"], e["weight"]
                    )
                )
            list_content = "\n".join(lines)
        else:
            list_content = self.language_manager.GetText("CHECKIN_REWARD_LIST_EMPTY")
        panel = ActionForm(
            title=self.language_manager.GetText("CHECKIN_REWARD_LIST_TITLE"),
            content=list_content,
            on_close=self.show_checkin_config_panel,
        )
        panel.add_button(
            self.language_manager.GetText("CHECKIN_REWARD_ADD_BUTTON"),
            on_click=self.show_checkin_reward_add_modal,
        )
        for entry_index, e in enumerate(reward_entries):
            btn_label = self.language_manager.GetText("CHECKIN_REWARD_LIST_ITEM_BUTTON").format(
                entry_index + 1, e["item_id"], e["item_count"]
            )
            panel.add_button(
                btn_label,
                on_click=lambda pl, i=entry_index: self.show_checkin_reward_entry_menu(pl, i),
            )
        panel.add_button(
            self.language_manager.GetText("RETURN_BUTTON_TEXT"),
            on_click=self.show_checkin_config_panel,
        )
        player.send_form(panel)

    def show_checkin_reward_entry_menu(self, player: Player, entry_index: int):
        """OP：单条条目 — 编辑或删除。"""
        reward_entries = self.get_checkin_config()["reward_list"]
        if entry_index < 0 or entry_index >= len(reward_entries):
            self.show_checkin_reward_list_panel(player)
            return
        e = reward_entries[entry_index]
        display_num = entry_index + 1
        sub = ActionForm(
            title=self.language_manager.GetText("CHECKIN_REWARD_ENTRY_MENU_TITLE"),
            content=self.language_manager.GetText("CHECKIN_REWARD_ENTRY_MENU_CONTENT").format(
                display_num, e["item_id"], e["item_count"], e["weight"]
            ),
            on_close=self.show_checkin_reward_list_panel,
        )
        sub.add_button(
            self.language_manager.GetText("CHECKIN_REWARD_EDIT_BUTTON"),
            on_click=lambda pl, i=entry_index: self.show_checkin_reward_edit_modal(pl, i),
        )
        sub.add_button(
            self.language_manager.GetText("CHECKIN_REWARD_DELETE_BUTTON"),
            on_click=lambda pl, i=entry_index: self.show_checkin_reward_delete_confirm(pl, i),
        )
        sub.add_button(
            self.language_manager.GetText("RETURN_BUTTON_TEXT"),
            on_click=self.show_checkin_reward_list_panel,
        )
        player.send_form(sub)

    def show_checkin_reward_delete_confirm(self, player: Player, entry_index: int):
        """OP：确认删除某条奖励。"""
        reward_entries = self.get_checkin_config()["reward_list"]
        if entry_index < 0 or entry_index >= len(reward_entries):
            self.show_checkin_reward_list_panel(player)
            return
        e = reward_entries[entry_index]
        display_num = entry_index + 1
        confirm = ActionForm(
            title=self.language_manager.GetText("CHECKIN_REWARD_DELETE_CONFIRM_TITLE"),
            content=self.language_manager.GetText("CHECKIN_REWARD_DELETE_CONFIRM_CONTENT").format(
                display_num, e["item_id"], e["item_count"]
            ),
            on_close=self.show_checkin_reward_list_panel,
        )

        def do_delete(pl: Player, del_index: int = entry_index):
            current = self.get_checkin_config()["reward_list"]
            if del_index < 0 or del_index >= len(current):
                self.show_checkin_reward_list_panel(pl)
                return
            new_list = [current[j] for j in range(len(current)) if j != del_index]
            self._save_checkin_reward_list_entries(new_list)
            pl.send_message(self.language_manager.GetText("CHECKIN_REWARD_LIST_SAVED"))
            self.show_checkin_reward_list_panel(pl)

        confirm.add_button(
            self.language_manager.GetText("CHECKIN_REWARD_DELETE_CONFIRM_BUTTON"),
            on_click=lambda pl, i=entry_index: do_delete(pl, i),
        )
        confirm.add_button(
            self.language_manager.GetText("RETURN_BUTTON_TEXT"),
            on_click=self.show_checkin_reward_list_panel,
        )
        player.send_form(confirm)

    def show_checkin_reward_add_modal(self, player: Player):
        """OP：新增一条 [物品ID, 数量, 权重]，权重可填默认 1。"""
        item_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_REWARD_ITEM_ID_LABEL"),
            placeholder="minecraft:diamond",
            default_value="",
        )
        count_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_REWARD_ITEM_COUNT_LABEL"),
            placeholder="1",
            default_value="1",
        )

        def try_add(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                p.send_message(self.language_manager.GetText("CHECKIN_REWARD_ADD_INVALID"))
                return self.show_checkin_reward_list_panel(p)
            if not data or len(data) < 2:
                p.send_message(self.language_manager.GetText("CHECKIN_REWARD_ADD_INVALID"))
                return self.show_checkin_reward_list_panel(p)
            item_id = str(data[0]).strip()
            try:
                item_count = int(str(data[1]).strip())
            except (ValueError, TypeError):
                item_count = 0
            weight = 1
            if len(data) >= 3 and str(data[2]).strip() != "":
                try:
                    weight = int(str(data[2]).strip())
                except (ValueError, TypeError):
                    weight = 1
            if not item_id or item_count <= 0:
                p.send_message(self.language_manager.GetText("CHECKIN_REWARD_ADD_INVALID"))
                return self.show_checkin_reward_list_panel(p)
            if weight <= 0:
                weight = 1
            current = self.get_checkin_config()["reward_list"][:]
            current.append(
                {"item_id": item_id, "item_count": item_count, "weight": weight}
            )
            self._save_checkin_reward_list_entries(current)
            p.send_message(self.language_manager.GetText("CHECKIN_REWARD_LIST_SAVED"))
            self.show_checkin_reward_list_panel(p)

        weight_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_REWARD_WEIGHT_LABEL"),
            placeholder="1",
            default_value="1",
        )
        form = ModalForm(
            title=self.language_manager.GetText("CHECKIN_REWARD_ADD_TITLE"),
            controls=[item_input, count_input, weight_input],
            on_close=self.show_checkin_reward_list_panel,
            on_submit=try_add,
        )
        player.send_form(form)

    def show_checkin_reward_edit_modal(self, player: Player, entry_index: int):
        """OP：编辑指定编号的奖励条目。"""
        reward_entries = self.get_checkin_config()["reward_list"]
        if entry_index < 0 or entry_index >= len(reward_entries):
            self.show_checkin_reward_list_panel(player)
            return
        e = reward_entries[entry_index]

        item_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_REWARD_ITEM_ID_LABEL"),
            placeholder="minecraft:diamond",
            default_value=str(e["item_id"]),
        )
        count_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_REWARD_ITEM_COUNT_LABEL"),
            placeholder="1",
            default_value=str(e["item_count"]),
        )
        weight_input = TextInput(
            label=self.language_manager.GetText("CHECKIN_REWARD_WEIGHT_LABEL"),
            placeholder="1",
            default_value=str(e["weight"]),
        )

        def try_save(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                p.send_message(self.language_manager.GetText("CHECKIN_REWARD_ADD_INVALID"))
                return self.show_checkin_reward_list_panel(p)
            if not data or len(data) < 2:
                p.send_message(self.language_manager.GetText("CHECKIN_REWARD_ADD_INVALID"))
                return self.show_checkin_reward_list_panel(p)
            item_id = str(data[0]).strip()
            try:
                item_count = int(str(data[1]).strip())
            except (ValueError, TypeError):
                item_count = 0
            try:
                weight = int(str(data[2]).strip()) if len(data) >= 3 else int(e["weight"])
            except (ValueError, TypeError):
                weight = 1
            if not item_id or item_count <= 0:
                p.send_message(self.language_manager.GetText("CHECKIN_REWARD_ADD_INVALID"))
                return self.show_checkin_reward_list_panel(p)
            if weight <= 0:
                weight = 1
            current = self.get_checkin_config()["reward_list"][:]
            if entry_index < 0 or entry_index >= len(current):
                self.show_checkin_reward_list_panel(p)
                return
            current[entry_index] = {
                "item_id": item_id,
                "item_count": item_count,
                "weight": weight,
            }
            self._save_checkin_reward_list_entries(current)
            p.send_message(self.language_manager.GetText("CHECKIN_REWARD_LIST_SAVED"))
            self.show_checkin_reward_list_panel(p)

        form = ModalForm(
            title=self.language_manager.GetText("CHECKIN_REWARD_EDIT_TITLE"),
            controls=[item_input, count_input, weight_input],
            on_close=self.show_checkin_reward_list_panel,
            on_submit=try_save,
        )
        player.send_form(form)

    def get_player_free_land_blocks(self, player: Player) -> int:
        """获取玩家剩余免费领地格子数"""
        try:
            player_xuid = str(player.xuid)
            result = self.database_manager.query_one(
                "SELECT remaining_free_land_blocks FROM player_basic_info WHERE xuid = ?",
                (player_xuid,)
            )
            if result is None:
                # 如果没有记录，返回默认值
                default_free_blocks = int(self.setting_manager.GetSetting('DEFAULT_FREE_LAND_BLOCKS') or '100')
                return default_free_blocks
            return result['remaining_free_land_blocks'] or 0
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Get player free land blocks error: {str(e)}")
            return 0

    def set_player_free_land_blocks(self, player: Player, amount: int) -> bool:
        """设置玩家剩余免费领地格子数"""
        try:
            player_xuid = str(player.xuid)
            return self.database_manager.update(
                'player_basic_info',
                {'remaining_free_land_blocks': amount},
                f"xuid = '{player_xuid}'"
            )
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Set player free land blocks error: {str(e)}")
            return False

    def get_invite_reward_config(self) -> Dict[str, Any]:
        """获取邀请奖励配置"""
        item_name_setting = self.setting_manager.GetSetting('INVITE_REWARD_ITEM_NAME')
        item_name = item_name_setting if item_name_setting is not None else ''

        item_count_setting = self.setting_manager.GetSetting('INVITE_REWARD_ITEM_COUNT')
        money_setting = self.setting_manager.GetSetting('INVITE_REWARD_MONEY')
        free_blocks_setting = self.setting_manager.GetSetting('INVITE_REWARD_FREE_LAND_BLOCKS')

        def parse_int_setting(raw_value: Optional[str]) -> int:
            if raw_value is None:
                return 0
            try:
                value = int(raw_value)
                if value < 0:
                    value = 0
                return value
            except (ValueError, TypeError):
                return 0

        def parse_float_money_setting(raw_value: Optional[str]) -> float:
            if raw_value is None:
                return 0.0
            try:
                value = float(raw_value)
                if value < 0:
                    value = 0.0
                return self._round_money(value)
            except (ValueError, TypeError):
                return 0.0

        item_count = parse_int_setting(item_count_setting)
        money_amount = parse_float_money_setting(money_setting)
        free_blocks = parse_int_setting(free_blocks_setting)

        return {
            'item_name': item_name,
            'item_count': item_count,
            'money': money_amount,
            'free_blocks': free_blocks
        }

    def grant_invite_reward_to_player(self, player: Player, times: int = 1):
        """给玩家发放邀请奖励（可一次性发放多份）"""
        if times <= 0:
            return

        reward_config = self.get_invite_reward_config()

        total_item_count = reward_config['item_count'] * times
        total_money = reward_config['money'] * times
        total_free_blocks = reward_config['free_blocks'] * times

        # 物资奖励通过服务器指令发放
        item_name = reward_config['item_name']
        if item_name and total_item_count > 0:
            try:
                self.server.dispatch_command(
                    self.server.command_sender,
                    f"give {player.name} {item_name} {total_item_count}"
                )
            except Exception as e:
                self.logger.error(f"{ColorFormat.RED}[ARC Core]Give invite reward item error: {str(e)}")

        # 金钱奖励
        if total_money > 0:
            self.increase_player_money(player, total_money)

        # 免费领地格子奖励
        if total_free_blocks > 0:
            current_free_blocks = self.get_player_free_land_blocks(player)
            new_free_blocks = current_free_blocks + total_free_blocks
            self.set_player_free_land_blocks(player, new_free_blocks)

        player.send_message(
            self.language_manager.GetText('INVITE_REWARD_GIVE_SELF_HINT').format(
                total_item_count,
                self._format_money_display(total_money),
                total_free_blocks
            )
        )

    def add_pending_invite_rewards(self, inviter_xuid: str, times: int = 1):
        """为邀请人累加待领取邀请奖励次数"""
        if times <= 0:
            return
        try:
            self.database_manager.execute(
                "UPDATE player_basic_info "
                "SET pending_invite_reward_times = COALESCE(pending_invite_reward_times, 0) + ? "
                "WHERE xuid = ?",
                (times, inviter_xuid)
            )
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Add pending invite rewards error: {str(e)}")

    def get_top_richest_players(self, top_count: int):
        """
        获取存款排行前 top_count 名玩家的信息列表。
        返回值为列表，每项包含：
        {
            "xuid": str,
            "display_name": str,  # 可能带有头衔/颜色的展示名
            "money": float,
            "is_op": bool or None,  # None 表示未知
        }
        """
        rich_list = []
        for entry in self.economy.get_top_richest_xuids(top_count):
            try:
                player_xuid = entry.get("xuid")
                if not player_xuid:
                    continue
                money_value = self._round_money(entry.get("money", 0.0))
                display_name = (
                    self.get_player_name_by_xuid(player_xuid, return_with_title=True)
                    or self.get_player_name_by_xuid(player_xuid, return_with_title=False)
                    or str(player_xuid)
                )
                is_op = self.get_offline_player_op_status_by_xuid(player_xuid)
                rich_list.append(
                    {
                        "xuid": player_xuid,
                        "display_name": display_name,
                        "money": money_value,
                        "is_op": is_op,
                    }
                )
            except Exception:
                continue
        return rich_list

    def get_player_money_rank(self, player: Player) -> Optional[int]:
        return self.economy.get_player_money_rank_by_xuid(str(player.xuid))

    def judge_if_player_has_enough_money_by_name(self, player_name: str, amount: float) -> bool:
        player_xuid = self.get_player_xuid_by_name(player_name)
        return self.economy.judge_if_player_has_enough_money_by_xuid(player_xuid, amount) if player_xuid else False

    def judge_if_player_has_enough_money(self, player: Player, amount: float) -> bool:
        return self.economy.judge_if_player_has_enough_money_by_xuid(str(player.xuid), amount)

    def _guild_text(self, key: str, default: str) -> str:
        t = self.language_manager.GetText(key)
        if t is None or not str(t).strip():
            return default
        return str(t)

    def _guild_err(self, code: Optional[str]) -> str:
        if not code:
            return self._guild_text("GUILD_ERR_UNKNOWN", "[弧光核心]操作失败。")
        return self._guild_text(code, f"[弧光核心]操作失败（{code}）。")

    def _find_online_player_by_xuid(self, xuid: str) -> Optional[Player]:
        xuid_s = str(xuid).strip()
        if not xuid_s:
            return None
        try:
            for p in self.server.online_players or []:
                if str(p.xuid) == xuid_s:
                    return p
        except Exception:
            pass
        return None

    # Guild
    def show_guild_main_menu(self, player: Player):
        if not self.if_player_logined(player):
            self.show_main_menu(player)
            return
        xuid = str(player.xuid)
        pending = self.guild_system.list_invites_for_player(xuid)
        mem = self.guild_system.get_membership(xuid)
        cost = self.guild_system.get_create_cost()
        lines = []
        if mem:
            g = self.guild_system.get_guild(int(mem["guild_id"]))
            gname = g.get("name", "") if g else ""
            role = mem.get("role", "")
            role_label = self._guild_text(
                f"GUILD_ROLE_{str(role).upper()}",
                str(role),
            )
            motto = (g.get("motto") or "") if g else ""
            lines.append(
                self._guild_text("GUILD_MAIN_IN_GUILD", "所属公会：{0}  职级：{1}").format(
                    gname, role_label
                )
            )
            if motto:
                lines.append(
                    self._guild_text("GUILD_MAIN_MOTTO", "简介：{0}").format(motto)
                )
        else:
            lines.append(
                self._guild_text(
                    "GUILD_MAIN_NOT_IN_GUILD",
                    "您尚未加入公会。创建需支付 {0}。",
                ).format(self._format_money_display(cost))
            )
        if pending:
            lines.append(
                self._guild_text(
                    "GUILD_MAIN_PENDING_HINT",
                    "您有 {0} 条待处理公会邀请。",
                ).format(len(pending))
            )
        form = ActionForm(
            title=self._guild_text("GUILD_MAIN_TITLE", "公会"),
            content="\n".join(lines),
            on_close=self.show_main_menu,
        )
        if pending:
            form.add_button(
                self._guild_text("GUILD_BTN_PENDING_INVITES", "待处理邀请"),
                on_click=self.show_guild_pending_invites_menu,
            )
        if not mem:
            form.add_button(
                self._guild_text("GUILD_BTN_CREATE", "创建公会"),
                on_click=self.show_guild_create_panel,
            )
        if mem:
            form.add_button(
                self._guild_text("GUILD_BTN_MY_GUILD", "我的公会"),
                on_click=self.show_guild_my_menu,
            )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_main_menu,
        )
        player.send_form(form)

    def show_guild_pending_invites_menu(self, player: Player):
        xuid = str(player.xuid)
        rows = self.guild_system.list_invites_for_player(xuid)
        form = ActionForm(
            title=self._guild_text("GUILD_PENDING_TITLE", "公会邀请"),
            content=self._guild_text("GUILD_PENDING_CONTENT", "选择一条邀请查看详情。"),
            on_close=self.show_guild_main_menu,
        )
        for r in rows:
            gid = int(r["guild_id"])
            inv_id = int(r["invite_id"])
            gname = str(r.get("guild_name") or "")
            label = self._guild_text("GUILD_PENDING_ROW", "{0}").format(gname)

            def _open(p: Player, iid: int = inv_id):
                self.show_guild_invite_action_menu(p, iid)

            form.add_button(label, on_click=_open)
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_main_menu,
        )
        player.send_form(form)

    def show_guild_invite_action_menu(self, player: Player, invite_id: int):
        xuid = str(player.xuid)
        inv = self.guild_system.get_invite(invite_id)
        if not inv or str(inv.get("invitee_xuid")) != xuid:
            player.send_message(self._guild_err("GUILD_NO_INVITE"))
            self.show_guild_pending_invites_menu(player)
            return
        g = self.guild_system.get_guild(int(inv["guild_id"]))
        gname = g.get("name", "") if g else ""
        form = ActionForm(
            title=self._guild_text("GUILD_INVITE_DETAIL_TITLE", "邀请详情"),
            content=self._guild_text(
                "GUILD_INVITE_DETAIL_CONTENT", "公会：{0}"
            ).format(gname),
            on_close=self.show_guild_pending_invites_menu,
        )

        def _accept(p: Player, iid: int = invite_id):
            ok, err = self.guild_system.accept_invite(str(p.xuid), iid)
            if ok:
                p.send_message(
                    self._guild_text("GUILD_ACCEPT_OK", "[弧光核心]已加入公会。")
                )
                self._update_player_name_tag(p)
            else:
                p.send_message(self._guild_err(err))
            self.show_guild_main_menu(p)

        def _decline(p: Player, iid: int = invite_id):
            ok, err = self.guild_system.decline_invite(str(p.xuid), iid)
            if ok:
                p.send_message(
                    self._guild_text("GUILD_DECLINE_OK", "[弧光核心]已拒绝邀请。")
                )
            else:
                p.send_message(self._guild_err(err))
            self.show_guild_pending_invites_menu(p)

        form.add_button(
            self._guild_text("GUILD_INVITE_ACCEPT", "接受"),
            on_click=_accept,
        )
        form.add_button(
            self._guild_text("GUILD_INVITE_DECLINE", "拒绝"),
            on_click=_decline,
        )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_pending_invites_menu,
        )
        player.send_form(form)

    def show_guild_invite_popup_live(
        self, player: Player, guild_id: int, inviter_xuid: str
    ):
        """在线邀请弹窗：不依赖 guild_invites 表，凭公会 id 与邀请人 xuid 确认后加入。"""
        g = self.guild_system.get_guild(int(guild_id))
        if not g:
            return
        gname = str(g.get("name") or "")
        ix = str(inviter_xuid or "").strip()
        inviter_disp = self.get_player_name_by_xuid(ix, return_with_title=False) or ix
        form = ActionForm(
            title=self._guild_text("GUILD_INVITE_POPUP_TITLE", "公会邀请"),
            content=self._guild_text(
                "GUILD_INVITE_POPUP_CONTENT",
                "公会：{0}\n邀请人：{1}\n\n是否加入该公会？",
            ).format(gname, inviter_disp),
            on_close=None,
        )

        def _accept(p: Player, gid: int = int(guild_id), inv: str = ix):
            ok, err = self.guild_system.join_via_live_invite(str(p.xuid), gid, inv)
            if ok:
                p.send_message(
                    self._guild_text("GUILD_ACCEPT_OK", "[弧光核心]已加入公会。")
                )
                self._update_player_name_tag(p)
            else:
                p.send_message(self._guild_err(err))

        def _decline(p: Player):
            p.send_message(
                self._guild_text("GUILD_DECLINE_OK", "[弧光核心]已拒绝邀请。")
            )

        form.add_button(
            self._guild_text("GUILD_INVITE_ACCEPT", "接受"),
            on_click=_accept,
        )
        form.add_button(
            self._guild_text("GUILD_INVITE_DECLINE", "拒绝"),
            on_click=_decline,
        )
        player.send_form(form)

    def _guild_send_live_invite(
        self, inviter: Player, target: Player, guild_id: int
    ) -> None:
        mem = self.guild_system.get_membership(str(inviter.xuid))
        if not mem or int(mem["guild_id"]) != int(guild_id):
            inviter.send_message(self._guild_err("GUILD_NO_PERMISSION"))
            self.show_guild_my_menu(inviter)
            return
        if mem.get("role") not in (ROLE_OWNER, ROLE_MANAGER):
            inviter.send_message(self._guild_err("GUILD_NO_PERMISSION"))
            self.show_guild_my_menu(inviter)
            return
        if self.guild_system.get_membership(str(target.xuid)):
            inviter.send_message(self._guild_err("GUILD_TARGET_IN_GUILD"))
            self.show_guild_invite_online_pick_menu(inviter)
            return
        self.show_guild_invite_popup_live(
            target, int(guild_id), str(inviter.xuid)
        )
        inviter.send_message(
            self._guild_text(
                "GUILD_INVITE_SENT",
                "[弧光核心]已向 {0} 发送公会邀请。",
            ).format(target.name or "?")
        )
        self.show_guild_my_menu(inviter)

    def show_guild_create_panel(self, player: Player):
        cost = self.guild_system.get_create_cost()
        info = Label(
            text=self._guild_text(
                "GUILD_CREATE_LABEL",
                "创建费用：{0}（将立即扣除）",
            ).format(self._format_money_display(cost))
        )
        name_in = TextInput(
            label=self._guild_text("GUILD_CREATE_NAME_LABEL", "公会名称（最多32字）"),
            placeholder=self._guild_text(
                "GUILD_CREATE_NAME_PLACEHOLDER", "请输入唯一公会名"
            ),
        )
        motto_in = TextInput(
            label=self._guild_text("GUILD_CREATE_MOTTO_LABEL", "公会简介（可选）"),
            placeholder=self._guild_text("GUILD_CREATE_MOTTO_PLACEHOLDER", "简介"),
            default_value="",
        )

        def _submit(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                p.send_message(
                    self._guild_text("GUILD_CREATE_INVALID", "[弧光核心]输入无效。")
                )
                self.show_guild_create_panel(p)
                return
            if len(data) < 3:
                self.show_guild_create_panel(p)
                return
            name = str(data[1]).strip()
            motto = str(data[2]).strip()
            ok, err = self.guild_system.create_guild(name, str(p.xuid), motto)
            if ok:
                p.send_message(
                    self._guild_text(
                        "GUILD_CREATE_OK",
                        "[弧光核心]公会创建成功，已扣除 {0}。",
                    ).format(self._format_money_display(cost))
                )
                self._update_player_name_tag(p)
                self.show_guild_main_menu(p)
            else:
                p.send_message(self._guild_err(err))
                self.show_guild_create_panel(p)

        form = ModalForm(
            title=self._guild_text("GUILD_CREATE_TITLE", "创建公会"),
            controls=[info, name_in, motto_in],
            on_close=self.show_guild_main_menu,
            on_submit=_submit,
        )
        player.send_form(form)

    def show_guild_my_menu(self, player: Player):
        xuid = str(player.xuid)
        mem = self.guild_system.get_membership(xuid)
        if not mem:
            self.show_guild_main_menu(player)
            return
        gid = int(mem["guild_id"])
        role = str(mem.get("role") or "")
        form = ActionForm(
            title=self._guild_text("GUILD_MY_TITLE", "我的公会"),
            content=self._guild_text("GUILD_MY_CONTENT", "管理公会事务。"),
            on_close=self.show_guild_main_menu,
        )
        form.add_button(
            self._guild_text("GUILD_BTN_MEMBER_LIST", "成员列表"),
            on_click=lambda p: self.show_guild_member_list_menu(p, readonly=True),
        )
        if role in (ROLE_OWNER, ROLE_MANAGER):
            form.add_button(
                self._guild_text("GUILD_BTN_INVITE", "邀请玩家"),
                on_click=self.show_guild_invite_online_pick_menu,
            )
            form.add_button(
                self._guild_text("GUILD_BTN_KICK", "踢出成员"),
                on_click=self.show_guild_kick_menu,
            )
        if role == ROLE_OWNER:
            form.add_button(
                self._guild_text("GUILD_BTN_SET_ROLE", "变更职级"),
                on_click=self.show_guild_set_role_pick_member,
            )
            form.add_button(
                self._guild_text("GUILD_BTN_DISBAND", "解散公会"),
                on_click=self.show_guild_disband_confirm,
            )
        if role != ROLE_OWNER:
            form.add_button(
                self._guild_text("GUILD_BTN_LEAVE", "退出公会"),
                on_click=self.show_guild_leave_confirm,
            )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_main_menu,
        )
        player.send_form(form)

    def show_guild_member_list_menu(self, player: Player, readonly: bool = True):
        mem = self.guild_system.get_membership(str(player.xuid))
        if not mem:
            self.show_guild_main_menu(player)
            return
        gid = int(mem["guild_id"])
        members = self.guild_system.list_members(gid)
        lines = []
        for m in members:
            xu = str(m.get("xuid") or "")
            rn = self.get_player_name_by_xuid(xu, return_with_title=False) or xu
            rl = self._guild_text(
                f"GUILD_ROLE_{str(m.get('role') or '').upper()}",
                str(m.get("role") or ""),
            )
            lines.append(f"{rn}  [{rl}]")
        form = ActionForm(
            title=self._guild_text("GUILD_MEMBER_LIST_TITLE", "成员列表"),
            content="\n".join(lines)
            if lines
            else self._guild_text("GUILD_MEMBER_LIST_EMPTY", "暂无成员"),
            on_close=self.show_guild_my_menu,
        )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_my_menu,
        )
        player.send_form(form)

    def show_guild_invite_online_pick_menu(self, player: Player):
        """仅邀请当前在线、且未加入任何公会的玩家；点击后对方弹出确认，不入库邀请表。"""
        mem = self.guild_system.get_membership(str(player.xuid))
        if not mem or mem.get("role") not in (ROLE_OWNER, ROLE_MANAGER):
            player.send_message(self._guild_err("GUILD_NO_PERMISSION"))
            self.show_guild_my_menu(player)
            return
        gid = int(mem["guild_id"])
        try:
            online = list(getattr(self.server, "online_players", []) or [])
        except Exception:
            online = []
        candidates: List[Player] = []
        self_xuid = str(player.xuid)
        for op in online:
            try:
                if str(op.xuid) == self_xuid:
                    continue
                if self.guild_system.get_membership(str(op.xuid)):
                    continue
            except Exception:
                continue
            candidates.append(op)
        candidates.sort(key=lambda pl: (pl.name or "").lower())

        form = ActionForm(
            title=self._guild_text("GUILD_INVITE_ONLINE_TITLE", "邀请在线玩家"),
            content=self._guild_text(
                "GUILD_INVITE_ONLINE_CONTENT",
                "选择一名未加入公会的在线玩家，对方将收到确认窗口。",
            ),
            on_close=self.show_guild_my_menu,
        )
        if not candidates:
            form.add_button(
                self._guild_text(
                    "GUILD_INVITE_ONLINE_EMPTY",
                    "当前没有可邀请的在线玩家",
                ),
                on_click=self.show_guild_my_menu,
            )
        else:
            for tgt in candidates:
                label = tgt.name or "?"

                def _pick(inviter: Player, target: Player = tgt, g_id: int = gid):
                    self._guild_send_live_invite(inviter, target, g_id)

                form.add_button(label, on_click=_pick)
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_my_menu,
        )
        player.send_form(form)

    def show_guild_kick_menu(self, player: Player):
        actor_xuid = str(player.xuid)
        mem = self.guild_system.get_membership(actor_xuid)
        if not mem or mem.get("role") not in (ROLE_OWNER, ROLE_MANAGER):
            player.send_message(self._guild_err("GUILD_NO_PERMISSION"))
            self.show_guild_my_menu(player)
            return
        gid = int(mem["guild_id"])
        role = str(mem.get("role") or "")
        members = self.guild_system.list_members(gid)
        targets: List[Dict[str, Any]] = []
        for m in members:
            tx = str(m.get("xuid") or "")
            tr = str(m.get("role") or "")
            if tx == actor_xuid:
                continue
            if tr == ROLE_OWNER:
                continue
            if role == ROLE_MANAGER and tr != ROLE_MEMBER:
                continue
            targets.append(m)
        form = ActionForm(
            title=self._guild_text("GUILD_KICK_TITLE", "踢出成员"),
            content=self._guild_text("GUILD_KICK_CONTENT", "选择要移出公会的成员。"),
            on_close=self.show_guild_my_menu,
        )
        if not targets:
            form.add_button(
                self._guild_text("GUILD_KICK_NONE", "暂无可踢出的成员"),
                on_click=self.show_guild_my_menu,
            )
        for m in targets:
            tx = str(m.get("xuid") or "")
            disp = self.get_player_name_by_xuid(tx, return_with_title=False) or tx

            def _kick(p: Player, target: str = tx):
                ok, err = self.guild_system.kick(str(p.xuid), target)
                if ok:
                    p.send_message(
                        self._guild_text("GUILD_KICK_OK", "[弧光核心]已移出该成员。")
                    )
                    self._refresh_player_name_tag_by_xuid(target)
                else:
                    p.send_message(self._guild_err(err))
                self.show_guild_my_menu(p)

            form.add_button(disp, on_click=_kick)
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_my_menu,
        )
        player.send_form(form)

    def show_guild_set_role_pick_member(self, player: Player):
        actor_xuid = str(player.xuid)
        mem = self.guild_system.get_membership(actor_xuid)
        if not mem or mem.get("role") != ROLE_OWNER:
            player.send_message(self._guild_err("GUILD_NO_PERMISSION"))
            self.show_guild_my_menu(player)
            return
        gid = int(mem["guild_id"])
        members = self.guild_system.list_members(gid)
        form = ActionForm(
            title=self._guild_text("GUILD_SET_ROLE_PICK_TITLE", "变更职级"),
            content=self._guild_text(
                "GUILD_SET_ROLE_PICK_CONTENT", "选择一名成员（不含会长）。"
            ),
            on_close=self.show_guild_my_menu,
        )
        any_btn = False
        for m in members:
            tx = str(m.get("xuid") or "")
            if tx == actor_xuid:
                continue
            if str(m.get("role") or "") == ROLE_OWNER:
                continue
            any_btn = True
            disp = self.get_player_name_by_xuid(tx, return_with_title=False) or tx

            def _pick(p: Player, target: str = tx):
                self.show_guild_set_role_actions(p, target)

            form.add_button(disp, on_click=_pick)
        if not any_btn:
            form.add_button(
                self._guild_text("GUILD_SET_ROLE_NOBODY", "没有其他成员"),
                on_click=self.show_guild_my_menu,
            )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_my_menu,
        )
        player.send_form(form)

    def show_guild_set_role_actions(self, player: Player, target_xuid: str):
        form = ActionForm(
            title=self._guild_text("GUILD_SET_ROLE_ACTION_TITLE", "职级操作"),
            content=self._guild_text("GUILD_SET_ROLE_ACTION_CONTENT", "选择新职级。"),
            on_close=self.show_guild_set_role_pick_member,
        )

        def _set(p: Player, new_r: str):
            ok, err = self.guild_system.set_role(str(p.xuid), target_xuid, new_r)
            if ok:
                p.send_message(
                    self._guild_text("GUILD_SET_ROLE_OK", "[弧光核心]职级已更新。")
                )
            else:
                p.send_message(self._guild_err(err))
            self.show_guild_my_menu(p)

        form.add_button(
            self._guild_text("GUILD_ROLE_PROMOTE_MANAGER", "设为管理者"),
            on_click=lambda p: _set(p, ROLE_MANAGER),
        )
        form.add_button(
            self._guild_text("GUILD_ROLE_DEMOTE_MEMBER", "设为普通成员"),
            on_click=lambda p: _set(p, ROLE_MEMBER),
        )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "返回"),
            on_click=self.show_guild_set_role_pick_member,
        )
        player.send_form(form)

    def show_guild_leave_confirm(self, player: Player):
        form = ActionForm(
            title=self._guild_text("GUILD_LEAVE_TITLE", "退出公会"),
            content=self._guild_text(
                "GUILD_LEAVE_CONFIRM", "确定退出当前公会吗？"
            ),
            on_close=self.show_guild_my_menu,
        )

        def _yes(p: Player):
            ok, err = self.guild_system.leave(str(p.xuid))
            if ok:
                p.send_message(
                    self._guild_text("GUILD_LEAVE_OK", "[弧光核心]已退出公会。")
                )
                self._update_player_name_tag(p)
            else:
                p.send_message(self._guild_err(err))
            self.show_guild_main_menu(p)

        form.add_button(
            self._guild_text("GUILD_CONFIRM_YES", "确定"),
            on_click=_yes,
        )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "取消"),
            on_click=self.show_guild_my_menu,
        )
        player.send_form(form)

    def show_guild_disband_confirm(self, player: Player):
        form = ActionForm(
            title=self._guild_text("GUILD_DISBAND_TITLE", "解散公会"),
            content=self._guild_text(
                "GUILD_DISBAND_CONFIRM",
                "解散后所有成员将被移除，且不可恢复。确定吗？",
            ),
            on_close=self.show_guild_my_menu,
        )

        def _yes(p: Player):
            member_xuids: List[str] = []
            try:
                mem = self.guild_system.get_membership(str(p.xuid))
                if mem:
                    for row in self.guild_system.list_members(int(mem["guild_id"])):
                        xu = str(row.get("xuid") or "").strip()
                        if xu:
                            member_xuids.append(xu)
            except Exception:
                member_xuids = []
            ok, err = self.guild_system.disband(str(p.xuid))
            if ok:
                p.send_message(
                    self._guild_text("GUILD_DISBAND_OK", "[弧光核心]公会已解散。")
                )
                for xu in member_xuids:
                    self._refresh_player_name_tag_by_xuid(xu)
            else:
                p.send_message(self._guild_err(err))
            self.show_guild_main_menu(p)

        form.add_button(
            self._guild_text("GUILD_CONFIRM_YES_DISBAND", "确定解散"),
            on_click=_yes,
        )
        form.add_button(
            self._guild_text("RETURN_BUTTON_TEXT", "取消"),
            on_click=self.show_guild_my_menu,
        )
        player.send_form(form)

    # Bank
    def show_bank_main_menu(self, player: Player):
        bank_main_menu = ActionForm(
            title=self.language_manager.GetText('BANK_MAIN_MENU_TITLE'),
            content=self.language_manager.GetText('BANK_MAIN_MENU_BALANCE_CONTENT').format(
                self._format_money_display(self.get_player_money(player))
            )
        )
        bank_main_menu.add_button(self.language_manager.GetText('BANK_MAIN_MENU_TRANSFER_BUTTON_TEXT'), on_click=self.show_transfer_panel)
        bank_main_menu.add_button(self.language_manager.GetText('BANK_MAIN_MENU_MONEY_RANK_BUTTON_TEXT'),on_click=self.show_money_rank_panel)
        # 返回
        bank_main_menu.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                                  on_click=self.show_main_menu)
        player.send_form(bank_main_menu)

    def show_transfer_panel(self, player: Player):
        """显示在线玩家选择面板"""
        online_players = self.server.online_players
        # 过滤掉自己
        available_players = [p for p in online_players if p.name != player.name]
        
        if not available_players:
            # 没有其他在线玩家
            no_players_form = ActionForm(
                title=self.language_manager.GetText('TRANSFER_PANEL_TITLE'),
                content=self.language_manager.GetText('TRANSFER_NO_ONLINE_PLAYERS_TEXT'),
                on_close=self.show_bank_main_menu
            )
            player.send_form(no_players_form)
            return
        
        # 创建玩家选择面板
        player_select_panel = ActionForm(
            title=self.language_manager.GetText('TRANSFER_PANEL_TITLE'),
            content=self.language_manager.GetText('TRANSFER_SELECT_PLAYER_CONTENT').format(
                self._format_money_display(self.get_player_money(player))
            )
        )
        
        # 为每个在线玩家添加按钮
        for target_player in available_players:
            player_select_panel.add_button(
                f"{target_player.name}",
                on_click=lambda sender, target=target_player: self.show_transfer_amount_panel(sender, target)
            )
        
        # 添加返回按钮
        player_select_panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_bank_main_menu
        )
        
        player.send_form(player_select_panel)
    
    def show_transfer_amount_panel(self, player: Player, target_player: Player):
        """显示转账金额输入面板"""
        # 添加信息标签来显示转账信息
        info_label = Label(
            text=self.language_manager.GetText('TRANSFER_PANEL_INFO_LABEL').format(
                target_player.name,
                self._format_money_display(self.get_player_money(player))
            )
        )
        
        money_amount_input = TextInput(
            label=self.language_manager.GetText('TRANSFER_PANEL_MONEY_AMOUNT_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('TRANSFER_PANEL_MONEY_AMOUNT_INPUT_PLACEHOLDER'),
            default_value='0'
        )

        def try_transfer(sender: Player, json_str: str):
            data = json.loads(json_str)
            # 直接使用目标玩家对象和金额进行转账
            error_code, receive_player, amount = self._validate_transfer_data_new(sender, target_player, data[1])
            if error_code == 0:
                if not self.decrease_player_money(sender, amount):
                    self.report_arc_error(
                        "BANK12",
                        f"bank transfer decrease failed sender={sender.name!r} receiver={receive_player.name!r} amount={amount!r}",
                        sender,
                    )
                    result_str = self.language_manager.GetText("TRANSFER_FAIL_DB_TEXT").format("BANK12")
                elif not self.increase_player_money(receive_player, amount):
                    self.report_arc_error(
                        "BANK13",
                        f"bank transfer increase failed after decrease; attempting rollback sender={sender.name!r} receiver={receive_player.name!r} amount={amount!r}",
                        sender,
                    )
                    if not self.increase_player_money(sender, amount):
                        self.report_arc_error(
                            "BANK14",
                            f"bank transfer rollback to sender FAILED sender={sender.name!r} amount={amount!r}",
                            sender,
                        )
                        result_str = self.language_manager.GetText("TRANSFER_FAIL_DB_TEXT").format("BANK14")
                    else:
                        result_str = self.language_manager.GetText("TRANSFER_FAIL_DB_TEXT").format("BANK13")
                else:
                    receive_player.send_message(self.language_manager.GetText('RECEIVE_PLAYER_TRANSFER_MESSAGE').format(
                        sender.name,
                        self._format_money_display(amount),
                        self._format_money_display(self.get_player_money(receive_player))))
                    result_str = self.language_manager.GetText('TRANSFER_COMPLETED_HINT_TEXT').format(
                        receive_player.name,
                        self._format_money_display(amount),
                        self._format_money_display(self.get_player_money(sender))
                    )
            else:
                result_str = self.language_manager.GetText(f'TRANSFER_ERROR_{error_code}_TEXT')
                if error_code == 2:
                    result_str = result_str.format(target_player.name)
            result_form = ActionForm(
                title=self.language_manager.GetText('TRANSFER_RESULT_PANEL_TITLE'),
                content=result_str,
                on_close=self.show_bank_main_menu
            )
            sender.send_form(result_form)

        transfer_panel = ModalForm(
            title=self.language_manager.GetText('TRANSFER_PANEL_TITLE'),
            controls=[info_label, money_amount_input],
            on_close=lambda sender: self.show_transfer_panel(sender),
            on_submit=try_transfer
        )
        player.send_form(transfer_panel)

    def show_small_horn_buy_panel(
        self,
        player: Player,
        hint_message: Optional[str] = None,
        *,
        on_panel_close: Any = None,
    ):
        """显示小喇叭购买面板。on_panel_close 关闭表单时回调，默认回主菜单。"""
        close_cb = on_panel_close if on_panel_close is not None else self.show_main_menu
        panel_title = self.language_manager.GetText('SMALL_HORN_MENU_TITLE')
        if hint_message:
            panel_title = hint_message

        info_label = Label(
            text=self.language_manager.GetText('SMALL_HORN_MENU_CONTENT').format(
                self._format_money_display(self.small_horn_price_per_hour),
                self._format_money_display(self.get_player_money(player))
            )
        )
        valid_hours_input = TextInput(
            label=self.language_manager.GetText('SMALL_HORN_HOURS_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('SMALL_HORN_HOURS_INPUT_PLACEHOLDER'),
            default_value='1'
        )
        content_input = TextInput(
            label=self.language_manager.GetText('SMALL_HORN_CONTENT_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('SMALL_HORN_CONTENT_INPUT_PLACEHOLDER')
        )

        def try_buy_small_horn(sender: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                self.show_small_horn_buy_panel(
                    sender, self.language_manager.GetText('SMALL_HORN_BUY_INVALID_INPUT'), on_panel_close=close_cb
                )
                return

            if len(data) < 3:
                self.show_small_horn_buy_panel(
                    sender, self.language_manager.GetText('SMALL_HORN_BUY_INVALID_INPUT'), on_panel_close=close_cb
                )
                return

            valid_hours_text = str(data[1]).strip()
            content = str(data[2]).strip()
            try:
                valid_hours = int(valid_hours_text)
            except (TypeError, ValueError):
                self.show_small_horn_buy_panel(
                    sender, self.language_manager.GetText('SMALL_HORN_BUY_INVALID_HOURS'), on_panel_close=close_cb
                )
                return

            if valid_hours <= 0:
                self.show_small_horn_buy_panel(
                    sender, self.language_manager.GetText('SMALL_HORN_BUY_INVALID_HOURS'), on_panel_close=close_cb
                )
                return

            if not content:
                self.show_small_horn_buy_panel(
                    sender, self.language_manager.GetText('SMALL_HORN_BUY_EMPTY_CONTENT'), on_panel_close=close_cb
                )
                return

            total_cost = float(valid_hours * self.small_horn_price_per_hour)
            if total_cost > 0 and not self.judge_if_player_has_enough_money(sender, total_cost):
                sender.send_message(
                    self.language_manager.GetText('SMALL_HORN_BUY_NO_MONEY').format(
                        self._format_money_display(total_cost),
                        self._format_money_display(self.get_player_money(sender))
                    )
                )
                self.show_small_horn_buy_panel(sender, on_panel_close=close_cb)
                return

            if total_cost > 0 and not self.decrease_player_money(sender, total_cost):
                sender.send_message(self.language_manager.GetText('SMALL_HORN_BUY_PAY_FAILED'))
                self.show_small_horn_buy_panel(sender, on_panel_close=close_cb)
                return

            start_time = datetime.now()
            end_time = start_time + timedelta(hours=valid_hours)
            success = self.database_manager.insert(
                'small_horn_orders',
                {
                    'xuid': str(sender.xuid),
                    'content': content,
                    'start_time': start_time.isoformat(timespec='seconds'),
                    'valid_hours': valid_hours,
                    'end_time': end_time.isoformat(timespec='seconds'),
                    'created_at': start_time.isoformat(timespec='seconds'),
                }
            )
            if not success:
                if total_cost > 0:
                    self.increase_player_money(sender, total_cost)
                sender.send_message(self.language_manager.GetText('SMALL_HORN_BUY_SAVE_FAILED'))
                self.show_small_horn_buy_panel(sender, on_panel_close=close_cb)
                return

            sender.send_message(
                self.language_manager.GetText('SMALL_HORN_BUY_SUCCESS').format(
                    valid_hours,
                    self._format_money_display(total_cost),
                    self._format_money_display(self.get_player_money(sender))
                )
            )
            self.show_main_menu(sender)

        buy_form = ModalForm(
            title=panel_title,
            controls=[info_label, valid_hours_input, content_input],
            on_close=close_cb,
            on_submit=try_buy_small_horn
        )
        player.send_form(buy_form)

    def _validate_transfer_data(self, player: Player, data: list) -> tuple[int, Optional[Player], Optional[int]]:
        """
        验证转账数据
        :param player: 发起转账的玩家
        :param data: 转账数据[接收玩家名, 金额]
        :return: (错误码, 接收玩家对象, 转账金额)
        """
        # 初始化返回值
        error_code = 0
        receive_player = None
        amount = None

        # 检查数据格式
        if not isinstance(data, list) or len(data) != 2:
            return 1, None, None

        # 获取并检查接收玩家
        receive_player = self.server.get_player(data[0])
        if receive_player is None:
            return 2, None, None

        # 检查是否自己给自己转账
        if receive_player.name == player.name:
            return 6, receive_player, None

        # 检查并转换金额
        try:
            amount = int(data[1])
        except (ValueError, TypeError):
            return 3, receive_player, None

        # 检查金额是否大于0
        if amount <= 0:
            return 5, receive_player, amount

        # 检查玩家余额是否足够
        if not self.judge_if_player_has_enough_money(player, amount):
            return 4, receive_player, amount

        return error_code, receive_player, amount

    def _validate_transfer_data_new(self, player: Player, target_player: Player, amount_str: str) -> tuple[int, Optional[Player], Optional[float]]:
        """
        验证新转账流程的数据
        :param player: 发起转账的玩家
        :param target_player: 目标玩家对象
        :param amount_str: 转账金额字符串（支持小数，精确到分）
        :return: (错误码, 接收玩家对象, 转账金额)
        """
        error_code = 0
        amount = None

        if target_player not in self.server.online_players:
            return 2, target_player, None

        if target_player.name == player.name:
            return 6, target_player, None

        try:
            amount = self._round_money(float(amount_str))
        except (ValueError, TypeError):
            return 3, target_player, None

        if amount <= 0:
            return 5, target_player, amount

        if not self.judge_if_player_has_enough_money(player, amount):
            return 4, target_player, amount

        return error_code, target_player, amount

    def show_money_rank_panel(self, player: Player):
        # 为了在隐藏 OP 时仍能展示足够名次，这里多取一些再在内存中过滤
        initial_count = 20 if self.hide_op_in_money_ranking else 10
        rich_entries = self.get_top_richest_players(initial_count)

        filtered_entries = []
        for entry in rich_entries:
            if self.hide_op_in_money_ranking and entry.get("is_op") is True:
                # 隐藏 OP 玩家
                continue
            filtered_entries.append(entry)
            if len(filtered_entries) >= 10:
                break

        rank_lines = []
        for index, entry in enumerate(filtered_entries, start=1):
            rank_lines.append(
                self.language_manager.GetText("MONEY_RANK_INFO_TEXT").format(
                    index,
                    entry.get("display_name", ""),
                    self._format_money_display(entry.get("money", 0.0)),
                )
            )

        rank_content = "\n".join(rank_lines)
        player_balance = self._format_money_display(self.get_player_money(player))
        player_rank = self.get_player_money_rank(player)

        rank_panel = ActionForm(
            title=self.language_manager.GetText("MONEY_RANK_PANEL_TITLE"),
            content=rank_content
            + "\n"
            + self.language_manager.GetText("MONEY_RANK_PLYAER_RANK_INFO_TEXT").format(
                player_balance, player_rank
            ),
            on_close=self.show_bank_main_menu,
        )
        player.send_form(rank_panel)
    
    # Shop menu
    def show_shop_menu(self, player: Player):
        player.perform_command('us')

    def show_button_shop_menu(self, player: Player):
        player.perform_command('shop')

    # Teleport menu
    def show_teleport_menu(self, player: Player):
        teleport_main_menu = ActionForm(
            title=self.language_manager.GetText('TELEPORT_MAIN_MENU_TITLE'),
            content=self.language_manager.GetText('TELEPORT_MAIN_MENU_CONTENT')
        )
        
        # 公共传送点按钮
        public_warp_text = self.language_manager.GetText('TELEPORT_MAIN_MENU_PUBLIC_WARP_BUTTON')
        if self.teleport_system.teleport_cost_public_warp > 0:
            public_warp_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(public_warp_text, self.teleport_system.teleport_cost_public_warp)
        teleport_main_menu.add_button(public_warp_text, on_click=self.show_public_warp_menu)
        
        # 私人传送点按钮
        home_text = self.language_manager.GetText('TELEPORT_MAIN_MENU_HOME_BUTTON')
        if self.teleport_system.teleport_cost_home > 0:
            home_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(home_text, self.teleport_system.teleport_cost_home)
        teleport_main_menu.add_button(home_text, on_click=self.show_home_menu)
        
        # 随机传送按钮
        if self.teleport_system.enable_random_teleport:
            random_text = self.language_manager.GetText('TELEPORT_MAIN_MENU_RANDOM_BUTTON')
            if self.teleport_system.teleport_cost_random > 0:
                random_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(random_text, self.teleport_system.teleport_cost_random)
            teleport_main_menu.add_button(random_text, on_click=self.start_random_teleport)
        
        # 如果玩家有死亡位置记录，显示返回死亡地点的按钮
        if self.teleport_system.has_death_location(player.name):
            death_location = self.teleport_system.get_death_location(player.name)
            death_text = self.language_manager.GetText('TELEPORT_MAIN_MENU_DEATH_LOCATION_BUTTON').format(death_location['dimension'])
            if self.teleport_system.teleport_cost_death_location > 0:
                death_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(death_text, self.teleport_system.teleport_cost_death_location)
            teleport_main_menu.add_button(death_text, on_click=self.teleport_to_death_location)
        
        # 玩家传送请求按钮
        player_request_text = self.language_manager.GetText('TELEPORT_MAIN_MENU_PLAYER_REQUEST_BUTTON')
        if self.teleport_system.teleport_cost_player > 0:
            player_request_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(player_request_text, self.teleport_system.teleport_cost_player)
        teleport_main_menu.add_button(player_request_text, on_click=self.show_player_teleport_request_menu)

        # 跨服传送按钮
        teleport_main_menu.add_button(
            self.language_manager.GetText('TELEPORT_MAIN_MENU_CROSS_SERVER_BUTTON'),
            on_click=self.show_cross_server_menu
        )
        
        # 返回
        teleport_main_menu.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                                      on_click=self.show_main_menu)
        player.send_form(teleport_main_menu)

    # Teleport System（委托 TeleportSystem）
    def create_public_warp(self, warp_name: str, dimension: str, x: float, y: float, z: float, creator_xuid: str) -> bool:
        return self.teleport_system.create_public_warp(warp_name, dimension, x, y, z, creator_xuid)

    def delete_public_warp(self, warp_name: str) -> bool:
        return self.teleport_system.delete_public_warp(warp_name)

    def get_public_warp(self, warp_name: str) -> Optional[Dict[str, Any]]:
        return self.teleport_system.get_public_warp(warp_name)

    def get_all_public_warps(self) -> Dict[str, Dict[str, Any]]:
        return self.teleport_system.get_all_public_warps()

    def public_warp_exists(self, warp_name: str) -> bool:
        return self.teleport_system.public_warp_exists(warp_name)

    def create_player_home(self, owner_xuid: str, home_name: str, dimension: str, x: float, y: float, z: float) -> bool:
        return self.teleport_system.create_player_home(owner_xuid, home_name, dimension, x, y, z)

    def delete_player_home(self, owner_xuid: str, home_name: str) -> bool:
        return self.teleport_system.delete_player_home(owner_xuid, home_name)

    def get_player_home(self, owner_xuid: str, home_name: str) -> Optional[Dict[str, Any]]:
        return self.teleport_system.get_player_home(owner_xuid, home_name)

    def get_player_homes(self, owner_xuid: str) -> Dict[str, Dict[str, Any]]:
        return self.teleport_system.get_player_homes(owner_xuid)

    def get_player_home_count(self, owner_xuid: str) -> int:
        return self.teleport_system.get_player_home_count(owner_xuid)

    def player_home_exists(self, owner_xuid: str, home_name: str) -> bool:
        return self.teleport_system.player_home_exists(owner_xuid, home_name)

    # Teleport System UI
    def show_public_warp_menu(self, player: Player):
        """显示公共传送点菜单"""
        public_warps = self.get_all_public_warps()
        if not public_warps:
            no_warp_panel = ActionForm(
                title=self.language_manager.GetText('PUBLIC_WARP_MENU_TITLE'),
                content=self.language_manager.GetText('PUBLIC_WARP_NO_WARP_CONTENT'),
                on_close=self.show_teleport_menu
            )
            player.send_form(no_warp_panel)
            return

        warp_menu = ActionForm(
            title=self.language_manager.GetText('PUBLIC_WARP_MENU_TITLE'),
            content=self.language_manager.GetText('PUBLIC_WARP_MENU_CONTENT').format(len(public_warps)),
            on_close=self.show_teleport_menu
        )
        
        for warp_name, warp_info in public_warps.items():
            creator_name = self.get_player_name_by_xuid(warp_info['created_by']) or 'Unknown'
            warp_button_text = self.language_manager.GetText('PUBLIC_WARP_BUTTON_TEXT').format(warp_name, warp_info['dimension'], creator_name)
            # 如果公共传送点收费，显示价格
            if self.teleport_system.teleport_cost_public_warp > 0:
                warp_button_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(warp_button_text, self.teleport_system.teleport_cost_public_warp)
            warp_menu.add_button(
                warp_button_text,
                on_click=lambda p=player, w_name=warp_name, w_info=warp_info: self.teleport_to_public_warp(p, w_name, w_info)
            )
        
        player.send_form(warp_menu)

    def _get_all_cross_server_targets(self) -> list[Dict[str, Any]]:
        return self.database_manager.query_all(
            "SELECT id, server_name, server_host, server_port FROM cross_server_targets ORDER BY id ASC"
        )

    def _create_cross_server_target(self, server_name: str, server_host: str, server_port: int) -> bool:
        now_str = datetime.now().isoformat(timespec='seconds')
        return self.database_manager.insert(
            'cross_server_targets',
            {
                'server_name': server_name,
                'server_host': server_host,
                'server_port': int(server_port),
                'created_at': now_str,
            }
        )

    def _update_cross_server_target(self, target_id: int, server_name: str, server_host: str, server_port: int) -> bool:
        return self.database_manager.update(
            'cross_server_targets',
            {
                'server_name': server_name,
                'server_host': server_host,
                'server_port': int(server_port),
            },
            'id = ?',
            (int(target_id),)
        )

    def _delete_cross_server_target(self, target_id: int) -> bool:
        return self.database_manager.delete('cross_server_targets', 'id = ?', (int(target_id),))

    def show_cross_server_menu(self, player: Player, on_close=None):
        """显示跨服传送菜单。on_close 默认返回传送主菜单；单独打开时可传入例如 show_main_menu。"""
        back_menu = on_close if on_close is not None else self.show_teleport_menu
        targets = self._get_all_cross_server_targets()
        if not targets:
            no_target_panel = ActionForm(
                title=self.language_manager.GetText('CROSS_SERVER_MENU_TITLE'),
                content=self.language_manager.GetText('CROSS_SERVER_MENU_EMPTY'),
                on_close=back_menu
            )
            no_target_panel.add_button(
                self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                on_click=back_menu
            )
            player.send_form(no_target_panel)
            return

        cross_server_menu = ActionForm(
            title=self.language_manager.GetText('CROSS_SERVER_MENU_TITLE'),
            content=self.language_manager.GetText('CROSS_SERVER_MENU_CONTENT').format(len(targets)),
            on_close=back_menu
        )
        for target in targets:
            server_name = str(target.get('server_name') or '').strip()
            server_host = str(target.get('server_host') or '').strip()
            server_port = int(target.get('server_port') or 19132)
            cross_server_menu.add_button(
                self.language_manager.GetText('CROSS_SERVER_TARGET_BUTTON').format(
                    server_name, server_host, server_port
                ),
                on_click=lambda p=player, h=server_host, po=server_port, n=server_name: self.transfer_player_to_server(p, h, po, n)
            )
        cross_server_menu.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=back_menu
        )
        player.send_form(cross_server_menu)

    def transfer_player_to_server(self, player: Player, server_host: str, server_port: int, server_name: str):
        """执行跨服传送。"""
        try:
            player.send_message(self.language_manager.GetText('CROSS_SERVER_TRANSFER_START').format(server_name))
            player.transfer(server_host, int(server_port))
        except Exception as e:
            self.logger.error(f"[ARC Core]Cross server transfer failed: {str(e)}")
            player.send_message(self.language_manager.GetText('CROSS_SERVER_TRANSFER_FAILED').format(server_name))

    def show_home_menu(self, player: Player):
        """显示玩家传送点菜单"""
        player_homes = self.get_player_homes(str(player.xuid))
        home_count = len(player_homes)
        
        home_menu = ActionForm(
            title=self.language_manager.GetText('HOME_MENU_TITLE'),
            content=self.language_manager.GetText('HOME_MENU_CONTENT').format(home_count, self.teleport_system.max_player_home_num),
            on_close=self.show_teleport_menu
        )
        
        # 显示现有传送点
        for home_name, home_info in player_homes.items():
            home_menu.add_button(
                self.language_manager.GetText('HOME_BUTTON_TEXT').format(home_name, home_info['dimension']),
                on_click=lambda p=player, h_name=home_name, h_info=home_info: self.show_home_detail_menu(p, h_name, h_info)
            )
        
        # 添加新传送点按钮
        if home_count < self.teleport_system.max_player_home_num:
            home_menu.add_button(
                self.language_manager.GetText('HOME_ADD_NEW_BUTTON'),
                on_click=self.show_create_home_panel
            )
        
        player.send_form(home_menu)

    def show_home_detail_menu(self, player: Player, home_name: str, home_info: Dict[str, Any]):
        """显示传送点详情菜单"""
        detail_menu = ActionForm(
            title=self.language_manager.GetText('HOME_DETAIL_MENU_TITLE').format(home_name),
            content=self.language_manager.GetText('HOME_DETAIL_MENU_CONTENT').format(
                home_name,
                home_info['dimension'],
                int(home_info['x']),
                int(home_info['y']),
                int(home_info['z'])
            ),
            on_close=self.show_home_menu
        )
        
        # 私人传送点传送按钮（显示价格）
        home_teleport_text = self.language_manager.GetText('HOME_TELEPORT_BUTTON')
        if self.teleport_system.teleport_cost_home > 0:
            home_teleport_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(home_teleport_text, self.teleport_system.teleport_cost_home)
        detail_menu.add_button(
            home_teleport_text,
            on_click=lambda p=player, h_name=home_name, h_info=home_info: self.teleport_to_home(p, h_name, h_info)
        )
        
        detail_menu.add_button(
            self.language_manager.GetText('HOME_DELETE_BUTTON'),
            on_click=lambda p=player, h_name=home_name: self.confirm_delete_home(p, h_name)
        )
        
        player.send_form(detail_menu)

    def show_create_home_panel(self, player: Player):
        """显示创建传送点面板"""
        home_name_input = TextInput(
            label=self.language_manager.GetText('CREATE_HOME_NAME_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('CREATE_HOME_NAME_INPUT_PLACEHOLDER'),
            default_value=f"{player.name}之家"
        )

        def try_create_home(player: Player, json_str: str):
            data = json.loads(json_str)
            if not data or not data[0].strip():
                player.send_message(self.language_manager.GetText('CREATE_HOME_EMPTY_NAME_ERROR'))
                self.show_create_home_panel(player)
                return
            
            home_name = data[0].strip()
            if self.player_home_exists(str(player.xuid), home_name):
                player.send_message(self.language_manager.GetText('CREATE_HOME_NAME_EXISTS_ERROR').format(home_name))
                self.show_create_home_panel(player)
                return
            
            # 创建传送点
            success = self.create_player_home(
                str(player.xuid),
                home_name,
                player.location.dimension.name,
                player.location.x,
                player.location.y,
                player.location.z
            )
            
            if success:
                player.send_message(self.language_manager.GetText('CREATE_HOME_SUCCESS').format(home_name))
            else:
                player.send_message(self.language_manager.GetText('CREATE_HOME_FAILED'))
            
            self.show_home_menu(player)

        create_panel = ModalForm(
            title=self.language_manager.GetText('CREATE_HOME_PANEL_TITLE'),
            controls=[home_name_input],
            on_close=self.show_home_menu,
            on_submit=try_create_home
        )
        
        player.send_form(create_panel)

    def confirm_delete_home(self, player: Player, home_name: str):
        """确认删除传送点"""
        confirm_panel = ActionForm(
            title=self.language_manager.GetText('CONFIRM_DELETE_HOME_TITLE'),
            content=self.language_manager.GetText('CONFIRM_DELETE_HOME_CONTENT').format(home_name),
            on_close=self.show_home_menu
        )
        
        confirm_panel.add_button(
            self.language_manager.GetText('CONFIRM_DELETE_HOME_BUTTON'),
            on_click=lambda p=player, h_name=home_name: self.delete_home_confirmed(p, h_name)
        )
        
        player.send_form(confirm_panel)

    def delete_home_confirmed(self, player: Player, home_name: str):
        """确认删除传送点"""
        success = self.delete_player_home(str(player.xuid), home_name)
        if success:
            player.send_message(self.language_manager.GetText('DELETE_HOME_SUCCESS').format(home_name))
        else:
            player.send_message(self.language_manager.GetText('DELETE_HOME_FAILED'))
        self.show_home_menu(player)

    # Teleport Functions
    def teleport_to_public_warp(self, player: Player, warp_name: str, warp_info: Dict[str, Any]):
        """传送到公共传送点"""
        # 检查费用
        if self.teleport_system.teleport_cost_public_warp > 0:
            player_money = self.get_player_money(player)
            if player_money < self.teleport_system.teleport_cost_public_warp:
                player.send_message(self.language_manager.GetText('TELEPORT_COST_NOT_ENOUGH_MONEY').format(
                    self._format_money_display(self.teleport_system.teleport_cost_public_warp),
                    self._format_money_display(player_money)
                ))
                return
            
            # 扣除费用
            if self.decrease_player_money(player, self.teleport_system.teleport_cost_public_warp):
                player.send_message(self.language_manager.GetText('TELEPORT_COST_DEDUCTED').format(
                    self._format_money_display(self.teleport_system.teleport_cost_public_warp),
                    self._format_money_display(self.get_player_money(player))
                ))
            else:
                self.report_arc_error(
                    "TP1",
                    f"teleport_to_public_warp decrease failed warp={warp_name!r} cost={self.teleport_system.teleport_cost_public_warp!r}",
                    player,
                )
                return
        
        self.start_teleport_to_position_countdown(player, warp_name, (warp_info['x'], warp_info['y'], warp_info['z']), 'PUBLIC_WARP', warp_info['dimension'])

    def teleport_to_home(self, player: Player, home_name: str, home_info: Dict[str, Any]):
        """传送到玩家传送点"""
        # 检查费用
        if self.teleport_system.teleport_cost_home > 0:
            player_money = self.get_player_money(player)
            if player_money < self.teleport_system.teleport_cost_home:
                player.send_message(self.language_manager.GetText('TELEPORT_COST_NOT_ENOUGH_MONEY').format(
                    self._format_money_display(self.teleport_system.teleport_cost_home),
                    self._format_money_display(player_money)
                ))
                return
            
            # 扣除费用
            if self.decrease_player_money(player, self.teleport_system.teleport_cost_home):
                player.send_message(self.language_manager.GetText('TELEPORT_COST_DEDUCTED').format(
                    self._format_money_display(self.teleport_system.teleport_cost_home),
                    self._format_money_display(self.get_player_money(player))
                ))
            else:
                self.report_arc_error(
                    "TP2",
                    f"teleport_to_home decrease failed home={home_name!r} cost={self.teleport_system.teleport_cost_home!r}",
                    player,
                )
                return
        
        self.start_teleport_to_position_countdown(player, home_name, (home_info['x'], home_info['y'], home_info['z']), 'HOME', home_info['dimension'])

    def start_teleport_to_position_countdown(self, player: Player, destination_name: str, position: tuple, teleport_type: str, dimension: str = 'overworld'):
        """开始传送到位置倒计时"""
        self.server.scheduler.run_task(
            self, 
            lambda: self.execute_teleport_to_position(player, destination_name, position, teleport_type, dimension), 
            delay=45
        )
        
        # 发送提示
        if teleport_type == 'PUBLIC_WARP':
            message = self.language_manager.GetText('TELEPORT_TO_WARP_COUNTDOWN').format(destination_name)
        elif teleport_type == 'HOME':
            message = self.language_manager.GetText('TELEPORT_TO_HOME_COUNTDOWN').format(destination_name)
        else:
            message = self.language_manager.GetText('TELEPORT_COUNTDOWN').format(destination_name)
        player.send_message(message)
    
    def start_teleport_to_player_countdown(self, player: Player, target_player: Player):
        """开始传送到玩家倒计时"""
        self.server.scheduler.run_task(
            self, 
            lambda: self.execute_teleport_to_player(player, target_player), 
            delay=45
        )

        # 发送提示
        message = self.language_manager.GetText('TELEPORT_COUNTDOWN').format(target_player.name)
        player.send_message(message)

    def execute_teleport_to_position(self, player: Player, destination_name: str, position: tuple, teleport_type: str, dimension: str = 'overworld'):
        """执行传送"""
        if teleport_type == 'PUBLIC_WARP':
            message = self.language_manager.GetText('TELEPORT_TO_WARP_SUCCESS').format(destination_name)
        elif teleport_type == 'HOME':
            message = self.language_manager.GetText('TELEPORT_TO_HOME_SUCCESS').format(destination_name)
        else:
            message = self.language_manager.GetText('TELEPORT_SUCCESS').format(destination_name)
        player.send_message(message)
        self.teleport_system.execute_teleport_to_position(player.name, position, dimension)
    
    def execute_teleport_to_player(self, player: Player, target_player: Player):
        """执行传送"""
        message = self.language_manager.GetText('TELEPORT_SUCCESS').format(target_player.name)
        player.send_message(message)
        target_dimension = target_player.location.dimension.name
        self.teleport_system.execute_teleport_to_player(player.name, target_player.name, target_dimension)

    # Death Location Teleport
    def teleport_to_death_location(self, player: Player):
        """传送到死亡地点"""
        if not self.teleport_system.has_death_location(player.name):
            player.send_message(self.language_manager.GetText('NO_DEATH_LOCATION_RECORDED'))
            return
        
        # 检查费用
        if self.teleport_system.teleport_cost_death_location > 0:
            player_money = self.get_player_money(player)
            if player_money < self.teleport_system.teleport_cost_death_location:
                player.send_message(self.language_manager.GetText('TELEPORT_COST_NOT_ENOUGH_MONEY').format(
                    self._format_money_display(self.teleport_system.teleport_cost_death_location),
                    self._format_money_display(player_money)
                ))
                return
            
            # 扣除费用
            if self.decrease_player_money(player, self.teleport_system.teleport_cost_death_location):
                player.send_message(self.language_manager.GetText('TELEPORT_COST_DEDUCTED').format(
                    self._format_money_display(self.teleport_system.teleport_cost_death_location),
                    self._format_money_display(self.get_player_money(player))
                ))
            else:
                self.report_arc_error(
                    "TP3",
                    f"teleport_to_death_location decrease failed cost={self.teleport_system.teleport_cost_death_location!r}",
                    player,
                )
                return
        
        death_location = self.teleport_system.get_death_location(player.name)
        
        # 开始传送倒计时
        self.server.scheduler.run_task(
            self, 
            lambda: self.execute_death_location_teleport(player), 
            delay=45
        )
        
        player.send_message(self.language_manager.GetText('TELEPORT_TO_DEATH_LOCATION_COUNTDOWN'))

    def execute_death_location_teleport(self, player: Player):
        """执行死亡地点传送"""
        if not self.teleport_system.has_death_location(player.name):
            player.send_message(self.language_manager.GetText('NO_DEATH_LOCATION_RECORDED'))
            return
        death_location = self.teleport_system.get_death_location(player.name)
        position = (death_location['x'], death_location['y'], death_location['z'])
        dimension = death_location['dimension']
        player.send_message(self.language_manager.GetText('TELEPORT_TO_DEATH_LOCATION_SUCCESS'))
        self.teleport_system.execute_teleport_to_position(player.name, position, dimension)
        self.teleport_system.clear_death_location(player.name)

    # Random Teleport System
    def start_random_teleport(self, player: Player):
        """开始随机传送"""
        # 检查功能是否启用
        if not self.teleport_system.enable_random_teleport:
            player.send_message(self.language_manager.GetText('RANDOM_TELEPORT_DISABLED'))
            return
        
        # 检查费用
        if self.teleport_system.teleport_cost_random > 0:
            player_money = self.get_player_money(player)
            if player_money < self.teleport_system.teleport_cost_random:
                player.send_message(self.language_manager.GetText('TELEPORT_COST_NOT_ENOUGH_MONEY').format(
                    self._format_money_display(self.teleport_system.teleport_cost_random),
                    self._format_money_display(player_money)
                ))
                return
            
            # 扣除费用
            if self.decrease_player_money(player, self.teleport_system.teleport_cost_random):
                player.send_message(self.language_manager.GetText('TELEPORT_COST_DEDUCTED').format(
                    self._format_money_display(self.teleport_system.teleport_cost_random),
                    self._format_money_display(self.get_player_money(player))
                ))
            else:
                self.report_arc_error(
                    "TP4",
                    f"start_random_teleport decrease failed cost={self.teleport_system.teleport_cost_random!r}",
                    player,
                )
                return
        
        # 发送倒计时消息
        player.send_message(self.language_manager.GetText('RANDOM_TELEPORT_COUNTDOWN'))
        
        # 延迟执行传送
        self.server.scheduler.run_task(
            self,
            lambda: self.execute_random_teleport(player),
            delay=45
        )
    
    def execute_random_teleport(self, player: Player):
        """执行随机传送"""
        position = self.teleport_system.get_random_teleport_position()
        dimension = 'overworld'
        player.send_message(self.language_manager.GetText('RANDOM_TELEPORT_SUCCESS').format(position[0], position[2]))
        self.teleport_system.execute_teleport_to_position(player.name, position, dimension)
        self.server.scheduler.run_task(
            self,
            lambda: self._apply_slow_falling_effect(player),
            delay=2
        )

    def _apply_slow_falling_effect(self, player: Player):
        """给玩家添加羽落效果（随机传送用）"""
        self.teleport_system.apply_slow_falling_effect(player.name)
        player.send_message(self.language_manager.GetText('RANDOM_TELEPORT_SLOW_FALLING_APPLIED'))

    # Player Teleport Request System
    def show_player_teleport_request_menu(self, player: Player):
        """显示玩家传送请求菜单"""
        request_menu = ActionForm(
            title=self.language_manager.GetText('PLAYER_TELEPORT_REQUEST_MENU_TITLE'),
            content=self.language_manager.GetText('PLAYER_TELEPORT_REQUEST_MENU_CONTENT'),
            on_close=self.show_teleport_menu
        )
        
        request_menu.add_button(
            self.language_manager.GetText('SEND_TPA_REQUEST_BUTTON'),
            on_click=self.show_send_tpa_request_panel
        )
        
        request_menu.add_button(
            self.language_manager.GetText('SEND_TPHERE_REQUEST_BUTTON'),
            on_click=self.show_send_tphere_request_panel
        )
        
        # 检查是否有待处理的请求
        pending_requests = self.get_pending_requests_for_player(player)
        if pending_requests:
            request_menu.add_button(
                self.language_manager.GetText('HANDLE_PENDING_REQUESTS_BUTTON').format(len(pending_requests)),
                on_click=self.show_pending_requests_menu
            )
        
        player.send_form(request_menu)

    def show_send_tpa_request_panel(self, player: Player):
        """显示发送TPA请求面板"""
        online_players = [p for p in self.server.online_players if p.name != player.name]
        if not online_players:
            no_players_panel = ActionForm(
                title=self.language_manager.GetText('SEND_TPA_REQUEST_TITLE'),
                content=self.language_manager.GetText('NO_OTHER_PLAYERS_ONLINE'),
                on_close=self.show_player_teleport_request_menu
            )
            player.send_form(no_players_panel)
            return

        tpa_menu = ActionForm(
            title=self.language_manager.GetText('SEND_TPA_REQUEST_TITLE'),
            content=self.language_manager.GetText('SEND_TPA_REQUEST_CONTENT'),
            on_close=self.show_player_teleport_request_menu
        )
        
        for target_player in online_players:
            tpa_menu.add_button(
                self.language_manager.GetText('TPA_TARGET_BUTTON').format(target_player.name),
                on_click=lambda p=player, t=target_player: self.send_tpa_request(p, t)
            )
        
        player.send_form(tpa_menu)

    def show_send_tphere_request_panel(self, player: Player):
        """显示发送TPHERE请求面板"""
        online_players = [p for p in self.server.online_players if p.name != player.name]
        if not online_players:
            no_players_panel = ActionForm(
                title=self.language_manager.GetText('SEND_TPHERE_REQUEST_TITLE'),
                content=self.language_manager.GetText('NO_OTHER_PLAYERS_ONLINE'),
                on_close=self.show_player_teleport_request_menu
            )
            player.send_form(no_players_panel)
            return

        tphere_menu = ActionForm(
            title=self.language_manager.GetText('SEND_TPHERE_REQUEST_TITLE'),
            content=self.language_manager.GetText('SEND_TPHERE_REQUEST_CONTENT'),
            on_close=self.show_player_teleport_request_menu
        )
        
        for target_player in online_players:
            tphere_menu.add_button(
                self.language_manager.GetText('TPHERE_TARGET_BUTTON').format(target_player.name),
                on_click=lambda p=player, t=target_player: self.send_tphere_request(p, t)
            )
        
        player.send_form(tphere_menu)

    def send_tpa_request(self, sender: Player, target: Player):
        """发送TPA请求（请求传送到目标玩家处）；费用在对方接受时从发起者扣除。"""
        if not self.teleport_system.add_request(target.name, 'tpa', sender.name):
            sender.send_message(self.language_manager.GetText('TELEPORT_REQUEST_ALREADY_EXISTS').format(target.name))
            return
        sender.send_message(self.language_manager.GetText('TPA_REQUEST_SENT').format(target.name))
        target.send_message(self.language_manager.GetText('TPA_REQUEST_RECEIVED').format(sender.name))
        self._send_incoming_teleport_request_form(target)

    def send_tphere_request(self, sender: Player, target: Player):
        """发送TPHERE请求（请求目标玩家传送过来）；费用在对方接受时从发起者扣除。"""
        if not self.teleport_system.add_request(target.name, 'tphere', sender.name):
            sender.send_message(self.language_manager.GetText('TELEPORT_REQUEST_ALREADY_EXISTS').format(target.name))
            return
        sender.send_message(self.language_manager.GetText('TPHERE_REQUEST_SENT').format(target.name))
        target.send_message(self.language_manager.GetText('TPHERE_REQUEST_RECEIVED').format(sender.name))
        self._send_incoming_teleport_request_form(target)

    def _incoming_teleport_request_form_content(self, request: Dict[str, Any]) -> str:
        sender_name = request.get('sender') or ''
        if request.get('type') == 'tphere':
            return self.language_manager.GetText('TPHERE_INCOMING_REQUEST_FORM_CONTENT').format(sender_name)
        return self.language_manager.GetText('TPA_INCOMING_REQUEST_FORM_CONTENT').format(sender_name)

    def _send_incoming_teleport_request_form(self, target_player: Player, on_close=None):
        """向被请求方弹出接受/拒绝表单（从菜单进入时可传 on_close 返回上一级）。"""
        pending_requests = self.get_pending_requests_for_player(target_player)
        if not pending_requests:
            return
        request = pending_requests[0]
        request_menu = ActionForm(
            title=self.language_manager.GetText('INCOMING_TP_REQUEST_TITLE'),
            content=self._incoming_teleport_request_form_content(request),
            on_close=on_close,
        )
        request_menu.add_button(
            self.language_manager.GetText('ACCEPT_REQUEST_BUTTON'),
            on_click=lambda p=target_player: self.accept_teleport_request(p),
        )
        request_menu.add_button(
            self.language_manager.GetText('DENY_REQUEST_BUTTON'),
            on_click=lambda p=target_player: self.deny_teleport_request(p),
        )
        target_player.send_form(request_menu)

    def get_pending_requests_for_player(self, player: Player) -> list:
        """获取玩家的待处理请求"""
        return self.teleport_system.get_pending_requests_for_player(player.name)

    def show_pending_requests_menu(self, player: Player):
        """显示待处理请求菜单（与收到请求时的弹窗文案一致）"""
        pending_requests = self.get_pending_requests_for_player(player)
        if not pending_requests:
            player.send_message(self.language_manager.GetText('NO_PENDING_REQUESTS'))
            self.show_player_teleport_request_menu(player)
            return
        self._send_incoming_teleport_request_form(player, on_close=self.show_player_teleport_request_menu)

    def accept_teleport_request(self, player: Player):
        """接受传送请求：此时从发起者扣除玩家互传费用（若配置大于 0）。"""
        request = self.teleport_system.get_request(player.name)
        if not request:
            player.send_message(self.language_manager.GetText('NO_PENDING_REQUESTS'))
            return
        if request.get('expire_time', 0) <= time.time():
            self.teleport_system.remove_request(player.name)
            player.send_message(self.language_manager.GetText('TP_REQUEST_EXPIRED'))
            return
        sender = self.server.get_player(request['sender'])
        if not sender:
            player.send_message(self.language_manager.GetText('REQUEST_SENDER_OFFLINE'))
            self.teleport_system.remove_request(player.name)
            return
        teleport_cost = self.teleport_system.teleport_cost_player
        if teleport_cost > 0:
            sender_money = self.get_player_money(sender)
            if sender_money < teleport_cost:
                player.send_message(
                    self.language_manager.GetText('TP_REQUEST_ACCEPT_SENDER_NO_MONEY_TARGET').format(sender.name)
                )
                sender.send_message(
                    self.language_manager.GetText('TELEPORT_COST_NOT_ENOUGH_MONEY').format(
                        self._format_money_display(teleport_cost),
                        self._format_money_display(sender_money),
                    )
                )
                self.teleport_system.remove_request(player.name)
                return
            if not self.decrease_player_money(sender, teleport_cost):
                self.report_arc_error(
                    "TP7",
                    f"accept_teleport_request decrease failed sender={sender.name!r} cost={teleport_cost!r}",
                    sender,
                )
                player.send_message(
                    self.language_manager.GetText('TP_REQUEST_ACCEPT_SENDER_NO_MONEY_TARGET').format(sender.name)
                )
                self.teleport_system.remove_request(player.name)
                return
            sender.send_message(
                self.language_manager.GetText('TELEPORT_COST_DEDUCTED').format(
                    self._format_money_display(teleport_cost),
                    self._format_money_display(self.get_player_money(sender)),
                )
            )
        if request['type'] == 'tpa':
            self.start_teleport_to_player_countdown(sender, player)
            player.send_message(self.language_manager.GetText('TPA_REQUEST_ACCEPTED_BY_TARGET').format(sender.name))
            sender.send_message(self.language_manager.GetText('TPA_REQUEST_ACCEPTED').format(player.name))
        else:
            self.start_teleport_to_player_countdown(player, sender)
            player.send_message(self.language_manager.GetText('TPHERE_REQUEST_ACCEPTED_BY_TARGET').format(sender.name))
            sender.send_message(self.language_manager.GetText('TPHERE_REQUEST_ACCEPTED').format(player.name))
        self.teleport_system.remove_request(player.name)

    def deny_teleport_request(self, player: Player):
        """拒绝传送请求"""
        request = self.teleport_system.get_request(player.name)
        if not request:
            player.send_message(self.language_manager.GetText('NO_PENDING_REQUESTS'))
            return
        sender = self.server.get_player(request['sender'])
        if sender:
            if request['type'] == 'tpa':
                sender.send_message(self.language_manager.GetText('TPA_REQUEST_DENIED').format(player.name))
                player.send_message(self.language_manager.GetText('TPA_REQUEST_DENIED_BY_YOU').format(sender.name))
            else:
                sender.send_message(self.language_manager.GetText('TPHERE_REQUEST_DENIED').format(player.name))
                player.send_message(self.language_manager.GetText('TPHERE_REQUEST_DENIED_BY_YOU').format(sender.name))
        self.teleport_system.remove_request(player.name)

    def show_op_teleport_manage_panel(self, player: Player):
        """OP 传送管理：公共传送点与传送相关配置。"""
        panel = ActionForm(
            title=self.language_manager.GetText('OP_TELEPORT_MANAGE_TITLE'),
            content=self.language_manager.GetText('OP_TELEPORT_MANAGE_CONTENT'),
            on_close=self.show_op_main_panel,
        )
        panel.add_button(
            self.language_manager.GetText('OP_TELEPORT_MANAGE_WARP_BUTTON'),
            on_click=self.show_op_warp_manage_menu,
        )
        panel.add_button(
            self.language_manager.GetText('OP_TELEPORT_MANAGE_SETTINGS_BUTTON'),
            on_click=self.show_op_teleport_settings_panel,
        )
        panel.add_button(
            self.language_manager.GetText('OP_TELEPORT_MANAGE_CROSS_SERVER_BUTTON'),
            on_click=self.show_op_cross_server_manage_menu,
        )
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_main_panel)
        player.send_form(panel)

    def show_op_teleport_settings_panel(self, player: Player):
        """OP 编辑 core_setting 中与传送相关的参数并立即重载 TeleportSystem。"""
        ts = self.teleport_system

        def _raw(key: str, fallback: str) -> str:
            v = self.setting_manager.GetSetting(key)
            if v is None or str(v).strip() == "":
                return fallback
            return str(v).strip()

        in_max_home = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_MAX_HOME_LABEL'),
            placeholder="5",
            default_value=_raw("MAX_PLAYER_HOME_NUM", str(ts.max_player_home_num)),
        )
        in_enable_random = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_ENABLE_RANDOM_LABEL'),
            placeholder="true / false",
            default_value="true" if ts.enable_random_teleport else "false",
        )
        in_cx = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_CENTER_X_LABEL'),
            placeholder="0",
            default_value=_raw("RANDOM_TELEPORT_CENTER_X", str(ts.random_teleport_center_x)),
        )
        in_cz = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_CENTER_Z_LABEL'),
            placeholder="0",
            default_value=_raw("RANDOM_TELEPORT_CENTER_Z", str(ts.random_teleport_center_z)),
        )
        in_radius = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_RADIUS_LABEL'),
            placeholder="4096",
            default_value=_raw("RANDOM_TELEPORT_RADIUS", str(ts.random_teleport_radius)),
        )
        in_cost_warp = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_COST_PUBLIC_WARP_LABEL'),
            placeholder="0",
            default_value=_raw("TELEPORT_COST_PUBLIC_WARP", str(ts.teleport_cost_public_warp)),
        )
        in_cost_home = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_COST_HOME_LABEL'),
            placeholder="0",
            default_value=_raw("TELEPORT_COST_HOME", str(ts.teleport_cost_home)),
        )
        in_cost_land = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_COST_LAND_LABEL'),
            placeholder="0",
            default_value=_raw("TELEPORT_COST_LAND", str(ts.teleport_cost_land)),
        )
        in_cost_death = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_COST_DEATH_LABEL'),
            placeholder="0",
            default_value=_raw("TELEPORT_COST_DEATH_LOCATION", str(ts.teleport_cost_death_location)),
        )
        in_cost_random = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_COST_RANDOM_LABEL'),
            placeholder="0",
            default_value=_raw("TELEPORT_COST_RANDOM", str(ts.teleport_cost_random)),
        )
        in_cost_player = TextInput(
            label=self.language_manager.GetText('OP_TELEPORT_SET_COST_PLAYER_LABEL'),
            placeholder="0",
            default_value=_raw("TELEPORT_COST_PLAYER", str(ts.teleport_cost_player)),
        )

        def try_save(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                p.send_message(self.language_manager.GetText('OP_TELEPORT_SETTINGS_SAVE_FAIL'))
                return self.show_op_teleport_manage_panel(p)
            if not data or len(data) < 11:
                p.send_message(self.language_manager.GetText('OP_TELEPORT_SETTINGS_SAVE_FAIL'))
                return self.show_op_teleport_manage_panel(p)

            def parse_int_safe(raw_value: str, default_value: int) -> int:
                try:
                    return int(str(raw_value).strip())
                except (ValueError, TypeError):
                    return default_value

            max_home = parse_int_safe(data[0], ts.max_player_home_num)
            enable_raw = str(data[1]).strip().lower()
            enable_random = enable_raw in ("true", "1", "yes", "on")
            cx = parse_int_safe(data[2], ts.random_teleport_center_x)
            cz = parse_int_safe(data[3], ts.random_teleport_center_z)
            radius = parse_int_safe(data[4], ts.random_teleport_radius)
            if radius < 0:
                radius = 0

            self.setting_manager.SetSetting("MAX_PLAYER_HOME_NUM", max_home)
            self.setting_manager.SetSetting("ENABLE_RANDOM_TELEPORT", "true" if enable_random else "false")
            self.setting_manager.SetSetting("RANDOM_TELEPORT_CENTER_X", cx)
            self.setting_manager.SetSetting("RANDOM_TELEPORT_CENTER_Z", cz)
            self.setting_manager.SetSetting("RANDOM_TELEPORT_RADIUS", radius)
            self.setting_manager.SetSetting("TELEPORT_COST_PUBLIC_WARP", parse_int_safe(data[5], ts.teleport_cost_public_warp))
            self.setting_manager.SetSetting("TELEPORT_COST_HOME", parse_int_safe(data[6], ts.teleport_cost_home))
            self.setting_manager.SetSetting("TELEPORT_COST_LAND", parse_int_safe(data[7], ts.teleport_cost_land))
            self.setting_manager.SetSetting("TELEPORT_COST_DEATH_LOCATION", parse_int_safe(data[8], ts.teleport_cost_death_location))
            self.setting_manager.SetSetting("TELEPORT_COST_RANDOM", parse_int_safe(data[9], ts.teleport_cost_random))
            self.setting_manager.SetSetting("TELEPORT_COST_PLAYER", parse_int_safe(data[10], ts.teleport_cost_player))

            self.teleport_system.reload_config()

            result = ActionForm(
                title=self.language_manager.GetText('OP_TELEPORT_SETTINGS_TITLE'),
                content=self.language_manager.GetText('OP_TELEPORT_SETTINGS_SAVED'),
                on_close=self.show_op_teleport_manage_panel,
            )
            result.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_teleport_manage_panel)
            p.send_form(result)

        form = ModalForm(
            title=self.language_manager.GetText('OP_TELEPORT_SETTINGS_TITLE'),
            controls=[
                in_max_home,
                in_enable_random,
                in_cx,
                in_cz,
                in_radius,
                in_cost_warp,
                in_cost_home,
                in_cost_land,
                in_cost_death,
                in_cost_random,
                in_cost_player,
            ],
            on_close=self.show_op_teleport_manage_panel,
            on_submit=try_save,
        )
        player.send_form(form)

    # OP Warp Management
    def show_op_cross_server_manage_menu(self, player: Player):
        """OP 管理跨服传送目标。"""
        targets = self._get_all_cross_server_targets()
        panel = ActionForm(
            title=self.language_manager.GetText('OP_CROSS_SERVER_MANAGE_TITLE'),
            content=self.language_manager.GetText('OP_CROSS_SERVER_MANAGE_CONTENT').format(len(targets)),
            on_close=self.show_op_teleport_manage_panel
        )
        panel.add_button(
            self.language_manager.GetText('OP_CROSS_SERVER_ADD_BUTTON'),
            on_click=self.show_op_create_cross_server_panel
        )
        for target in targets:
            target_id = int(target.get('id'))
            panel.add_button(
                self.language_manager.GetText('OP_CROSS_SERVER_ITEM_BUTTON').format(
                    target.get('server_name', ''),
                    target.get('server_host', ''),
                    int(target.get('server_port') or 19132)
                ),
                on_click=lambda p=player, t_id=target_id: self.show_op_cross_server_detail_menu(p, t_id)
            )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_op_teleport_manage_panel
        )
        player.send_form(panel)

    def _get_cross_server_target_by_id(self, target_id: int) -> Optional[Dict[str, Any]]:
        return self.database_manager.query_one(
            "SELECT id, server_name, server_host, server_port FROM cross_server_targets WHERE id = ?",
            (int(target_id),)
        )

    def _get_cross_server_target_by_name(self, server_name: str) -> Optional[Dict[str, Any]]:
        server_name_str = str(server_name or "").strip()
        if not server_name_str:
            return None
        return self.database_manager.query_one(
            "SELECT id, server_name, server_host, server_port FROM cross_server_targets "
            "WHERE LOWER(TRIM(server_name)) = LOWER(?) "
            "ORDER BY id ASC LIMIT 1",
            (server_name_str,)
        )

    def show_op_create_cross_server_panel(self, player: Player):
        server_name_input = TextInput(
            label=self.language_manager.GetText('OP_CROSS_SERVER_NAME_LABEL'),
            placeholder=self.language_manager.GetText('OP_CROSS_SERVER_NAME_PLACEHOLDER')
        )
        server_host_input = TextInput(
            label=self.language_manager.GetText('OP_CROSS_SERVER_HOST_LABEL'),
            placeholder=self.language_manager.GetText('OP_CROSS_SERVER_HOST_PLACEHOLDER')
        )
        server_port_input = TextInput(
            label=self.language_manager.GetText('OP_CROSS_SERVER_PORT_LABEL'),
            placeholder=self.language_manager.GetText('OP_CROSS_SERVER_PORT_PLACEHOLDER'),
            default_value='19132'
        )

        def try_create_target(sender: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_create_cross_server_panel(sender)
                return

            if len(data) < 3:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_create_cross_server_panel(sender)
                return

            server_name = str(data[0]).strip()
            server_host = str(data[1]).strip()
            server_port_text = str(data[2]).strip()
            try:
                server_port = int(server_port_text)
            except (ValueError, TypeError):
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_PORT_INVALID'))
                self.show_op_create_cross_server_panel(sender)
                return

            if not server_name or not server_host:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_create_cross_server_panel(sender)
                return
            if server_port <= 0 or server_port > 65535:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_PORT_INVALID'))
                self.show_op_create_cross_server_panel(sender)
                return

            if not self._create_cross_server_target(server_name, server_host, server_port):
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_create_cross_server_panel(sender)
                return

            sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_SUCCESS'))
            self.show_op_cross_server_manage_menu(sender)

        form = ModalForm(
            title=self.language_manager.GetText('OP_CROSS_SERVER_CREATE_TITLE'),
            controls=[server_name_input, server_host_input, server_port_input],
            on_close=self.show_op_cross_server_manage_menu,
            on_submit=try_create_target
        )
        player.send_form(form)

    def show_op_cross_server_detail_menu(self, player: Player, target_id: int):
        target = self._get_cross_server_target_by_id(target_id)
        if not target:
            player.send_message(self.language_manager.GetText('OP_CROSS_SERVER_NOT_FOUND'))
            self.show_op_cross_server_manage_menu(player)
            return

        detail_menu = ActionForm(
            title=self.language_manager.GetText('OP_CROSS_SERVER_DETAIL_TITLE').format(target.get('server_name', '')),
            content=self.language_manager.GetText('OP_CROSS_SERVER_DETAIL_CONTENT').format(
                target.get('server_name', ''),
                target.get('server_host', ''),
                int(target.get('server_port') or 19132)
            ),
            on_close=self.show_op_cross_server_manage_menu
        )
        detail_menu.add_button(
            self.language_manager.GetText('OP_CROSS_SERVER_EDIT_BUTTON'),
            on_click=lambda p=player, t_id=target_id: self.show_op_edit_cross_server_panel(p, t_id)
        )
        detail_menu.add_button(
            self.language_manager.GetText('OP_CROSS_SERVER_DELETE_BUTTON'),
            on_click=lambda p=player, t_id=target_id: self.show_op_delete_cross_server_confirm(p, t_id)
        )
        detail_menu.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_op_cross_server_manage_menu
        )
        player.send_form(detail_menu)

    def show_op_edit_cross_server_panel(self, player: Player, target_id: int):
        target = self._get_cross_server_target_by_id(target_id)
        if not target:
            player.send_message(self.language_manager.GetText('OP_CROSS_SERVER_NOT_FOUND'))
            self.show_op_cross_server_manage_menu(player)
            return

        server_name_input = TextInput(
            label=self.language_manager.GetText('OP_CROSS_SERVER_NAME_LABEL'),
            placeholder=self.language_manager.GetText('OP_CROSS_SERVER_NAME_PLACEHOLDER'),
            default_value=str(target.get('server_name') or '')
        )
        server_host_input = TextInput(
            label=self.language_manager.GetText('OP_CROSS_SERVER_HOST_LABEL'),
            placeholder=self.language_manager.GetText('OP_CROSS_SERVER_HOST_PLACEHOLDER'),
            default_value=str(target.get('server_host') or '')
        )
        server_port_input = TextInput(
            label=self.language_manager.GetText('OP_CROSS_SERVER_PORT_LABEL'),
            placeholder=self.language_manager.GetText('OP_CROSS_SERVER_PORT_PLACEHOLDER'),
            default_value=str(int(target.get('server_port') or 19132))
        )

        def try_edit_target(sender: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_edit_cross_server_panel(sender, target_id)
                return
            if len(data) < 3:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_edit_cross_server_panel(sender, target_id)
                return

            server_name = str(data[0]).strip()
            server_host = str(data[1]).strip()
            server_port_text = str(data[2]).strip()
            try:
                server_port = int(server_port_text)
            except (ValueError, TypeError):
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_PORT_INVALID'))
                self.show_op_edit_cross_server_panel(sender, target_id)
                return

            if not server_name or not server_host:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_edit_cross_server_panel(sender, target_id)
                return
            if server_port <= 0 or server_port > 65535:
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_PORT_INVALID'))
                self.show_op_edit_cross_server_panel(sender, target_id)
                return

            if not self._update_cross_server_target(target_id, server_name, server_host, server_port):
                sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_FAIL'))
                self.show_op_edit_cross_server_panel(sender, target_id)
                return
            sender.send_message(self.language_manager.GetText('OP_CROSS_SERVER_SAVE_SUCCESS'))
            self.show_op_cross_server_detail_menu(sender, target_id)

        form = ModalForm(
            title=self.language_manager.GetText('OP_CROSS_SERVER_EDIT_TITLE'),
            controls=[server_name_input, server_host_input, server_port_input],
            on_close=lambda p=player: self.show_op_cross_server_detail_menu(p, target_id),
            on_submit=try_edit_target
        )
        player.send_form(form)

    def show_op_delete_cross_server_confirm(self, player: Player, target_id: int):
        target = self._get_cross_server_target_by_id(target_id)
        if not target:
            player.send_message(self.language_manager.GetText('OP_CROSS_SERVER_NOT_FOUND'))
            self.show_op_cross_server_manage_menu(player)
            return

        panel = ActionForm(
            title=self.language_manager.GetText('OP_CROSS_SERVER_DELETE_CONFIRM_TITLE'),
            content=self.language_manager.GetText('OP_CROSS_SERVER_DELETE_CONFIRM_CONTENT').format(
                target.get('server_name', ''),
                target.get('server_host', ''),
                int(target.get('server_port') or 19132)
            ),
            on_close=lambda p=player: self.show_op_cross_server_detail_menu(p, target_id)
        )
        panel.add_button(
            self.language_manager.GetText('OP_CROSS_SERVER_DELETE_CONFIRM_BUTTON'),
            on_click=lambda p=player, t_id=target_id: self._do_delete_cross_server_target(p, t_id)
        )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player: self.show_op_cross_server_detail_menu(p, target_id)
        )
        player.send_form(panel)

    def _do_delete_cross_server_target(self, player: Player, target_id: int):
        if self._delete_cross_server_target(target_id):
            player.send_message(self.language_manager.GetText('OP_CROSS_SERVER_DELETE_SUCCESS'))
        else:
            player.send_message(self.language_manager.GetText('OP_CROSS_SERVER_DELETE_FAIL'))
        self.show_op_cross_server_manage_menu(player)

    def show_op_warp_manage_menu(self, player: Player):
        """显示OP传送点管理菜单"""
        warp_manage_menu = ActionForm(
            title=self.language_manager.GetText('OP_WARP_MANAGE_MENU_TITLE'),
            content=self.language_manager.GetText('OP_WARP_MANAGE_MENU_CONTENT'),
            on_close=self.show_op_teleport_manage_panel
        )
        
        warp_manage_menu.add_button(
            self.language_manager.GetText('OP_CREATE_WARP_BUTTON'),
            on_click=self.show_create_warp_panel
        )
        
        public_warps = self.get_all_public_warps()
        if public_warps:
            warp_manage_menu.add_button(
                self.language_manager.GetText('OP_DELETE_WARP_BUTTON').format(len(public_warps)),
                on_click=self.show_delete_warp_menu
            )
        
        player.send_form(warp_manage_menu)

    def show_create_warp_panel(self, player: Player):
        """显示创建公共传送点面板"""
        warp_name_input = TextInput(
            label=self.language_manager.GetText('CREATE_WARP_NAME_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('CREATE_WARP_NAME_INPUT_PLACEHOLDER')
        )

        def try_create_warp(player: Player, json_str: str):
            data = json.loads(json_str)
            if not data or not data[0].strip():
                player.send_message(self.language_manager.GetText('CREATE_WARP_EMPTY_NAME_ERROR'))
                self.show_create_warp_panel(player)
                return
            
            warp_name = data[0].strip()
            if self.public_warp_exists(warp_name):
                player.send_message(self.language_manager.GetText('CREATE_WARP_NAME_EXISTS_ERROR').format(warp_name))
                self.show_create_warp_panel(player)
                return
            
            # 创建公共传送点
            success = self.create_public_warp(
                warp_name,
                player.location.dimension.name,
                player.location.x,
                player.location.y,
                player.location.z,
                str(player.xuid)
            )
            
            if success:
                player.send_message(self.language_manager.GetText('CREATE_WARP_SUCCESS').format(warp_name))
            else:
                player.send_message(self.language_manager.GetText('CREATE_WARP_FAILED'))
            
            self.show_op_warp_manage_menu(player)

        create_panel = ModalForm(
            title=self.language_manager.GetText('CREATE_WARP_PANEL_TITLE'),
            controls=[warp_name_input],
            on_close=self.show_op_warp_manage_menu,
            on_submit=try_create_warp
        )
        
        player.send_form(create_panel)

    def show_delete_warp_menu(self, player: Player):
        """显示删除公共传送点菜单"""
        public_warps = self.get_all_public_warps()
        if not public_warps:
            player.send_message(self.language_manager.GetText('NO_WARPS_TO_DELETE'))
            self.show_op_warp_manage_menu(player)
            return

        delete_menu = ActionForm(
            title=self.language_manager.GetText('DELETE_WARP_MENU_TITLE'),
            content=self.language_manager.GetText('DELETE_WARP_MENU_CONTENT'),
            on_close=self.show_op_warp_manage_menu
        )
        
        for warp_name, warp_info in public_warps.items():
            creator_name = self.get_player_name_by_xuid(warp_info['created_by']) or 'Unknown'
            delete_menu.add_button(
                self.language_manager.GetText('DELETE_WARP_BUTTON_TEXT').format(warp_name, creator_name),
                on_click=lambda p=player, w_name=warp_name: self.confirm_delete_warp(p, w_name)
            )
        
        player.send_form(delete_menu)

    def confirm_delete_warp(self, player: Player, warp_name: str):
        """确认删除公共传送点"""
        confirm_panel = ActionForm(
            title=self.language_manager.GetText('CONFIRM_DELETE_WARP_TITLE'),
            content=self.language_manager.GetText('CONFIRM_DELETE_WARP_CONTENT').format(warp_name),
            on_close=self.show_delete_warp_menu
        )
        
        confirm_panel.add_button(
            self.language_manager.GetText('CONFIRM_DELETE_WARP_BUTTON'),
            on_click=lambda p=player, w_name=warp_name: self.delete_warp_confirmed(p, w_name)
        )
        
        player.send_form(confirm_panel)

    def delete_warp_confirmed(self, player: Player, warp_name: str):
        """确认删除公共传送点"""
        success = self.delete_public_warp(warp_name)
        if success:
            player.send_message(self.language_manager.GetText('DELETE_WARP_SUCCESS').format(warp_name))
        else:
            player.send_message(self.language_manager.GetText('DELETE_WARP_FAILED'))
        self.show_delete_warp_menu(player)

    # Land System
    # ─── Land data methods (delegated to LandSystem) ─────────────────────────

    def rebuild_chunk_land_mapping(self) -> tuple:
        """委托 LandSystem 重建区块映射，并将结果格式化为语言文本"""
        success, num_dims, num_lands, err = self.land_system.rebuild_chunk_land_mapping()
        if not success:
            return False, self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_FAILED').format(err)
        if num_lands == 0:
            return True, self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_NO_LANDS')
        return True, self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_SUCCESS').format(num_dims, num_lands)

    def create_land(self, owner_xuid: str, land_name: str, dimension: str,
                    min_x: int, max_x: int, min_y: int, max_y: int, min_z: int, max_z: int,
                    tp_x: float, tp_y: float, tp_z: float, owner_paid_money: float = 0.0) -> Optional[int]:
        return self.land_system.create_land(
            owner_xuid, land_name, dimension,
            min_x, max_x, min_y, max_y, min_z, max_z,
            tp_x, tp_y, tp_z, owner_paid_money
        )

    def get_land_at_pos(self, dimension: str, x: int, z: int, y: int = None) -> Optional[int]:
        return self.land_system.get_land_at_pos(dimension, x, z, y)

    def delete_land(self, land_id: int) -> bool:
        return self.land_system.delete_land(land_id)

    def check_land_availability(self, dimension: str, min_x: int, max_x: int, min_y: int, max_y: int, min_z: int, max_z: int) -> tuple:
        return self.land_system.check_land_availability(dimension, min_x, max_x, min_y, max_y, min_z, max_z)

    def create_sub_land(self, parent_land_id: int, owner_xuid: str, sub_land_name: str,
                        min_x: int, max_x: int, min_y: int, max_y: int,
                        min_z: int, max_z: int) -> Optional[int]:
        return self.land_system.create_sub_land(
            parent_land_id, owner_xuid, sub_land_name,
            min_x, max_x, min_y, max_y, min_z, max_z
        )

    def delete_sub_land(self, sub_land_id: int) -> bool:
        return self.land_system.delete_sub_land(sub_land_id)

    def get_sub_land_info(self, sub_land_id: int) -> dict:
        return self.land_system.get_sub_land_info(sub_land_id)

    def get_sub_lands_by_parent(self, parent_land_id: int) -> dict:
        return self.land_system.get_sub_lands_by_parent(parent_land_id)

    def get_sub_lands_by_owner_in_parent(self, parent_land_id: int, owner_xuid: str) -> dict:
        return self.land_system.get_sub_lands_by_owner_in_parent(parent_land_id, owner_xuid)

    def get_sub_land_at_pos(self, parent_land_id: int, x: int, y: int, z: int) -> Optional[int]:
        return self.land_system.get_sub_land_at_pos(parent_land_id, x, y, z)

    def check_sub_land_availability(self, parent_land_id: int,
                                    min_x: int, max_x: int, min_y: int, max_y: int,
                                    min_z: int, max_z: int,
                                    exclude_sub_land_id: int = None) -> tuple:
        return self.land_system.check_sub_land_availability(
            parent_land_id, min_x, max_x, min_y, max_y, min_z, max_z, exclude_sub_land_id
        )

    def add_sub_land_shared_user(self, sub_land_id: int, xuid: str) -> bool:
        return self.land_system.add_sub_land_shared_user(sub_land_id, xuid)

    def remove_sub_land_shared_user(self, sub_land_id: int, xuid: str) -> bool:
        return self.land_system.remove_sub_land_shared_user(sub_land_id, xuid)

    def rename_sub_land(self, sub_land_id: int, new_name: str) -> bool:
        return self.land_system.rename_sub_land(sub_land_id, new_name)

    def get_player_land_count(self, xuid: str) -> int:
        return self.land_system.get_player_land_count(xuid)

    def get_player_lands(self, xuid: str) -> dict:
        return self.land_system.get_player_lands(xuid)

    def get_all_lands(self) -> Dict[int, dict]:
        return self.land_system.get_all_lands()

    def get_land_info(self, land_id: int) -> dict:
        return self.land_system.get_land_info(land_id)

    PUBLIC_LAND_OWNER_XUID = LandSystem.PUBLIC_LAND_OWNER_XUID

    def is_public_land(self, land_id: int) -> bool:
        return self.land_system.is_public_land(land_id)

    def _get_public_land_protected_entities(self) -> Set[str]:
        return self.land_system.get_public_land_protected_entities()

    def get_land_display_owner_name(self, land_id: int) -> str:
        owner_xuid = self.land_system.get_land_owner(land_id)
        if owner_xuid == LandSystem.PUBLIC_LAND_OWNER_XUID:
            return self.language_manager.GetText('PUBLIC_LAND_NAME')
        return self.get_player_name_by_xuid(owner_xuid) or owner_xuid or ''

    def get_land_owner(self, land_id: int) -> str:
        return self.land_system.get_land_owner(land_id)

    def set_land_as_public(self, land_id: int) -> bool:
        return self.land_system.set_land_as_public(land_id)

    def rename_land(self, land_id: int, new_name: str) -> tuple:
        success, err = self.land_system.rename_land(land_id, new_name)
        if success:
            return True, "领地名称修改成功"
        return False, err or "修改领地名称时发生错误"

    def set_land_teleport_point(self, land_id: int, x: int, y: int, z: int) -> tuple:
        success, err = self.land_system.set_land_teleport_point(land_id, x, y, z)
        if success:
            return True, "领地传送点设置成功"
        if err == "LAND_NOT_FOUND":
            return False, "领地不存在"
        if err == "TP_POINT_OUT_OF_LAND":
            return False, "传送点必须在领地范围内"
        return False, f"设置传送点时发生错误: {err}"

    def get_land_teleport_point(self, land_id: int) -> Optional[tuple]:
        return self.land_system.get_land_teleport_point(land_id)

    def get_land_dimension(self, land_id: int) -> str:
        return self.land_system.get_land_dimension(land_id)

    def get_land_name(self, land_id: int) -> str:
        return self.land_system.get_land_name(land_id)

    # Land System UI
    def show_land_main_menu(self, player: Player):
        land_main_menu = ActionForm(
            title=self.language_manager.GetText('LAND_MAIN_MENU_TITLE'),
            content=self.language_manager.GetText('LAND_MAIN_MENU_CONTENT').format(
                self.get_player_land_count(str(player.xuid)))
        )
        land_main_menu.add_button(self.language_manager.GetText('LAND_MAIN_MENU_MANAGE_LAND_TEXT'),
                                  on_click=self.show_own_land_menu)
        land_main_menu.add_button(self.language_manager.GetText('LAND_MAIN_MENU_CREATE_NEW_LAND_TEXT'),
                                  on_click=self.start_interactive_land_creation)
        land_main_menu.add_button(self.language_manager.GetText('LAND_MAIN_MENU_CHECK_CURRENT_LAND_TEXT'),
                                  on_click=self.show_current_land_info)
        # 返回
        land_main_menu.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                                  on_click=self.show_main_menu)
        player.send_form(land_main_menu)

    def show_own_land_menu(self, player: Player):
        player_land_num = self.get_player_land_count(str(player.xuid))
        if player_land_num == 0:
            own_land_panel = ActionForm(
                title=self.language_manager.GetText('OWN_LAND_PANEL_TITLE'),
                content=self.language_manager.GetText('OWN_LAND_PANEL_NO_LAND_EXIST_CONTENT').format(
                    self.get_player_land_count(str(player.xuid))),
                on_close=self.show_land_main_menu
            )
            player.send_form(own_land_panel)
            return
        else:
            own_land_panel = ActionForm(
                title=self.language_manager.GetText('OWN_LAND_PANEL_TITLE'),
                on_close=self.show_land_main_menu
            )
            player_lands = self.get_player_lands(str(player.xuid))
            for land_id in player_lands.keys():
                own_land_panel.add_button(
                    self.language_manager.GetText('OWN_LAND_PANEL_LAND_BUTTON_TEXT').format(
                        land_id,
                        player_lands[land_id]['land_name']
                    ),
                    on_click=lambda p=player, l_id=land_id, l_info=player_lands[land_id]: self.show_own_land_detail_panel(p, l_id, l_info)
                )
            player.send_form(own_land_panel)

    def show_own_land_detail_panel(self, player: Player, land_id: int, land_info: dict):
        # 处理具体领地的详情显示
        if len(land_info['shared_users']):
            shared_user_names = [self.get_player_name_by_xuid(uu_id) for uu_id in land_info['shared_users']]
            shared_user_name_str = '\n'.join(shared_user_names)
        else:
            shared_user_name_str = self.language_manager.GetText('LAND_DETAIL_NO_SHARED_USER_TEXT')
        land_detail_panel = ActionForm(
            title=self.language_manager.GetText('LAND_DETAIL_PANEL_TITLE'),
            content=self.language_manager.GetText('LAND_DETAIL_PANEL_CONTENT').format(
                land_id,
                land_info['land_name'],
                land_info['dimension'],
                (int(land_info['min_x']), int(land_info.get('min_y', 0)), int(land_info['min_z'])),
                (int(land_info['max_x']), int(land_info.get('max_y', 255)), int(land_info['max_z'])),
                (int(land_info['tp_x']), int(land_info['tp_y']), int(land_info['tp_z'])),
                shared_user_name_str
            ),
            on_close=self.show_own_land_menu
        )
        
        # 领地传送按钮（显示价格）
        land_teleport_text = self.language_manager.GetText('LAND_DETAIL_PANEL_TELEPORT_BUTTON_TEXT')
        if self.teleport_system.teleport_cost_land > 0:
            land_teleport_text = self.language_manager.GetText('TELEPORT_BUTTON_WITH_COST').format(land_teleport_text, self.teleport_system.teleport_cost_land)
        land_detail_panel.add_button(land_teleport_text, on_click=lambda p=player, l_id=land_id: self.teleport_to_land(p, l_id))
        land_detail_panel.add_button(self.language_manager.GetText('LAND_DETAIL_PANEL_RENAME_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_rename_own_land_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_DETAIL_PANEL_RESET_LAND_TP_POS_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.set_player_pos_as_land_tp_pos(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_DETAIL_PANEL_MANAGE_AUTH_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_land_auth_manage_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_EXPLOSION_SETTING_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_land_explosion_setting_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_ACTOR_INTERACTION_SETTING_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_land_actor_interaction_setting_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_ACTOR_DAMAGE_SETTING_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_land_actor_damage_setting_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_FRAME_SETTING_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_land_frame_setting_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_PUBLIC_INTERACT_SETTING_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_land_public_interact_setting_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_DETAIL_PANEL_MANAGE_SUB_LAND_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_sub_land_manage_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_DETAIL_PANEL_TRANSFER_LAND_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.show_transfer_land_panel(p, l_id)
                                     )
        land_detail_panel.add_button(self.language_manager.GetText('LAND_DETAIL_PANEL_DELETE_LAND_BUTTON_TEXT'),
                                     on_click=lambda p=player, l_id=land_id: self.confirm_delete_land(p, l_id)
                                     )
        player.send_form(land_detail_panel)

    def show_rename_own_land_panel(self, player: Player, land_id: int):
        new_name_input = TextInput(
            label=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_INPUT_LABEL').format(land_id),
            placeholder=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_INPUT_PLACEHOLDER').format(player.name),
            default_value=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_INPUT_PLACEHOLDER').format(player.name)
        )

        def try_change_name(player: Player, json_str: str):
            data = json.loads(json_str)
            self.rename_land(land_id, data[0])
            # 返回上级菜单
            self.show_own_land_detail_panel(player, land_id, self.get_land_info(land_id))

        rename_panel = ModalForm(
            title=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_TITLE'),
            controls=[new_name_input],
            on_close=self.show_own_land_menu,
            on_submit=try_change_name
        )
        player.send_form(rename_panel)

    def set_player_pos_as_land_tp_pos(self, player: Player, land_id: int):
        on_land_id = self.get_land_at_pos(player.location.dimension.name, math.floor(player.location.x), math.floor(player.location.z))
        if on_land_id is None or on_land_id != land_id:
            result = self.language_manager.GetText('SET_LAND_TP_POS_FAIL_OUT_LAND')
        else:
            new_pos = (math.floor(player.location.x), math.floor(player.location.y), math.floor(player.location.z))
            self.set_land_teleport_point(land_id, new_pos[0], new_pos[1], new_pos[2])
            result = self.language_manager.GetText('SET_LAND_TP_POS_SUCCESS').format(land_id, new_pos)
        result_panel = ActionForm(
            title=self.language_manager.GetText('SET_LAND_TP_POS_RESULT_TITLE'),
            content=result,
            on_close=lambda p=player, l_id=land_id, l_info=self.get_land_info(land_id): self.show_own_land_detail_panel(p, l_id, l_info)
        )
        player.send_form(result_panel)

    def teleport_to_land(self, player: Player, land_id: int):
        # 检查费用
        if self.teleport_system.teleport_cost_land > 0:
            player_money = self.get_player_money(player)
            if player_money < self.teleport_system.teleport_cost_land:
                player.send_message(self.language_manager.GetText('TELEPORT_COST_NOT_ENOUGH_MONEY').format(
                    self._format_money_display(self.teleport_system.teleport_cost_land),
                    self._format_money_display(player_money)
                ))
                return
            
            # 扣除费用
            if self.decrease_player_money(player, self.teleport_system.teleport_cost_land):
                player.send_message(self.language_manager.GetText('TELEPORT_COST_DEDUCTED').format(
                    self._format_money_display(self.teleport_system.teleport_cost_land),
                    self._format_money_display(self.get_player_money(player))
                ))
            else:
                self.report_arc_error(
                    "TP7",
                    f"teleport_to_land decrease failed land_id={land_id!r} cost={self.teleport_system.teleport_cost_land!r}",
                    player,
                )
                return
        
        tp_target_pos = self.get_land_teleport_point(land_id)
        self.server.scheduler.run_task(self, lambda p=player, l_id=land_id, pos=tp_target_pos: self.delay_teleport_to_land(p, l_id, pos), delay=45)
        player.send_message(self.language_manager.GetText('READY_TELEPORT_TO_LAND').format(land_id))

    def delay_teleport_to_land(self, player: Player, land_id: int, position: tuple):
        player.send_message(self.language_manager.GetText('TELEPORT_TO_LAND_START_HINT').format(land_id))
        land_dimension = self.get_land_dimension(land_id)
        self.server.dispatch_command(self.server.command_sender, generate_tp_command_to_position(player.name, position, land_dimension))

    def confirm_delete_land(self, player: Player, land_id: int):
        deleta_land_info = self.get_land_info(land_id)
        owner_paid = deleta_land_info.get('owner_paid_money')
        if owner_paid is not None:
            return_money = round(float(owner_paid) * self.land_sell_refund_coefficient, 2)
        else:
            land_area = (deleta_land_info['max_x'] - deleta_land_info['min_x'] + 1) * (deleta_land_info['max_z'] - deleta_land_info['min_z'] + 1)
            return_money = round(land_area * self.land_price * self.land_sell_refund_coefficient, 2)
        confirm_panel = ActionForm(
            title=self.language_manager.GetText('CONFIRM_DELETE_LAND_TITLE').format(land_id),
            content=self.language_manager.GetText('CONFIRM_DELETE_LAND_CONTENT').format(
            land_id, deleta_land_info['land_name'], self.land_sell_refund_coefficient,
            self._format_money_display(return_money)),
            on_close=self.show_own_land_detail_panel(player, land_id, deleta_land_info)
        )
        confirm_panel.add_button(self.language_manager.GetText('CONFIRM_DELETE_LAND_BUTTON').format(land_id),
                                 on_click=lambda p=player, l_id=land_id, r_m=return_money: self.try_delete_land(p, l_id, r_m)
                                 )
        player.send_form(confirm_panel)

    def try_delete_land(self, player: Player, land_id: int, return_money: int):
        r = self.delete_land(land_id)
        if r:
            if return_money and return_money > 0:
                if not self.increase_player_money(player, return_money):
                    self.report_arc_error(
                        "LAND_PAY2",
                        f"try_delete_land land_id={land_id} deleted but refund increase failed amount={return_money!r}",
                        player,
                    )
            player.send_message(self.language_manager.GetText('DELETE_LAND_SUCCESS').format(
                land_id,
                self._format_money_display(return_money),
                self._format_money_display(self.get_player_money(player))))
        else:
            player.send_message(self.language_manager.GetText('DELETE_LAND_FAILED').format(land_id))
        self.show_own_land_menu(player)

    def show_transfer_land_panel(self, player: Player, land_id: int):
        """显示移交领地面板，让玩家选择要移交给谁"""
        online_players = [p for p in self.server.online_players if p.name != player.name]
        if not online_players:
            no_players_panel = ActionForm(
                title=self.language_manager.GetText('TRANSFER_LAND_PANEL_TITLE'),
                content=self.language_manager.GetText('NO_OTHER_PLAYERS_ONLINE'),
                on_close=lambda p=player, l_id=land_id, l_info=self.get_land_info(land_id): self.show_own_land_detail_panel(p, l_id, l_info)
            )
            player.send_form(no_players_panel)
            return

        transfer_menu = ActionForm(
            title=self.language_manager.GetText('TRANSFER_LAND_PANEL_TITLE'),
            content=self.language_manager.GetText('TRANSFER_LAND_PANEL_CONTENT'),
            on_close=lambda p=player, l_id=land_id, l_info=self.get_land_info(land_id): self.show_own_land_detail_panel(p, l_id, l_info)
        )
        
        for target_player in online_players:
            transfer_menu.add_button(
                self.language_manager.GetText('TRANSFER_LAND_TARGET_BUTTON').format(target_player.name),
                on_click=lambda p=player, l_id=land_id, t=target_player: self.confirm_transfer_land(p, l_id, t)
            )
        
        player.send_form(transfer_menu)

    def confirm_transfer_land(self, player: Player, land_id: int, target_player: Player):
        """显示确认移交领地的面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND10",
                f"confirm_transfer_land get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        confirm_panel = ActionForm(
            title=self.language_manager.GetText('CONFIRM_TRANSFER_LAND_TITLE').format(land_id),
            content=self.language_manager.GetText('CONFIRM_TRANSFER_LAND_CONTENT').format(
                land_id, 
                land_info['land_name'], 
                target_player.name
            ),
            on_close=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        confirm_panel.add_button(
            self.language_manager.GetText('CONFIRM_TRANSFER_LAND_BUTTON'),
            on_click=lambda p=player, l_id=land_id, t=target_player: self.try_transfer_land(p, l_id, t)
        )
        player.send_form(confirm_panel)

    def transfer_land(self, land_id: int, new_owner_xuid: str) -> bool:
        return self.land_system.transfer_land(land_id, new_owner_xuid)

    def try_transfer_land(self, player: Player, land_id: int, target_player: Player):
        """尝试移交领地"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND11",
                f"try_transfer_land get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        # 检查目标玩家是否还在线
        target_online = any(p.name == target_player.name for p in self.server.online_players)
        if not target_online:
            player.send_message(self.language_manager.GetText('REQUEST_SENDER_OFFLINE'))
            self.show_own_land_menu(player)
            return

        # 执行移交
        success = self.transfer_land(land_id, str(target_player.xuid))
        if success:
            # 通知当前玩家
            player.send_message(self.language_manager.GetText('TRANSFER_LAND_SUCCESS').format(land_id, target_player.name))
            
            # 通知目标玩家
            target_player.send_message(self.language_manager.GetText('TRANSFER_LAND_NOTIFICATION').format(
                player.name, 
                land_id, 
                land_info['land_name']
            ))
        else:
            player.send_message(self.language_manager.GetText('TRANSFER_LAND_FAILED').format(land_id))
        
        self.show_own_land_menu(player)

    def show_land_auth_manage_panel(self, player: Player, land_id: int):
        """显示领地授权管理面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND12",
                f"show_land_auth_manage_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        auth_panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_MANAGE_TITLE'),
            on_close=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        
        auth_panel.add_button(
            self.language_manager.GetText('LAND_AUTH_ADD_BUTTON'),
            on_click=lambda p=player, l_id=land_id: self.show_add_land_auth_panel(p, l_id)
        )
        
        if land_info['shared_users']:
            auth_panel.add_button(
                self.language_manager.GetText('LAND_AUTH_REMOVE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.show_remove_land_auth_panel(p, l_id)
            )
        
        player.send_form(auth_panel)

    def show_add_land_auth_panel(self, player: Player, land_id: int):
        """显示添加领地授权面板"""
        online_players = [p for p in self.server.online_players if p.name != player.name]
        if not online_players:
            no_players_panel = ActionForm(
                title=self.language_manager.GetText('LAND_AUTH_ADD_PANEL_TITLE'),
                content=self.language_manager.GetText('NO_OTHER_PLAYERS_ONLINE'),
                on_close=lambda p=player, l_id=land_id: self.show_land_auth_manage_panel(p, l_id)
            )
            player.send_form(no_players_panel)
            return

        add_auth_panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_ADD_PANEL_TITLE'),
            content=self.language_manager.GetText('LAND_AUTH_SELECT_PLAYER_CONTENT'),
            on_close=lambda p=player, l_id=land_id: self.show_land_auth_manage_panel(p, l_id)
        )
        
        for target_player in online_players:
            add_auth_panel.add_button(
                self.language_manager.GetText('LAND_AUTH_ADD_TARGET_BUTTON').format(target_player.name),
                on_click=lambda p=player, l_id=land_id, t=target_player: self.add_land_auth(p, l_id, t)
            )
        
        player.send_form(add_auth_panel)

    def show_remove_land_auth_panel(self, player: Player, land_id: int):
        """显示移除领地授权面板"""
        land_info = self.get_land_info(land_id)
        if not land_info or not land_info['shared_users']:
            no_auth_panel = ActionForm(
                title=self.language_manager.GetText('LAND_AUTH_REMOVE_PANEL_TITLE'),
                content=self.language_manager.GetText('LAND_AUTH_NO_SHARED_USERS'),
                on_close=lambda p=player, l_id=land_id: self.show_land_auth_manage_panel(p, l_id)
            )
            player.send_form(no_auth_panel)
            return

        remove_auth_panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_REMOVE_PANEL_TITLE'),
            content=self.language_manager.GetText('LAND_AUTH_SELECT_REMOVE_CONTENT'),
            on_close=lambda p=player, l_id=land_id: self.show_land_auth_manage_panel(p, l_id)
        )
        
        for shared_uuid in land_info['shared_users']:
            raw_name = self.get_player_name_by_xuid(shared_uuid, return_with_title=False)
            if not raw_name:
                continue
            display_name = self.get_player_name_by_xuid(shared_uuid, return_with_title=True) or raw_name
            remove_auth_panel.add_button(
                self.language_manager.GetText('LAND_AUTH_REMOVE_TARGET_BUTTON').format(display_name),
                on_click=lambda p=player, l_id=land_id, uuid=shared_uuid, name=raw_name: self.remove_land_auth(p, l_id, uuid, name)
            )
        
        player.send_form(remove_auth_panel)

    def add_land_auth(self, player: Player, land_id: int, target_player: Player):
        """添加领地授权"""
        try:
            land_info = self.get_land_info(land_id)
            if not land_info:
                self.report_arc_error(
                    "LAND13",
                    f"add_land_auth get_land_info empty land_id={land_id!r}",
                    player,
                )
                return
            target_xuid = str(target_player.xuid)
            if target_xuid in land_info['shared_users']:
                player.send_message(self.language_manager.GetText('LAND_AUTH_ALREADY_EXISTS').format(target_player.name))
                self.show_land_auth_manage_panel(player, land_id)
                return
            success = self.land_system.add_land_shared_user(land_id, target_xuid)
            if success:
                player.send_message(self.language_manager.GetText('LAND_AUTH_SUCCESS_ADD').format(land_id, target_player.name))
                target_player.send_message(self.language_manager.GetText('LAND_AUTH_NOTIFICATION').format(
                    player.name, land_id, land_info['land_name']
                ))
            else:
                player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_ADD'))
        except Exception as e:
            self.logger.error(f"Add land auth error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_ADD'))
        self.show_land_auth_manage_panel(player, land_id)

    def remove_land_auth(self, player: Player, land_id: int, target_uuid: str, target_name: str):
        """移除领地授权"""
        try:
            land_info = self.get_land_info(land_id)
            if not land_info:
                self.report_arc_error(
                    "LAND14",
                    f"remove_land_auth get_land_info empty land_id={land_id!r}",
                    player,
                )
                return
            if target_uuid not in land_info['shared_users']:
                player.send_message(self.language_manager.GetText('LAND_AUTH_NOT_EXISTS').format(target_name))
                self.show_land_auth_manage_panel(player, land_id)
                return
            success = self.land_system.remove_land_shared_user(land_id, target_uuid)
            if success:
                player.send_message(self.language_manager.GetText('LAND_AUTH_SUCCESS_REMOVE').format(target_name, land_id))
                target_player = self.server.get_player(target_name)
                if target_player:
                    target_player.send_message(self.language_manager.GetText('LAND_AUTH_REMOVE_NOTIFICATION').format(
                        player.name, land_id, land_info['land_name']
                    ))
            else:
                player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_REMOVE'))
        except Exception as e:
            self.logger.error(f"Remove land auth error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_REMOVE'))
        self.show_land_auth_manage_panel(player, land_id)

    def show_land_explosion_setting_panel(self, player: Player, land_id: int):
        """显示领地爆炸保护设置面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND15",
                f"show_land_explosion_setting_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        current_allow_explosion = land_info.get('allow_explosion', False)
        status_text = self.language_manager.GetText('LAND_EXPLOSION_STATUS_ENABLED') if current_allow_explosion else self.language_manager.GetText('LAND_EXPLOSION_STATUS_DISABLED')
        
        explosion_setting_panel = ActionForm(
            title=self.language_manager.GetText('LAND_EXPLOSION_SETTING_TITLE'),
            content=self.language_manager.GetText('LAND_EXPLOSION_CURRENT_STATUS').format(status_text),
            on_close=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        
        if current_allow_explosion:
            # 当前允许爆炸，显示禁止爆炸按钮
            explosion_setting_panel.add_button(
                self.language_manager.GetText('LAND_EXPLOSION_TOGGLE_DISABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_explosion_setting(p, l_id, False)
            )
        else:
            # 当前禁止爆炸，显示允许爆炸按钮
            explosion_setting_panel.add_button(
                self.language_manager.GetText('LAND_EXPLOSION_TOGGLE_ENABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_explosion_setting(p, l_id, True)
            )
        
        player.send_form(explosion_setting_panel)

    def show_land_public_interact_setting_panel(self, player: Player, land_id: int):
        """显示领地方块互动开放设置面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND16",
                f"show_land_public_interact_setting_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        current_allow_public_interact = land_info.get('allow_public_interact', False)
        status_text = self.language_manager.GetText('LAND_PUBLIC_INTERACT_STATUS_ENABLED') if current_allow_public_interact else self.language_manager.GetText('LAND_PUBLIC_INTERACT_STATUS_DISABLED')
        
        public_interact_setting_panel = ActionForm(
            title=self.language_manager.GetText('LAND_PUBLIC_INTERACT_SETTING_TITLE'),
            content=self.language_manager.GetText('LAND_PUBLIC_INTERACT_CURRENT_STATUS').format(status_text),
            on_close=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        
        if current_allow_public_interact:
            # 当前对所有人开放方块互动，显示关闭按钮
            public_interact_setting_panel.add_button(
                self.language_manager.GetText('LAND_PUBLIC_INTERACT_TOGGLE_DISABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_public_interact_setting(p, l_id, False)
            )
        else:
            # 当前不对所有人开放方块互动，显示开启按钮
            public_interact_setting_panel.add_button(
                self.language_manager.GetText('LAND_PUBLIC_INTERACT_TOGGLE_ENABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_public_interact_setting(p, l_id, True)
            )
        
        player.send_form(public_interact_setting_panel)

    def toggle_land_public_interact_setting(self, player: Player, land_id: int, allow_public_interact: bool):
        """切换领地方块互动开放设置"""
        try:
            success = self.land_system.set_land_allow_public_interact(land_id, allow_public_interact)
            if success:
                key = 'LAND_PUBLIC_INTERACT_SETTING_UPDATED_ENABLE' if allow_public_interact else 'LAND_PUBLIC_INTERACT_SETTING_UPDATED_DISABLE'
                player.send_message(self.language_manager.GetText(key).format(land_id))
            else:
                player.send_message(self.language_manager.GetText('LAND_PUBLIC_INTERACT_SETTING_FAILED'))
            land_info = self.get_land_info(land_id)
            self.show_own_land_detail_panel(player, land_id, land_info)
        except Exception as e:
            self.logger.error(f"Update land public interact setting error: {str(e)}")
            self.report_arc_error(
                "LAND17",
                f"toggle_land_public_interact_setting exception land_id={land_id!r}",
                player,
                exception=e,
            )

    def toggle_land_explosion_setting(self, player: Player, land_id: int, allow_explosion: bool):
        """切换领地爆炸保护设置"""
        try:
            success = self.land_system.set_land_allow_explosion(land_id, allow_explosion)
            if success:
                key = 'LAND_EXPLOSION_SETTING_UPDATED_ENABLE' if allow_explosion else 'LAND_EXPLOSION_SETTING_UPDATED_DISABLE'
                player.send_message(self.language_manager.GetText(key).format(land_id))
            else:
                player.send_message(self.language_manager.GetText('LAND_EXPLOSION_SETTING_FAILED'))
        except Exception as e:
            self.logger.error(f"Toggle land explosion setting error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_EXPLOSION_SETTING_FAILED'))
        land_info = self.get_land_info(land_id)
        if land_info:
            self.show_own_land_detail_panel(player, land_id, land_info)

    def show_land_actor_interaction_setting_panel(self, player: Player, land_id: int):
        """显示领地生物互动设置面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND18",
                f"show_land_actor_interaction_setting_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        current_allow_actor_interaction = land_info.get('allow_actor_interaction', False)
        status_text = self.language_manager.GetText('LAND_ACTOR_INTERACTION_STATUS_ENABLED') if current_allow_actor_interaction else self.language_manager.GetText('LAND_ACTOR_INTERACTION_STATUS_DISABLED')
        
        actor_interaction_setting_panel = ActionForm(
            title=self.language_manager.GetText('LAND_ACTOR_INTERACTION_SETTING_TITLE'),
            content=self.language_manager.GetText('LAND_ACTOR_INTERACTION_CURRENT_STATUS').format(status_text),
            on_close=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        
        if current_allow_actor_interaction:
            # 当前允许生物互动，显示禁止生物互动按钮
            actor_interaction_setting_panel.add_button(
                self.language_manager.GetText('LAND_ACTOR_INTERACTION_TOGGLE_DISABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_actor_interaction_setting(p, l_id, False)
            )
        else:
            # 当前禁止生物互动，显示允许生物互动按钮
            actor_interaction_setting_panel.add_button(
                self.language_manager.GetText('LAND_ACTOR_INTERACTION_TOGGLE_ENABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_actor_interaction_setting(p, l_id, True)
            )
        
        player.send_form(actor_interaction_setting_panel)

    def show_land_actor_damage_setting_panel(self, player: Player, land_id: int):
        """显示领地生物攻击设置面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND19",
                f"show_land_actor_damage_setting_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        current_allow_actor_damage = land_info.get('allow_actor_damage', False)
        status_text = self.language_manager.GetText('LAND_ACTOR_DAMAGE_STATUS_ENABLED') if current_allow_actor_damage else self.language_manager.GetText('LAND_ACTOR_DAMAGE_STATUS_DISABLED')
        
        actor_damage_setting_panel = ActionForm(
            title=self.language_manager.GetText('LAND_ACTOR_DAMAGE_SETTING_TITLE'),
            content=self.language_manager.GetText('LAND_ACTOR_DAMAGE_CURRENT_STATUS').format(status_text),
            on_close=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        
        if current_allow_actor_damage:
            # 当前允许攻击生物，显示禁止攻击生物按钮
            actor_damage_setting_panel.add_button(
                self.language_manager.GetText('LAND_ACTOR_DAMAGE_TOGGLE_DISABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_actor_damage_setting(p, l_id, False)
            )
        else:
            # 当前禁止攻击生物，显示允许攻击生物按钮
            actor_damage_setting_panel.add_button(
                self.language_manager.GetText('LAND_ACTOR_DAMAGE_TOGGLE_ENABLE_BUTTON'),
                on_click=lambda p=player, l_id=land_id: self.toggle_land_actor_damage_setting(p, l_id, True)
            )
        
        player.send_form(actor_damage_setting_panel)

    def toggle_land_actor_interaction_setting(self, player: Player, land_id: int, allow_actor_interaction: bool):
        """切换领地生物互动设置"""
        try:
            success = self.land_system.set_land_allow_actor_interaction(land_id, allow_actor_interaction)
            if success:
                key = 'LAND_ACTOR_INTERACTION_SETTING_UPDATED_ENABLE' if allow_actor_interaction else 'LAND_ACTOR_INTERACTION_SETTING_UPDATED_DISABLE'
                player.send_message(self.language_manager.GetText(key).format(land_id))
            else:
                player.send_message(self.language_manager.GetText('LAND_ACTOR_INTERACTION_SETTING_FAILED'))
        except Exception as e:
            self.logger.error(f"Toggle land actor interaction setting error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_ACTOR_INTERACTION_SETTING_FAILED'))
        land_info = self.get_land_info(land_id)
        if land_info:
            self.show_own_land_detail_panel(player, land_id, land_info)

    def toggle_land_actor_damage_setting(self, player: Player, land_id: int, allow_actor_damage: bool):
        """切换领地生物攻击设置"""
        try:
            success = self.land_system.set_land_allow_actor_damage(land_id, allow_actor_damage)
            if success:
                key = 'LAND_ACTOR_DAMAGE_SETTING_UPDATED_ENABLE' if allow_actor_damage else 'LAND_ACTOR_DAMAGE_SETTING_UPDATED_DISABLE'
                player.send_message(self.language_manager.GetText(key).format(land_id))
            else:
                player.send_message(self.language_manager.GetText('LAND_ACTOR_DAMAGE_SETTING_FAILED'))
        except Exception as e:
            self.logger.error(f"Toggle land actor damage setting error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_ACTOR_DAMAGE_SETTING_FAILED'))
        land_info = self.get_land_info(land_id)
        if land_info:
            self.show_own_land_detail_panel(player, land_id, land_info)

    def show_land_frame_setting_panel(self, player: Player, land_id: int):
        """领地展示框权限设置：为 False 时禁止对展示框/发光展示框进行互动与破坏。"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.show_own_land_menu(player)
            return
        current_allow_frame = land_info.get('allow_frame', False)
        status_text = self.language_manager.GetText('LAND_FRAME_STATUS_ENABLED') if current_allow_frame else self.language_manager.GetText('LAND_FRAME_STATUS_DISABLED')
        panel = ActionForm(
            title=self.language_manager.GetText('LAND_FRAME_SETTING_TITLE'),
            content=self.language_manager.GetText('LAND_FRAME_CURRENT_STATUS').format(status_text),
            on_close=lambda p=player, l_id=land_id, linfo=self.get_land_info(land_id): self.show_own_land_detail_panel(p, l_id, linfo)
        )
        panel.add_button(self.language_manager.GetText('LAND_FRAME_TOGGLE_ENABLE_BUTTON'),
                         on_click=lambda p=player, l_id=land_id: self.toggle_land_frame_setting(p, l_id, True))
        panel.add_button(self.language_manager.GetText('LAND_FRAME_TOGGLE_DISABLE_BUTTON'),
                         on_click=lambda p=player, l_id=land_id: self.toggle_land_frame_setting(p, l_id, False))
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                         on_click=lambda p=player, l_id=land_id, linfo=self.get_land_info(land_id): self.show_own_land_detail_panel(p, l_id, linfo))
        player.send_form(panel)

    def toggle_land_frame_setting(self, player: Player, land_id: int, allow_frame: bool):
        try:
            success = self.land_system.set_land_allow_frame(land_id, allow_frame)
            if success:
                key = 'LAND_FRAME_SETTING_UPDATED_ENABLE' if allow_frame else 'LAND_FRAME_SETTING_UPDATED_DISABLE'
                player.send_message(self.language_manager.GetText(key).format(land_id))
            else:
                player.send_message(self.language_manager.GetText('LAND_FRAME_SETTING_FAILED'))
        except Exception as e:
            self.logger.error(f"Toggle land frame setting error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_FRAME_SETTING_FAILED'))
        land_info = self.get_land_info(land_id)
        if land_info:
            self.show_own_land_detail_panel(player, land_id, land_info)

    def show_create_new_land_guide(self, player: Player):
        """显示创建领地的坐标输入表单，可预填上次设定的值"""
        cached = self.player_new_land_creation_info.get(player.name, {})
        default_min_x = str(cached.get('min_x', math.floor(player.location.x)))
        default_max_x = str(cached.get('max_x', math.floor(player.location.x)))
        default_min_y = str(cached.get('min_y', math.floor(player.location.y)))
        default_max_y = str(cached.get('max_y', math.floor(player.location.y)))
        default_min_z = str(cached.get('min_z', math.floor(player.location.z)))
        default_max_z = str(cached.get('max_z', math.floor(player.location.z)))

        controls = [
            Label(text=self.language_manager.GetText('CREATE_LAND_FORM_DIMENSION_LABEL').format(player.location.dimension.name)),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MIN_X'), placeholder='例如: -100', default_value=default_min_x),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MAX_X'), placeholder='例如: 100', default_value=default_max_x),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MIN_Y'), placeholder='例如: 0', default_value=default_min_y),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MAX_Y'), placeholder='例如: 255', default_value=default_max_y),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MIN_Z'), placeholder='例如: -100', default_value=default_min_z),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MAX_Z'), placeholder='例如: 100', default_value=default_max_z),
        ]

        def on_submit(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
                # data[0] is Label (ignored), data[1..6] are the text inputs
                min_x_str = data[1]
                max_x_str = data[2]
                min_y_str = data[3]
                max_y_str = data[4]
                min_z_str = data[5]
                max_z_str = data[6]
                try:
                    min_x = int(min_x_str)
                    max_x = int(max_x_str)
                    min_y = int(min_y_str)
                    max_y = int(max_y_str)
                    min_z = int(min_z_str)
                    max_z = int(max_z_str)
                except (ValueError, TypeError):
                    p.send_message(self.language_manager.GetText('CREATE_LAND_FORM_INVALID_COORD'))
                    return
                # 自动排序
                min_x, max_x = min(min_x, max_x), max(min_x, max_x)
                min_y, max_y = min(min_y, max_y), max(min_y, max_y)
                min_z, max_z = min(min_z, max_z), max(min_z, max_z)
                self.player_new_land_creation_info[p.name] = {
                    'dimension': p.location.dimension.name,
                    'min_x': min_x, 'max_x': max_x,
                    'min_y': min_y, 'max_y': max_y,
                    'min_z': min_z, 'max_z': max_z
                }
                self._visualize_pending_land(p)
                self.show_pending_land_purchase_panel(p)
            except Exception as e:
                self.logger.error(f"Create land form submit error: {str(e)}")
                self.report_arc_error(
                    "LAND20",
                    "show_create_new_land_guide on_submit exception",
                    p,
                    exception=e,
                )

        form = ModalForm(
            title=self.language_manager.GetText('CREATE_LAND_FORM_TITLE'),
            controls=controls,
            on_submit=on_submit,
            on_close=self.show_land_main_menu
        )
        player.send_form(form)

    def show_current_land_info(self, player: Player):
        """显示玩家当前位置的领地信息并绘制粒子边界"""
        try:
            # 获取玩家当前位置（与位置线程、权限检测使用同一套维度和坐标逻辑）
            pos = self.get_player_position_vector(player)
            if not pos:
                self.report_arc_error(
                    "LAND21",
                    f"show_current_land_info get_player_position_vector None player={player.name!r}",
                    player,
                )
                return
            
            x, y, z = pos
            dimension = player.location.dimension.name
            
            # 获取当前位置的领地ID（传入 y 做三维判断，与进入领地提示一致）
            land_id = self.get_land_at_pos(dimension, x, z, y)
            
            if not land_id:
                player.send_message(self.language_manager.GetText('LAND_CURRENT_POSITION_NO_LAND'))
                return
            
            # 获取领地详细信息
            land_info = self.get_land_info(land_id)
            if not land_info:
                self.report_arc_error(
                    "LAND22",
                    f"show_current_land_info get_land_info empty land_id={land_id!r}",
                    player,
                )
                return
            
            # 获取领地拥有者名称（公共领地显示「公共领地」）
            owner_name = self.get_land_display_owner_name(land_id) or '未知'
            
            # 格式化爆炸保护状态
            explosion_status = (self.language_manager.GetText('LAND_CURRENT_POSITION_EXPLOSION_ENABLED') 
                              if land_info.get('allow_explosion', False) 
                              else self.language_manager.GetText('LAND_CURRENT_POSITION_EXPLOSION_DISABLED'))
            
            # 格式化公共互动状态
            public_interact_status = (self.language_manager.GetText('LAND_CURRENT_POSITION_PUBLIC_INTERACT_ENABLED') 
                                    if land_info.get('allow_public_interact', False) 
                                    else self.language_manager.GetText('LAND_CURRENT_POSITION_PUBLIC_INTERACT_DISABLED'))
            
            shared_users = land_info.get('shared_users', [])
            if shared_users:
                shared_names = [self.get_player_name_by_xuid(uid) or uid for uid in shared_users]
                shared_str = ', '.join(shared_names)
            else:
                shared_str = self.language_manager.GetText('LAND_DETAIL_NO_SHARED_USER_TEXT')

            land_message = self.language_manager.GetText('LAND_CURRENT_POSITION_INFO').format(
                land_id,
                land_info['land_name'],
                owner_name,
                land_info['dimension'],
                land_info['min_x'], land_info.get('min_y', 0), land_info['min_z'],
                land_info['max_x'], land_info.get('max_y', 255), land_info['max_z'],
                land_info['tp_x'], land_info['tp_y'], land_info['tp_z'],
                explosion_status,
                public_interact_status
            )

            info_panel = ActionForm(
                title=self.language_manager.GetText('LAND_CURRENT_PANEL_TITLE'),
                content=land_message + '\n' + self.language_manager.GetText('LAND_CURRENT_POSITION_SHARED_USERS').format(shared_str),
                on_close=self.show_land_main_menu
            )

            info_panel.add_button(
                self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                on_click=self.show_land_main_menu
            )

            # 显示粒子边界
            self.display_land_particle_boundary(player, land_info)
            player.send_form(info_panel)
            
        except Exception as e:
            self.logger.error(f"Show current land info error: {str(e)}")
            self.report_arc_error(
                "LAND23",
                "show_current_land_info outer exception",
                player,
                exception=e,
            )

    def display_land_particle_boundary(self, player: Player, land_info: dict, y_coord: float = None):
        """显示三维领地粒子边界（立方体12条棱）"""
        try:
            min_x = land_info['min_x']
            max_x = land_info['max_x']
            min_y = land_info.get('min_y', 0)
            max_y = land_info.get('max_y', 255)
            min_z = land_info['min_z']
            max_z = land_info['max_z']

            STEPS = 8  # 每条棱的插值段数（含端点共9个点）

            def emit(x, y, z):
                self.server.dispatch_command(
                    self.server.command_sender,
                    f"particle minecraft:crop_growth_emitter {x} {y} {z}"
                )

            def draw_edge(p1, p2):
                """在两点之间均匀生成粒子"""
                for i in range(STEPS + 1):
                    t = i / STEPS
                    x = p1[0] + (p2[0] - p1[0]) * t
                    y = p1[1] + (p2[1] - p1[1]) * t
                    z = p1[2] + (p2[2] - p1[2]) * t
                    emit(x, y, z)

            # 立方体8个顶点
            corners = [
                (min_x, min_y, min_z),
                (max_x, min_y, min_z),
                (max_x, min_y, max_z),
                (min_x, min_y, max_z),
                (min_x, max_y, min_z),
                (max_x, max_y, min_z),
                (max_x, max_y, max_z),
                (min_x, max_y, max_z),
            ]

            # 底面4条棱
            draw_edge(corners[0], corners[1])
            draw_edge(corners[1], corners[2])
            draw_edge(corners[2], corners[3])
            draw_edge(corners[3], corners[0])
            # 顶面4条棱
            draw_edge(corners[4], corners[5])
            draw_edge(corners[5], corners[6])
            draw_edge(corners[6], corners[7])
            draw_edge(corners[7], corners[4])
            # 4条竖直棱
            draw_edge(corners[0], corners[4])
            draw_edge(corners[1], corners[5])
            draw_edge(corners[2], corners[6])
            draw_edge(corners[3], corners[7])

        except Exception as e:
            self.logger.error(f"Display land particle boundary error: {str(e)}")
            self.report_arc_error(
                "LAND24",
                "display_land_particle_boundary exception",
                player,
                exception=e,
            )

    def show_new_land_info(self, player: Player):
        """兼容旧入口：打开待购领地面板。"""
        self.show_pending_land_purchase_panel(player)

    def _execute_land_buy(self, player: Player):
        """供 /landbuy 调用：打开购买确认面板（不再直接扣款购买）。"""
        self.show_pending_land_purchase_panel(player)

    def _visualize_pending_land(self, player: Player):
        """用粒子效果可视化玩家缓存中的待购买领地"""
        info = self.player_new_land_creation_info.get(player.name)
        if not info:
            return
        self.display_land_particle_boundary(player, {
            'min_x': info['min_x'], 'max_x': info['max_x'],
            'min_y': info['min_y'], 'max_y': info['max_y'],
            'min_z': info['min_z'], 'max_z': info['max_z']
        })

    def clear_new_land_creation_info_memory(self, player: Player):
        self.player_new_land_creation_info.pop(player.name, None)
        self.player_land_creation_pick.pop(player.name, None)
        self.player_land_pick_last_event_ts.pop(player.name, None)

    def start_interactive_land_creation(self, player: Player):
        """创建领地：先在世界中交互 4 个选点，再进入购买确认面板。"""
        if not self.if_player_logined(player):
            self.show_main_menu(player)
            return
        self.player_new_land_creation_info.pop(player.name, None)
        self.player_land_pos1.pop(player.name, None)
        self.player_land_creation_pick[player.name] = {
            "step": "rect_a",
            "dimension": player.location.dimension.name,
        }
        self.player_land_pick_last_event_ts.pop(player.name, None)
        player.send_message(self.language_manager.GetText("LAND_CREATION_PICK_RECT_A"))

    def _try_consume_land_creation_pick(self, event: PlayerInteractEvent) -> bool:
        """处理圈地选点；已处理则取消默认交互。成功推进选点后打时间戳，短间隔内重复事件视为同一次点击防抖丢弃。"""
        player = event.player
        name = player.name
        state = self.player_land_creation_pick.get(name)
        if not state:
            return False
        if not getattr(event, "has_block", False):
            return False
        block = getattr(event, "block", None)
        if block is None or not hasattr(block, "location") or block.location is None:
            return False
        block_location = block.location
        now_ts = time.time()
        last_ok_ts = self.player_land_pick_last_event_ts.get(name)
        if last_ok_ts is not None and (now_ts - last_ok_ts) < self._land_creation_pick_debounce_sec:
            event.is_cancelled = True
            return True
        if hasattr(block, "dimension") and block.dimension is not None and hasattr(block.dimension, "name"):
            dimension = block.dimension.name
        else:
            dimension = player.location.dimension.name if hasattr(player, "location") and player.location else ""
        if dimension != state.get("dimension"):
            player.send_message(self.language_manager.GetText("LAND_CREATION_PICK_WRONG_DIM"))
            return False
        bx = int(math.floor(block_location.x))
        by = int(math.floor(block_location.y))
        bz = int(math.floor(block_location.z))
        step = state.get("step")
        try:
            if step == "rect_a":
                event.is_cancelled = True
                state["step"] = "rect_b"
                state["ax"], state["az"] = bx, bz
                self.player_land_pick_last_event_ts[name] = time.time()
                player.send_message(self.language_manager.GetText("LAND_CREATION_PICK_RECT_B"))
                return True
            if step == "rect_b":
                event.is_cancelled = True
                ax, az = state["ax"], state["az"]
                state.pop("ax", None)
                state.pop("az", None)
                state["min_x"], state["max_x"] = min(ax, bx), max(ax, bx)
                state["min_z"], state["max_z"] = min(az, bz), max(az, bz)
                state["step"] = "y_min"
                self.player_land_pick_last_event_ts[name] = time.time()
                player.send_message(self.language_manager.GetText("LAND_CREATION_PICK_Y_MIN"))
                return True
            if step == "y_min":
                event.is_cancelled = True
                state["y_low"] = by
                state["step"] = "y_max"
                self.player_land_pick_last_event_ts[name] = time.time()
                player.send_message(self.language_manager.GetText("LAND_CREATION_PICK_Y_MAX"))
                return True
            if step == "y_max":
                event.is_cancelled = True
                y_low = int(state.get("y_low", by))
                y_high = by
                min_y = min(y_low, y_high)
                max_y = max(y_low, y_high)
                self.player_new_land_creation_info[name] = {
                    "dimension": state["dimension"],
                    "min_x": state["min_x"],
                    "max_x": state["max_x"],
                    "min_y": min_y,
                    "max_y": max_y,
                    "min_z": state["min_z"],
                    "max_z": state["max_z"],
                }
                self.player_land_creation_pick.pop(name, None)
                self.player_land_pick_last_event_ts.pop(name, None)
                self._visualize_pending_land(player)
                self.show_pending_land_purchase_panel(player)
                return True
        except Exception as e:
            self.logger.error(f"[ARC Core] land creation pick error: {e}")
            self.report_arc_error(
                "LAND_PICK1",
                "_try_consume_land_creation_pick exception",
                player,
                exception=e,
            )
        return False

    def show_pending_land_purchase_panel(self, player: Player):
        """待购领地：粒子预览、坐标修改、确认购买；亦供 /landbuy 打开。"""
        info = self.player_new_land_creation_info.get(player.name)
        if not info:
            player.send_message(self.language_manager.GetText("LANDBUY_NO_PENDING_LAND"))
            return

        dimension = info["dimension"]
        min_x, max_x = info["min_x"], info["max_x"]
        min_y, max_y = info["min_y"], info["max_y"]
        min_z, max_z = info["min_z"], info["max_z"]

        if_allowed, reason, overlap_ids = self.check_land_availability(dimension, min_x, max_x, min_y, max_y, min_z, max_z)
        if not if_allowed:
            if reason == "SYSTEM_ERROR":
                self.report_arc_error(
                    "LAND0",
                    f"show_pending_land_purchase_panel check_land_availability SYSTEM_ERROR dim={dimension!r} overlap_ids={overlap_ids!r}",
                    player,
                )
            msg = self.language_manager.GetText(f"CHECK_NEW_LAND_AVAILABILITY_FAIL_{reason}")
            if overlap_ids:
                land_parts = [f"#{lid} {self.get_land_name(lid) or ''}".strip() for lid in overlap_ids]
                msg = msg + "\n" + self.language_manager.GetText("LAND_OVERLAP_WITH_LANDS").format(", ".join(land_parts))
            player.send_message(msg)
            return

        length = max_x - min_x + 1
        height = max_y - min_y + 1
        width = max_z - min_z + 1

        if length <= self.land_min_size or width <= self.land_min_size:
            player.send_message(
                self.language_manager.GetText("CREATE_NEW_LAND_SIZE_TOO_SMALL").format(length, width, self.land_min_size)
            )
            return

        volume = length * height * width

        remaining_free_blocks = self.get_player_free_land_blocks(player)
        paid_blocks = max(0, volume - remaining_free_blocks)
        money_cost = paid_blocks * self.land_price
        used_free_blocks = min(volume, remaining_free_blocks)

        player_money = self.get_player_money(player)
        can_afford = player.is_op or player_money >= money_cost

        base_text = self.language_manager.GetText("NEW_LAND_INFO_TEXT").format(
            dimension,
            (min_x, min_y, min_z),
            (max_x, max_y, max_z),
            volume,
            self._format_money_display(money_cost),
            self._format_money_display(player_money),
        )
        content = base_text + "\n" + self.language_manager.GetText("NEW_LAND_PURCHASE_CONTENT_SUFFIX")

        purchase_form = ActionForm(
            title=self.language_manager.GetText("LAND_PENDING_PURCHASE_PANEL_TITLE"),
            content=content,
            on_close=self.show_land_main_menu,
        )

        def _preview(p: Player):
            self._visualize_pending_land(p)
            p.send_message(self.language_manager.GetText("LAND_CURRENT_POSITION_PARTICLE_DISPLAY"))

        purchase_form.add_button(self.language_manager.GetText("LAND_PENDING_PREVIEW_BUTTON"), on_click=_preview)
        purchase_form.add_button(
            self.language_manager.GetText("LAND_PENDING_EDIT_COORD_BUTTON"),
            on_click=self.show_edit_pending_land_coordinates_modal,
        )
        purchase_form.add_button(
            self.language_manager.GetText("LAND_PENDING_MANUAL_INPUT_BUTTON"),
            on_click=self.show_create_new_land_guide,
        )
        purchase_form.add_button(
            self.language_manager.GetText("LAND_PENDING_RESTART_PICK_BUTTON"),
            on_click=self.start_interactive_land_creation,
        )
        if can_afford:
            purchase_form.add_button(
                self.language_manager.GetText("BUY_NEW_LAND_TEXT"),
                on_click=lambda p: self.player_buy_new_land(
                    p, dimension, min_x, max_x, min_y, max_y, min_z, max_z, volume, money_cost, used_free_blocks
                ),
            )
        else:
            purchase_form.add_button(self.language_manager.GetText("BUY_NEW_LAND_NO_MONEY_TEXT"))

        purchase_form.add_button(self.language_manager.GetText("RETURN_BUTTON_TEXT"), on_click=self.show_land_main_menu)
        player.send_form(purchase_form)

    def show_edit_pending_land_coordinates_modal(self, player: Player):
        """待购领地：6 个整数框 xmin/xmax ymin ymax zmin zmax（与领地存储字段一致）。"""
        info = self.player_new_land_creation_info.get(player.name)
        if not info:
            player.send_message(self.language_manager.GetText("LANDBUY_NO_PENDING_LAND"))
            return

        controls = [
            Label(text=self.language_manager.GetText("LAND_PENDING_EDIT_COORD_LABEL")),
            TextInput(
                label=self.language_manager.GetText("CREATE_LAND_FORM_MIN_X"),
                default_value=str(info["min_x"]),
            ),
            TextInput(
                label=self.language_manager.GetText("CREATE_LAND_FORM_MAX_X"),
                default_value=str(info["max_x"]),
            ),
            TextInput(
                label=self.language_manager.GetText("CREATE_LAND_FORM_MIN_Y"),
                default_value=str(info["min_y"]),
            ),
            TextInput(
                label=self.language_manager.GetText("CREATE_LAND_FORM_MAX_Y"),
                default_value=str(info["max_y"]),
            ),
            TextInput(
                label=self.language_manager.GetText("CREATE_LAND_FORM_MIN_Z"),
                default_value=str(info["min_z"]),
            ),
            TextInput(
                label=self.language_manager.GetText("CREATE_LAND_FORM_MAX_Z"),
                default_value=str(info["max_z"]),
            ),
        ]

        def on_submit(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
                try:
                    raw_min_x = int(data[1])
                    raw_max_x = int(data[2])
                    raw_min_y = int(data[3])
                    raw_max_y = int(data[4])
                    raw_min_z = int(data[5])
                    raw_max_z = int(data[6])
                except (ValueError, TypeError, IndexError):
                    p.send_message(self.language_manager.GetText("CREATE_LAND_FORM_INVALID_COORD"))
                    return
                min_x, max_x = min(raw_min_x, raw_max_x), max(raw_min_x, raw_max_x)
                min_y, max_y = min(raw_min_y, raw_max_y), max(raw_min_y, raw_max_y)
                min_z, max_z = min(raw_min_z, raw_max_z), max(raw_min_z, raw_max_z)
                p_new = self.player_new_land_creation_info.get(p.name, {})
                dim = p_new.get("dimension", p.location.dimension.name)
                self.player_new_land_creation_info[p.name] = {
                    "dimension": dim,
                    "min_x": min_x,
                    "max_x": max_x,
                    "min_y": min_y,
                    "max_y": max_y,
                    "min_z": min_z,
                    "max_z": max_z,
                }
                self._visualize_pending_land(p)
                self.show_pending_land_purchase_panel(p)
            except Exception as e:
                self.logger.error(f"Edit pending land coords error: {e}")
                self.report_arc_error(
                    "LAND_EDIT1",
                    "show_edit_pending_land_coordinates_modal on_submit exception",
                    p,
                    exception=e,
                )

        form = ModalForm(
            title=self.language_manager.GetText("LAND_PENDING_EDIT_COORD_TITLE"),
            controls=controls,
            on_submit=on_submit,
            on_close=lambda p: self.show_pending_land_purchase_panel(p),
        )
        player.send_form(form)

    def player_buy_new_land(self, player: Player, dimension: str,
                            min_x: int, max_x: int, min_y: int, max_y: int, min_z: int, max_z: int,
                            volume: int, money_cost: int, used_free_blocks: int = 0):
        if self.judge_if_player_has_enough_money(player, money_cost) or player.is_op:
            paid_money = float(money_cost) if not player.is_op else 0.0
            land_id = self.create_land(
                str(player.xuid),
                self.language_manager.GetText('DEFAULT_LAND_NAME').format(player.name, self.get_player_land_count(str(player.xuid)) + 1),
                dimension, min_x, max_x, min_y, max_y, min_z, max_z,
                player.location.x, player.location.y, player.location.z,
                owner_paid_money=paid_money
            )
            if land_id is not None:
                if not player.is_op:
                    if money_cost > 0:
                        if self.decrease_player_money(player, money_cost):
                            player.send_message(self.language_manager.GetText('PAY_SUCCESS_HINT').format(
                                self._format_money_display(money_cost),
                                self._format_money_display(self.get_player_money(player))))
                        else:
                            self.report_arc_error(
                                "LAND_PAY1",
                                f"player_buy_new_land land_id={land_id} created but decrease_money failed cost={money_cost!r}",
                                player,
                            )

                    if used_free_blocks > 0:
                        current_free_blocks = self.get_player_free_land_blocks(player)
                        new_free_blocks = max(0, current_free_blocks - used_free_blocks)
                        self.set_player_free_land_blocks(player, new_free_blocks)
                        player.send_message(self.language_manager.GetText('USE_FREE_BLOCKS_HINT').format(used_free_blocks))

                self.clear_new_land_creation_info_memory(player)
                self.show_own_land_detail_panel(player, land_id, self.get_land_info(land_id))
            else:
                self.report_arc_error(
                    "LAND26",
                    f"player_buy_new_land create_land returned None player={player.name!r} dim={dimension!r}",
                    player,
                )
        else:
            player.send_message(self.language_manager.GetText('PAY_FAIL_NO_ENOUGH_MONEY').format(
                self._format_money_display(money_cost),
                self._format_money_display(self.get_player_money(player))))

    # ─── Sub-land UI ─────────────────────────────────────────────────────────────

    def show_sub_land_manage_panel(self, player: Player, land_id: int):
        """领地主人管理子领地：查看所有子领地 + 新建"""
        sub_lands = self.get_sub_lands_by_parent(land_id)
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "LAND27",
                f"show_sub_land_manage_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            return
        panel = ActionForm(
            title=self.language_manager.GetText('SUB_LAND_MANAGE_PANEL_TITLE'),
            content=self.language_manager.GetText('SUB_LAND_MANAGE_PANEL_CONTENT').format(len(sub_lands)),
            on_close=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        panel.add_button(
            self.language_manager.GetText('SUB_LAND_CREATE_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id: self.show_create_sub_land_form(p, l_id)
        )
        for sl_id, sl_info in sub_lands.items():
            owner_name = self.get_player_name_by_xuid(sl_info['owner_xuid']) or sl_info['owner_xuid']
            panel.add_button(
                self.language_manager.GetText('SUB_LAND_LIST_BUTTON_TEXT').format(sl_id, sl_info['sub_land_name'], owner_name),
                on_click=lambda p=player, sl=sl_id: self.show_sub_land_detail_panel(p, sl)
            )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, l_info=land_info: self.show_own_land_detail_panel(p, l_id, l_info)
        )
        player.send_form(panel)

    def show_create_sub_land_form(self, player: Player, land_id: int):
        """显示创建子领地的 XYZ 输入表单"""
        parent_info = self.get_land_info(land_id)
        if not parent_info:
            self.report_arc_error(
                "LAND28",
                f"show_create_sub_land_form get_land_info empty land_id={land_id!r}",
                player,
            )
            return

        p_min_x, p_max_x = parent_info['min_x'], parent_info['max_x']
        p_min_y, p_max_y = parent_info.get('min_y', 0), parent_info.get('max_y', 255)
        p_min_z, p_max_z = parent_info['min_z'], parent_info['max_z']

        default_px = str(math.floor(player.location.x))
        default_py = str(math.floor(player.location.y))
        default_pz = str(math.floor(player.location.z))

        hint_label = self.language_manager.GetText('SUB_LAND_FORM_HINT').format(
            p_min_x, p_min_y, p_min_z, p_max_x, p_max_y, p_max_z
        )

        def _back(p):
            self.show_sub_land_manage_panel(p, land_id)

        controls = [
            Label(text=hint_label),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MIN_X'), placeholder=str(p_min_x), default_value=default_px),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MAX_X'), placeholder=str(p_max_x), default_value=default_px),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MIN_Y'), placeholder=str(p_min_y), default_value=default_py),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MAX_Y'), placeholder=str(p_max_y), default_value=default_py),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MIN_Z'), placeholder=str(p_min_z), default_value=default_pz),
            TextInput(label=self.language_manager.GetText('CREATE_LAND_FORM_MAX_Z'), placeholder=str(p_max_z), default_value=default_pz),
            TextInput(label=self.language_manager.GetText('SUB_LAND_NAME_INPUT_LABEL'),
                      placeholder=self.language_manager.GetText('SUB_LAND_NAME_INPUT_PLACEHOLDER').format(player.name),
                      default_value=self.language_manager.GetText('SUB_LAND_NAME_INPUT_PLACEHOLDER').format(player.name)),
        ]

        def on_submit(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
                try:
                    min_x = int(data[1]); max_x = int(data[2])
                    min_y = int(data[3]); max_y = int(data[4])
                    min_z = int(data[5]); max_z = int(data[6])
                except (ValueError, TypeError, IndexError):
                    p.send_message(self.language_manager.GetText('CREATE_LAND_FORM_INVALID_COORD'))
                    return
                sub_land_name = (data[7] or '').strip()
                if not sub_land_name:
                    sub_land_name = self.language_manager.GetText('SUB_LAND_NAME_INPUT_PLACEHOLDER').format(p.name)
                min_x, max_x = min(min_x, max_x), max(min_x, max_x)
                min_y, max_y = min(min_y, max_y), max(min_y, max_y)
                min_z, max_z = min(min_z, max_z), max(min_z, max_z)

                ok, reason = self.check_sub_land_availability(land_id, min_x, max_x, min_y, max_y, min_z, max_z)
                if not ok:
                    if reason == "SYSTEM_ERROR":
                        self.report_arc_error(
                            "LAND0C",
                            f"create_sub_land form check_sub_land_availability SYSTEM_ERROR parent_land_id={land_id!r}",
                            p,
                        )
                    p.send_message(self.language_manager.GetText(f'CHECK_SUB_LAND_FAIL_{reason}'))
                    return

                sl_id = self.create_sub_land(land_id, str(p.xuid), sub_land_name, min_x, max_x, min_y, max_y, min_z, max_z)
                if sl_id is not None:
                    p.send_message(self.language_manager.GetText('SUB_LAND_CREATE_SUCCESS').format(sl_id, sub_land_name))
                    self.display_land_particle_boundary(p, {'min_x': min_x, 'max_x': max_x, 'min_y': min_y, 'max_y': max_y, 'min_z': min_z, 'max_z': max_z})
                    self.show_sub_land_detail_panel(p, sl_id)
                else:
                    self.report_arc_error(
                        "LAND29",
                        f"create_sub_land returned None parent_land_id={land_id!r} player={p.name!r}",
                        p,
                    )
            except Exception as e:
                self.logger.error(f"Create sub land form submit error: {str(e)}")
                self.report_arc_error(
                    "LAND30",
                    "show_create_sub_land_form on_submit exception",
                    p,
                    exception=e,
                )

        form = ModalForm(
            title=self.language_manager.GetText('SUB_LAND_CREATE_FORM_TITLE'),
            controls=controls,
            on_submit=on_submit,
            on_close=_back
        )
        player.send_form(form)

    def show_sub_land_detail_panel(self, player: Player, sub_land_id: int):
        """显示子领地详情面板"""
        sl_info = self.get_sub_land_info(sub_land_id)
        if not sl_info:
            self.report_arc_error(
                "LAND31",
                f"show_sub_land_detail_panel get_sub_land_info empty sub_land_id={sub_land_id!r}",
                player,
            )
            return

        parent_land_id = sl_info['parent_land_id']
        is_owner = sl_info['owner_xuid'] == str(player.xuid) or player.is_op
        shared_names = [self.get_player_name_by_xuid(uid) or uid for uid in sl_info['shared_users']]
        shared_str = ', '.join(shared_names) if shared_names else self.language_manager.GetText('LAND_DETAIL_NO_SHARED_USER_TEXT')

        content = self.language_manager.GetText('SUB_LAND_DETAIL_CONTENT').format(
            sub_land_id,
            sl_info['sub_land_name'],
            (sl_info['min_x'], sl_info['min_y'], sl_info['min_z']),
            (sl_info['max_x'], sl_info['max_y'], sl_info['max_z']),
            self.get_player_name_by_xuid(sl_info['owner_xuid']) or sl_info['owner_xuid'],
            shared_str
        )

        def _back(p):
            self.show_sub_land_manage_panel(p, parent_land_id)

        panel = ActionForm(
            title=self.language_manager.GetText('SUB_LAND_DETAIL_PANEL_TITLE'),
            content=content,
            on_close=_back
        )

        if is_owner:
            panel.add_button(
                self.language_manager.GetText('SUB_LAND_MANAGE_AUTH_BUTTON_TEXT'),
                on_click=lambda p=player, sl=sub_land_id: self.show_sub_land_auth_manage_panel(p, sl)
            )
            panel.add_button(
                self.language_manager.GetText('SUB_LAND_RENAME_BUTTON_TEXT'),
                on_click=lambda p=player, sl=sub_land_id: self.show_rename_sub_land_panel(p, sl)
            )
            panel.add_button(
                self.language_manager.GetText('SUB_LAND_DELETE_BUTTON_TEXT'),
                on_click=lambda p=player, sl=sub_land_id: self.confirm_delete_sub_land(p, sl)
            )

        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=_back
        )
        player.send_form(panel)

    def show_rename_sub_land_panel(self, player: Player, sub_land_id: int):
        sl_info = self.get_sub_land_info(sub_land_id)
        if not sl_info:
            self.report_arc_error(
                "LAND32",
                f"show_rename_sub_land_panel get_sub_land_info empty sub_land_id={sub_land_id!r}",
                player,
            )
            return

        def on_submit(p: Player, json_str: str):
            data = json.loads(json_str)
            new_name = (data[0] or '').strip()
            if not new_name:
                p.send_message(self.language_manager.GetText('CREATE_HOME_EMPTY_NAME_ERROR'))
                return
            self.rename_sub_land(sub_land_id, new_name)
            self.show_sub_land_detail_panel(p, sub_land_id)

        form = ModalForm(
            title=self.language_manager.GetText('SUB_LAND_RENAME_PANEL_TITLE'),
            controls=[TextInput(
                label=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_INPUT_LABEL').format(sub_land_id),
                placeholder=sl_info['sub_land_name'],
                default_value=sl_info['sub_land_name']
            )],
            on_submit=on_submit,
            on_close=lambda p=player, sl=sub_land_id: self.show_sub_land_detail_panel(p, sl)
        )
        player.send_form(form)

    def confirm_delete_sub_land(self, player: Player, sub_land_id: int):
        sl_info = self.get_sub_land_info(sub_land_id)
        if not sl_info:
            self.report_arc_error(
                "LAND33",
                f"confirm_delete_sub_land get_sub_land_info empty sub_land_id={sub_land_id!r}",
                player,
            )
            return

        parent_land_id = sl_info['parent_land_id']

        def _back(p):
            self.show_sub_land_manage_panel(p, parent_land_id)

        panel = ActionForm(
            title=self.language_manager.GetText('SUB_LAND_CONFIRM_DELETE_TITLE').format(sub_land_id),
            content=self.language_manager.GetText('SUB_LAND_CONFIRM_DELETE_CONTENT').format(sub_land_id, sl_info['sub_land_name']),
            on_close=lambda p=player, sl=sub_land_id: self.show_sub_land_detail_panel(p, sl)
        )
        panel.add_button(
            self.language_manager.GetText('SUB_LAND_CONFIRM_DELETE_BUTTON'),
            on_click=lambda p=player, sl=sub_land_id, back=_back: self._do_delete_sub_land(p, sl, back)
        )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, sl=sub_land_id: self.show_sub_land_detail_panel(p, sl)
        )
        player.send_form(panel)

    def _do_delete_sub_land(self, player: Player, sub_land_id: int, back_func):
        if self.delete_sub_land(sub_land_id):
            player.send_message(self.language_manager.GetText('SUB_LAND_DELETE_SUCCESS').format(sub_land_id))
        else:
            player.send_message(self.language_manager.GetText('SUB_LAND_DELETE_FAILED'))
        back_func(player)

    def show_sub_land_auth_manage_panel(self, player: Player, sub_land_id: int):
        """管理子领地授权"""
        sl_info = self.get_sub_land_info(sub_land_id)
        if not sl_info:
            self.report_arc_error(
                "LAND34",
                f"show_sub_land_auth_manage_panel get_sub_land_info empty sub_land_id={sub_land_id!r}",
                player,
            )
            return

        panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_MANAGE_TITLE'),
            content=self.language_manager.GetText('SUB_LAND_AUTH_PANEL_CONTENT').format(sub_land_id, sl_info['sub_land_name']),
            on_close=lambda p=player, sl=sub_land_id: self.show_sub_land_detail_panel(p, sl)
        )
        panel.add_button(
            self.language_manager.GetText('LAND_AUTH_ADD_BUTTON'),
            on_click=lambda p=player, sl=sub_land_id: self.show_add_sub_land_auth_panel(p, sl)
        )
        if sl_info['shared_users']:
            panel.add_button(
                self.language_manager.GetText('LAND_AUTH_REMOVE_BUTTON'),
                on_click=lambda p=player, sl=sub_land_id: self.show_remove_sub_land_auth_panel(p, sl)
            )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, sl=sub_land_id: self.show_sub_land_detail_panel(p, sl)
        )
        player.send_form(panel)

    def show_add_sub_land_auth_panel(self, player: Player, sub_land_id: int):
        sl_info = self.get_sub_land_info(sub_land_id)
        if not sl_info:
            self.report_arc_error(
                "LAND35",
                f"show_add_sub_land_auth_panel get_sub_land_info empty sub_land_id={sub_land_id!r}",
                player,
            )
            return
        online_players = [p for p in self.server.online_players if str(p.xuid) != str(player.xuid) and str(p.xuid) != sl_info['owner_xuid'] and str(p.xuid) not in sl_info['shared_users']]
        if not online_players:
            player.send_message(self.language_manager.GetText('LAND_AUTH_NO_SHARED_USERS'))
            self.show_sub_land_auth_manage_panel(player, sub_land_id)
            return
        panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_ADD_PANEL_TITLE'),
            content=self.language_manager.GetText('LAND_AUTH_SELECT_PLAYER_CONTENT'),
            on_close=lambda p=player, sl=sub_land_id: self.show_sub_land_auth_manage_panel(p, sl)
        )
        for op in online_players:
            panel.add_button(
                self.language_manager.GetText('LAND_AUTH_ADD_TARGET_BUTTON').format(op.name),
                on_click=lambda p=player, sl=sub_land_id, target=op: self._do_add_sub_land_auth(p, sl, str(target.xuid), target.name)
            )
        player.send_form(panel)

    def _do_add_sub_land_auth(self, player: Player, sub_land_id: int, target_xuid: str, target_name: str):
        if self.add_sub_land_shared_user(sub_land_id, target_xuid):
            player.send_message(self.language_manager.GetText('LAND_AUTH_SUCCESS_ADD').format(sub_land_id, target_name))
        else:
            player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_ADD'))
        self.show_sub_land_auth_manage_panel(player, sub_land_id)

    def show_remove_sub_land_auth_panel(self, player: Player, sub_land_id: int):
        sl_info = self.get_sub_land_info(sub_land_id)
        if not sl_info or not sl_info['shared_users']:
            player.send_message(self.language_manager.GetText('LAND_AUTH_NO_SHARED_USERS'))
            self.show_sub_land_auth_manage_panel(player, sub_land_id)
            return
        panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_REMOVE_PANEL_TITLE'),
            content=self.language_manager.GetText('LAND_AUTH_SELECT_REMOVE_CONTENT'),
            on_close=lambda p=player, sl=sub_land_id: self.show_sub_land_auth_manage_panel(p, sl)
        )
        for uid in sl_info['shared_users']:
            name = self.get_player_name_by_xuid(uid) or uid
            panel.add_button(
                self.language_manager.GetText('LAND_AUTH_REMOVE_TARGET_BUTTON').format(name),
                on_click=lambda p=player, sl=sub_land_id, u=uid, n=name: self._do_remove_sub_land_auth(p, sl, u, n)
            )
        player.send_form(panel)

    def _do_remove_sub_land_auth(self, player: Player, sub_land_id: int, target_xuid: str, target_name: str):
        if self.remove_sub_land_shared_user(sub_land_id, target_xuid):
            player.send_message(self.language_manager.GetText('LAND_AUTH_SUCCESS_REMOVE').format(target_name, sub_land_id))
        else:
            player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_REMOVE'))
        self.show_sub_land_auth_manage_panel(player, sub_land_id)

    # ─── End Sub-land UI ─────────────────────────────────────────────────────────

    # OP Panel
    def show_op_land_manage_panel(self, player: Player):
        """OP 领地管理二级菜单。"""
        panel = ActionForm(
            title=self.language_manager.GetText('OP_LAND_MANAGE_TITLE'),
            content=self.language_manager.GetText('OP_LAND_MANAGE_CONTENT'),
            on_close=self.show_op_main_panel,
        )
        panel.add_button(
            self.language_manager.GetText('OP_PANEL_MANAGE_ALL_LANDS'),
            on_click=self.show_op_all_lands_panel,
        )
        panel.add_button(
            self.language_manager.GetText('OP_PANEL_MANAGE_LAND_AT_POS'),
            on_click=self.show_op_land_at_pos,
        )
        panel.add_button(
            self.language_manager.GetText('OP_PANEL_REBUILD_CHUNK_MAPPING'),
            on_click=self.show_op_rebuild_chunk_mapping_confirm,
        )
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_main_panel)
        player.send_form(panel)

    def show_op_tools_panel(self, player: Player):
        """OP 工具二级菜单。"""
        panel = ActionForm(
            title=self.language_manager.GetText('OP_TOOLS_TITLE'),
            content=self.language_manager.GetText('OP_TOOLS_CONTENT'),
            on_close=self.show_op_main_panel,
        )
        panel.add_button(
            self.language_manager.GetText('OP_PANEL_SWITCH_GAME_MODE'),
            on_click=self.switch_player_game_mode,
        )
        panel.add_button(self.language_manager.GetText('CLEAR_DROP_ITEM'), on_click=self.clear_drop_item)
        panel.add_button(self.language_manager.GetText('RECORD_COOR_1'), on_click=self.record_coordinate_1)
        panel.add_button(self.language_manager.GetText('RECORD_COOR_2'), on_click=self.record_coordinate_2)
        debug_btn_text = (
            self.language_manager.GetText('OP_DEBUG_MODE_BUTTON_ON')
            if player.name in self.op_debug_mode
            else self.language_manager.GetText('OP_DEBUG_MODE_BUTTON_OFF')
        )
        panel.add_button(debug_btn_text, on_click=self.toggle_op_debug_mode)
        panel.add_button(self.language_manager.GetText('RUN_COMMAND'), on_click=self.run_command_as_self)
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_main_panel)
        player.send_form(panel)

    def show_op_main_panel(self, player: Player):
        op_main_panel = ActionForm(
            title=self.language_manager.GetText('OP_PANEL_TITLE')
        )
        op_main_panel.add_button(self.language_manager.GetText('OP_PANEL_RELOAD_CONFIG_BUTTON'),
                                 on_click=self.op_reload_config)
        op_main_panel.add_button(self.language_manager.GetText('OP_TOOLS_ENTRY'),
                                 on_click=self.show_op_tools_panel)
        op_main_panel.add_button(self.language_manager.GetText('OP_ECONOMY_MANAGE_ENTRY'),
                                 on_click=self.show_economy_manage_panel)
        op_main_panel.add_button(self.language_manager.GetText('OP_LAND_MANAGE_ENTRY'),
                                 on_click=self.show_op_land_manage_panel)
        op_main_panel.add_button(self.language_manager.GetText('OP_TELEPORT_MANAGE_ENTRY'),
                                 on_click=self.show_op_teleport_manage_panel)
        op_main_panel.add_button(self.language_manager.GetText('OP_ACHIEVEMENT_MANAGE_BUTTON'),
                                 on_click=self.show_op_achievement_manage_panel)
        op_main_panel.add_button(self.language_manager.GetText('CHECKIN_CONFIG_OP_BUTTON'),
                                 on_click=self.show_checkin_config_panel)
        op_main_panel.add_button(self.language_manager.GetText('INVITE_REWARD_CONFIG_BUTTON'),
                                 on_click=self.show_invite_reward_config_panel)
        op_main_panel.add_button(self.language_manager.GetText('OP_TITLE_MANAGE_BUTTON'),
                                 on_click=self.show_op_title_manage_panel)
        # 返回
        op_main_panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                                  on_click=self.show_main_menu)
        player.send_form(op_main_panel)

    def show_op_achievement_manage_panel(self, player: Player):
        """OP 成就管理：列表 / 创建 / 返回。"""
        panel = ActionForm(
            title=self.language_manager.GetText("OP_ACHIEVEMENT_PANEL_TITLE"),
            content=self.language_manager.GetText("OP_ACHIEVEMENT_PANEL_CONTENT"),
            on_close=self.show_op_main_panel,
        )
        panel.add_button(self.language_manager.GetText("OP_ACHIEVEMENT_CREATE_BUTTON"),
                         on_click=self.show_op_achievement_create_panel)
        panel.add_button(self.language_manager.GetText("OP_ACHIEVEMENT_LIST_BUTTON"),
                         on_click=self.show_op_achievement_list_panel)
        panel.add_button(self.language_manager.GetText("OP_ACHIEVEMENT_APPLY_DEFAULT_BUTTON"),
                         on_click=self._do_op_apply_default_kill_achievements)
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                         on_click=self.show_op_main_panel)
        player.send_form(panel)

    def _do_op_apply_default_kill_achievements(self, player: Player):
        bundle_size = AchievementSystem.get_horror_kill_bundle_size()
        ok = self.achievement_system.apply_horror_kill_achievement_bundle(self.title_system)
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_APPLY_DEFAULT_DONE").format(bundle_size))
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
        self.show_op_achievement_manage_panel(player)

    def show_op_achievement_list_panel(self, player: Player):
        achievement_rows = self.achievement_system.list_achievements()
        if not achievement_rows:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_EMPTY_HINT"))
            return self.show_op_achievement_manage_panel(player)

        panel = ActionForm(
            title=self.language_manager.GetText("OP_ACHIEVEMENT_LIST_TITLE"),
            content=self.language_manager.GetText("OP_ACHIEVEMENT_LIST_CONTENT"),
            on_close=self.show_op_achievement_manage_panel,
        )
        for achievement_row in achievement_rows:
            name = str(achievement_row.get("name") or "").strip()
            unlock_title = str(achievement_row.get("unlock_title") or "").strip()
            enabled = int(achievement_row.get("enabled") or 0) == 1
            if_hidden = bool(achievement_row.get("if_hidden", False))
            condition_count = len(self.achievement_system.list_conditions(unlock_title))
            status = "§aON§r" if enabled else "§cOFF§r"
            hid = self.language_manager.GetText('OP_ACHIEVEMENT_HIDDEN_TAG') if if_hidden else ""
            label = f"{hid}{status} {name}\n头衔: {unlock_title} | 条件数: {condition_count} | 逻辑: all"
            panel.add_button(
                label,
                on_click=lambda p, ut=unlock_title: self.show_op_achievement_edit_panel(p, ut),
            )
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                         on_click=self.show_op_achievement_manage_panel)
        player.send_form(panel)

    def show_op_achievement_create_panel(self, player: Player):
        """创建成就基础信息。"""
        name_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_NAME"),
            placeholder="例如：僵尸杀手",
            default_value="",
        )
        title_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_UNLOCK_TITLE"),
            placeholder="例如：僵尸杀手",
            default_value="",
        )
        enabled_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_ENABLED"),
            placeholder="1=启用 0=禁用",
            default_value="1",
        )
        hidden_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_IF_HIDDEN"),
            placeholder=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_IF_HIDDEN_HINT"),
            default_value="0",
        )
        form = ModalForm(
            title=self.language_manager.GetText("OP_ACHIEVEMENT_CREATE_TITLE"),
            controls=[name_input, title_input, enabled_input, hidden_input],
            on_close=self.show_op_achievement_manage_panel,
            on_submit=self._do_op_achievement_create,
        )
        player.send_form(form)

    def _do_op_achievement_create(self, player: Player, json_str: str):
        try:
            data = json.loads(json_str)
        except Exception:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_manage_panel(player)

        if not data or len(data) < 3:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_manage_panel(player)

        name = str(data[0] or "").strip()
        unlock_title = str(data[1] or "").strip()
        enabled = str(data[2] or "1").strip() not in ["0", "false", "False", "off", "OFF"]
        if_hidden = False
        if len(data) >= 4:
            if_hidden = str(data[3] or "0").strip() in ["1", "true", "True", "yes", "YES", "on", "ON"]

        ok = self.achievement_system.create_achievement(
            name=name,
            unlock_title=unlock_title,
            enabled=enabled,
            if_hidden=if_hidden,
        )
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_SUCCESS"))
            self.show_op_achievement_edit_panel(player, unlock_title)
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            self.show_op_achievement_manage_panel(player)

    def show_op_achievement_edit_panel(self, player: Player, unlock_title: str):
        achievement_row = self.achievement_system.get_achievement(unlock_title)
        if not achievement_row:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_NOT_FOUND"))
            return self.show_op_achievement_list_panel(player)

        name = str(achievement_row.get("name") or "").strip()
        current_unlock_title = str(achievement_row.get("unlock_title") or "").strip()
        enabled = int(achievement_row.get("enabled") or 0) == 1
        if_hidden = bool(achievement_row.get("if_hidden", False))
        condition_rows = self.achievement_system.list_conditions(current_unlock_title)

        panel = ActionForm(
            title=f"编辑成就: {name}",
            content=(
                f"头衔: {current_unlock_title}\n"
                f"状态: {'启用' if enabled else '禁用'}\n"
                f"隐藏: {'是' if if_hidden else '否'}\n"
                "逻辑: all\n"
                f"条件数: {len(condition_rows)}\n"
                "说明: 全部条件满足后才会解锁。"
            ),
            on_close=self.show_op_achievement_list_panel,
        )
        panel.add_button(
            "编辑基础信息",
            on_click=lambda p, ut=current_unlock_title: self._show_op_achievement_edit_meta_modal(p, ut),
        )
        for condition_row in condition_rows:
            condition_id = int(condition_row.get("id") or 0)
            condition_type = str(condition_row.get("condition_type") or "").strip()
            target_id = str(condition_row.get("target_id") or "").strip()
            required_count = int(condition_row.get("required_count") or 0)
            if condition_type == self.achievement_system.condition_type_kill_entity_sum:
                ids_joined = ", ".join(condition_row.get("target_ids") or [])
                condition_text = f"击杀总和 [{ids_joined}] >= {required_count}"
            elif condition_type == self.achievement_system.condition_type_kill_entity:
                if target_id == "*":
                    condition_text = f"累计击杀任意生物 >= {required_count}"
                else:
                    condition_text = f"击杀 {target_id} >= {required_count}"
            else:
                condition_text = f"{condition_type}:{target_id} >= {required_count}"
            panel.add_button(
                f"条件 #{condition_id}\n{condition_text}",
                on_click=lambda p, ut=current_unlock_title, c_id=condition_id: self.show_op_achievement_condition_panel(p, ut, c_id),
            )
        panel.add_button(
            "新增条件",
            on_click=lambda p, ut=current_unlock_title: self._show_op_achievement_create_condition_modal(p, ut),
        )
        toggle_text = self.language_manager.GetText("OP_ACHIEVEMENT_DISABLE_BUTTON") if enabled else self.language_manager.GetText("OP_ACHIEVEMENT_ENABLE_BUTTON")
        panel.add_button(
            toggle_text,
            on_click=lambda p, ut=current_unlock_title, en=enabled: self._do_op_achievement_toggle(p, ut, not en),
        )
        hidden_toggle = (
            self.language_manager.GetText("OP_ACHIEVEMENT_CLEAR_HIDDEN_BUTTON")
            if if_hidden
            else self.language_manager.GetText("OP_ACHIEVEMENT_SET_HIDDEN_BUTTON")
        )
        panel.add_button(
            hidden_toggle,
            on_click=lambda p, ut=current_unlock_title, h=if_hidden: self._do_op_achievement_toggle_hidden(
                p, ut, not h
            ),
        )
        panel.add_button(
            self.language_manager.GetText("OP_ACHIEVEMENT_DELETE_BUTTON"),
            on_click=lambda p, ut=current_unlock_title: self._do_op_achievement_delete(p, ut),
        )
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                         on_click=self.show_op_achievement_list_panel)
        player.send_form(panel)

    def _show_op_achievement_edit_meta_modal(self, player: Player, unlock_title: str):
        achievement_row = self.achievement_system.get_achievement(unlock_title)
        if not achievement_row:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_NOT_FOUND"))
            return self.show_op_achievement_list_panel(player)

        name_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_NAME"),
            placeholder="",
            default_value=str(achievement_row.get("name") or ""),
        )
        title_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_UNLOCK_TITLE"),
            placeholder="",
            default_value=str(achievement_row.get("unlock_title") or ""),
        )
        enabled_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_ENABLED"),
            placeholder="1=启用 0=禁用",
            default_value="1" if int(achievement_row.get("enabled") or 0) == 1 else "0",
        )
        hidden_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_IF_HIDDEN"),
            placeholder=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_IF_HIDDEN_HINT"),
            default_value="1" if bool(achievement_row.get("if_hidden", False)) else "0",
        )
        form = ModalForm(
            title=f"编辑成就信息: {unlock_title}",
            controls=[name_input, title_input, enabled_input, hidden_input],
            on_close=lambda p, ut=unlock_title: self.show_op_achievement_edit_panel(p, ut),
            on_submit=lambda p, json_str, ut=unlock_title: self._do_op_achievement_save_meta(p, json_str, ut),
        )
        player.send_form(form)

    def _do_op_achievement_save_meta(self, player: Player, json_str: str, old_unlock_title: str):
        try:
            data = json.loads(json_str)
        except Exception:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_edit_panel(player, old_unlock_title)

        if not data or len(data) < 3:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_edit_panel(player, old_unlock_title)

        name = str(data[0] or "").strip()
        new_unlock_title = str(data[1] or "").strip()
        enabled = str(data[2] or "1").strip() not in ["0", "false", "False", "off", "OFF"]
        if_hidden = False
        if len(data) >= 4:
            if_hidden = str(data[3] or "0").strip() in ["1", "true", "True", "yes", "YES", "on", "ON"]

        ok = self.achievement_system.update_achievement(
            old_unlock_title=old_unlock_title,
            name=name,
            new_unlock_title=new_unlock_title,
            enabled=enabled,
            if_hidden=if_hidden,
        )
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_SUCCESS"))
            self.show_op_achievement_edit_panel(player, new_unlock_title)
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            self.show_op_achievement_edit_panel(player, old_unlock_title)

    def _show_op_achievement_create_condition_modal(self, player: Player, unlock_title: str):
        entity_input = TextInput(
            label="生物ID",
            placeholder="例如: minecraft:zombie 或 *",
            default_value="minecraft:zombie",
        )
        required_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_REQUIRED"),
            placeholder="例如：100",
            default_value="100",
        )
        form = ModalForm(
            title=f"新增条件: {unlock_title}",
            controls=[entity_input, required_input],
            on_close=lambda p, ut=unlock_title: self.show_op_achievement_edit_panel(p, ut),
            on_submit=lambda p, json_str, ut=unlock_title: self._do_op_achievement_create_condition(p, json_str, ut),
        )
        player.send_form(form)

    def _do_op_achievement_create_condition(self, player: Player, json_str: str, unlock_title: str):
        try:
            data = json.loads(json_str)
        except Exception:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_edit_panel(player, unlock_title)

        if not data or len(data) < 2:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_edit_panel(player, unlock_title)

        target_id = str(data[0] or "").strip()
        try:
            required_count_int = int(data[1])
        except Exception:
            required_count_int = 0

        ok = self.achievement_system.create_condition(
            unlock_title=unlock_title,
            condition_type=self.achievement_system.condition_type_kill_entity,
            target_id=target_id,
            required_count=required_count_int,
        )
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_SUCCESS"))
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
        self.show_op_achievement_edit_panel(player, unlock_title)

    def show_op_achievement_condition_panel(self, player: Player, unlock_title: str, condition_id: int):
        condition_row = self.achievement_system.get_condition(condition_id)
        if not condition_row:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_NOT_FOUND"))
            return self.show_op_achievement_edit_panel(player, unlock_title)

        target_id = str(condition_row.get("target_id") or "").strip()
        required_count = int(condition_row.get("required_count") or 0)
        condition_type = str(condition_row.get("condition_type") or "").strip()
        if condition_type == self.achievement_system.condition_type_kill_entity_sum:
            ids_joined = ", ".join(condition_row.get("target_ids") or [])
            condition_text = f"击杀总和 [{ids_joined}] >= {required_count}"
        elif target_id == "*":
            condition_text = f"累计击杀任意生物 >= {required_count}"
        else:
            condition_text = f"击杀 {target_id} >= {required_count}"

        panel = ActionForm(
            title=f"条件 #{condition_id}",
            content=condition_text,
            on_close=lambda p, ut=unlock_title: self.show_op_achievement_edit_panel(p, ut),
        )
        panel.add_button(
            "编辑条件",
            on_click=lambda p, ut=unlock_title, c_id=condition_id: self._show_op_achievement_edit_condition_modal(p, ut, c_id),
        )
        panel.add_button(
            self.language_manager.GetText("OP_ACHIEVEMENT_DELETE_BUTTON"),
            on_click=lambda p, ut=unlock_title, c_id=condition_id: self._do_op_achievement_delete_condition(p, ut, c_id),
        )
        panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p, ut=unlock_title: self.show_op_achievement_edit_panel(p, ut),
        )
        player.send_form(panel)

    def _show_op_achievement_edit_condition_modal(self, player: Player, unlock_title: str, condition_id: int):
        condition_row = self.achievement_system.get_condition(condition_id)
        if not condition_row:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_NOT_FOUND"))
            return self.show_op_achievement_edit_panel(player, unlock_title)

        condition_type = str(condition_row.get("condition_type") or "").strip()
        if condition_type == self.achievement_system.condition_type_kill_entity_sum:
            default_ids = ", ".join(condition_row.get("target_ids") or [])
            entity_input = TextInput(
                label="生物ID（英文逗号分隔，击杀数相加）",
                placeholder="minecraft:zombie, minecraft:skeleton",
                default_value=default_ids,
            )
        else:
            entity_input = TextInput(
                label="生物ID",
                placeholder="例如: minecraft:zombie 或 *",
                default_value=str(condition_row.get("target_id") or ""),
            )
        required_input = TextInput(
            label=self.language_manager.GetText("OP_ACHIEVEMENT_FIELD_REQUIRED"),
            placeholder="",
            default_value=str(int(condition_row.get("required_count") or 0)),
        )
        form = ModalForm(
            title=f"编辑条件 #{condition_id}",
            controls=[entity_input, required_input],
            on_close=lambda p, ut=unlock_title, c_id=condition_id: self.show_op_achievement_condition_panel(p, ut, c_id),
            on_submit=lambda p, json_str, ut=unlock_title, c_id=condition_id: self._do_op_achievement_save_condition(p, json_str, ut, c_id),
        )
        player.send_form(form)

    def _do_op_achievement_save_condition(self, player: Player, json_str: str, unlock_title: str, condition_id: int):
        condition_row = self.achievement_system.get_condition(condition_id)
        try:
            data = json.loads(json_str)
        except Exception:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_condition_panel(player, unlock_title, condition_id)

        if not data or len(data) < 2:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            return self.show_op_achievement_condition_panel(player, unlock_title, condition_id)

        try:
            required_count_int = int(data[1])
        except Exception:
            required_count_int = 0

        condition_type = str((condition_row or {}).get("condition_type") or "").strip()
        if condition_type == self.achievement_system.condition_type_kill_entity_sum:
            ids_raw = str(data[0] or "")
            target_ids_list = [x.strip() for x in ids_raw.split(",") if x.strip()]
            ok = self.achievement_system.update_condition(
                condition_id=condition_id,
                condition_type=self.achievement_system.condition_type_kill_entity_sum,
                target_id="",
                required_count=required_count_int,
                target_ids=target_ids_list,
            )
        else:
            target_id = str(data[0] or "").strip()
            ok = self.achievement_system.update_condition(
                condition_id=condition_id,
                condition_type=self.achievement_system.condition_type_kill_entity,
                target_id=target_id,
                required_count=required_count_int,
            )
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_SUCCESS"))
            self.show_op_achievement_condition_panel(player, unlock_title, condition_id)
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
            self.show_op_achievement_condition_panel(player, unlock_title, condition_id)

    def _do_op_achievement_delete_condition(self, player: Player, unlock_title: str, condition_id: int):
        ok = self.achievement_system.delete_condition(int(condition_id))
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_DELETE_SUCCESS"))
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_DELETE_FAIL"))
        self.show_op_achievement_edit_panel(player, unlock_title)

    def _do_op_achievement_toggle(self, player: Player, unlock_title: str, enabled: bool):
        ok = self.achievement_system.set_achievement_enabled(unlock_title, bool(enabled))
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_SUCCESS"))
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
        self.show_op_achievement_edit_panel(player, unlock_title)

    def _do_op_achievement_toggle_hidden(self, player: Player, unlock_title: str, if_hidden: bool):
        ok = self.achievement_system.set_achievement_if_hidden(unlock_title, bool(if_hidden))
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_SUCCESS"))
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_SAVE_FAIL"))
        self.show_op_achievement_edit_panel(player, unlock_title)

    def _do_op_achievement_delete(self, player: Player, unlock_title: str):
        ok = self.achievement_system.delete_achievement(unlock_title)
        if ok:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_DELETE_SUCCESS"))
        else:
            player.send_message(self.language_manager.GetText("OP_ACHIEVEMENT_DELETE_FAIL"))
        self.show_op_achievement_list_panel(player)

    def show_op_title_manage_panel(self, player: Player):
        """OP 头衔管理子菜单：头衔属性管理、创建新头衔、给全体添加、给单独玩家添加。"""
        panel = ActionForm(
            title=self.language_manager.GetText('OP_TITLE_MANAGE_TITLE'),
            content=self.language_manager.GetText('OP_TITLE_MANAGE_CONTENT'),
            on_close=self.show_op_main_panel
        )
        panel.add_button(self.language_manager.GetText('OP_TITLE_ATTR_MANAGE_BUTTON'),
                         on_click=self.show_op_title_attr_list_panel)
        panel.add_button(self.language_manager.GetText('OP_TITLE_CREATE_BUTTON'),
                         on_click=self.show_op_title_create_panel)
        panel.add_button(self.language_manager.GetText('OP_TITLE_GRANT_TO_ALL_BUTTON'),
                         on_click=self.show_op_grant_title_to_all_panel)
        panel.add_button(self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_BUTTON'),
                         on_click=self.show_op_grant_title_to_single_player_input)
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                         on_click=self.show_op_main_panel)
        player.send_form(panel)

    def show_op_title_attr_list_panel(self, player: Player):
        """OP 头衔属性管理：列出所有头衔，点击编辑。"""
        titles = self.title_system.get_all_title_names()
        if not titles:
            player.send_message(self.language_manager.GetText('OP_TITLE_NO_TITLES'))
            self.show_op_title_manage_panel(player)
            return
        panel = ActionForm(
            title=self.language_manager.GetText('OP_TITLE_ATTR_MANAGE_TITLE'),
            content=self.language_manager.GetText('OP_TITLE_ATTR_MANAGE_CONTENT'),
            on_close=self.show_op_title_manage_panel
        )
        for t in titles:
            defn = self.title_system.get_title_definition(t)
            rarity = (defn.get('rarity') or '普通') if defn else '普通'
            panel.add_button(f"{t} ({rarity})", on_click=lambda p, title=t: self.show_op_title_edit_panel(p, title))
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_title_manage_panel)
        player.send_form(panel)

    def show_op_title_edit_panel(self, player: Player, title_name: str):
        """OP 头衔管理：编辑属性 / 重命名。"""
        menu = ActionForm(
            title=self.language_manager.GetText('OP_TITLE_ATTR_EDIT_TITLE').format(title_name),
            on_close=self.show_op_title_attr_list_panel,
        )
        menu.add_button(
            self.language_manager.GetText('OP_TITLE_ATTR_EDIT_ATTR_BUTTON'),
            on_click=lambda p=player, t=title_name: self._show_op_title_attr_edit_modal(p, t)
        )
        menu.add_button(
            self.language_manager.GetText('OP_TITLE_RENAME_BUTTON'),
            on_click=lambda p=player, t=title_name: self.show_op_title_rename_panel(p, t)
        )
        menu.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_op_title_attr_list_panel
        )
        player.send_form(menu)

    def _show_op_title_attr_edit_modal(self, player: Player, title_name: str):
        """OP 编辑头衔属性：稀有度、介绍、解锁奖励。"""
        defn = self.title_system.get_title_definition(title_name)
        if not defn:
            defn = {"rarity": "普通", "description": "", "reward_money": 0.0, "reward_items": []}
        reward_items_str = "; ".join(
            f"{x.get('item_name', x.get('id', ''))} {x.get('count', 0)}"
            for x in (defn.get("reward_items") or [])
        )
        rarity_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_ATTR_RARITY_LABEL'),
            placeholder="普通/稀有/史诗/传奇/神话",
            default_value=defn.get("rarity", "普通"),
        )
        desc_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_ATTR_DESC_LABEL'),
            placeholder=self.language_manager.GetText('OP_TITLE_ATTR_DESC_PLACEHOLDER'),
            default_value=defn.get("description", ""),
        )
        money_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_ATTR_REWARD_MONEY_LABEL'),
            placeholder="0",
            default_value=str(defn.get("reward_money", 0)),
        )
        items_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_ATTR_REWARD_ITEMS_LABEL'),
            placeholder="minecraft:diamond 2; minecraft:emerald 1",
            default_value=reward_items_str,
        )
        form = ModalForm(
            title=self.language_manager.GetText('OP_TITLE_ATTR_EDIT_TITLE').format(title_name),
            controls=[rarity_input, desc_input, money_input, items_input],
            on_close=self.show_op_title_attr_list_panel,
            on_submit=lambda p, json_str: self._do_op_title_save_attr(p, json_str, title_name),
        )
        player.send_form(form)

    def show_op_title_rename_panel(self, player: Player, title_name: str):
        """OP 头衔重命名：将旧头衔名迁移为新头衔名。"""
        rename_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_RENAME_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('OP_TITLE_RENAME_INPUT_PLACEHOLDER'),
            default_value="",
        )
        form = ModalForm(
            title=self.language_manager.GetText('OP_TITLE_RENAME_PANEL_TITLE').format(title_name),
            controls=[rename_input],
            on_close=self.show_op_title_attr_list_panel,
            on_submit=lambda p, json_str: self._do_op_title_rename(p, json_str, title_name),
        )
        player.send_form(form)

    def _do_op_title_rename(self, player: Player, json_str: str, title_name: str):
        """执行头衔重命名：校验冲突 + 更新配置（管理员头衔）+ 同步数据库。"""
        try:
            data = json.loads(json_str)
            if not data or not str(data[0]).strip():
                player.send_message(self.language_manager.GetText('OP_TITLE_RENAME_FAIL_EMPTY'))
                return self.show_op_title_attr_list_panel(player)

            old_title = str(title_name).strip()
            new_title = str(data[0]).strip()

            if old_title == new_title:
                player.send_message(self.language_manager.GetText('OP_TITLE_RENAME_FAIL_SAME'))
                return self.show_op_title_attr_list_panel(player)

            # 新名字冲突校验
            if self.title_system.get_title_definition(new_title):
                player.send_message(self.language_manager.GetText('OP_TITLE_RENAME_FAIL_CONFLICT').format(new_title))
                return self.show_op_title_attr_list_panel(player)

            ok = self.title_system.rename_title(old_title, new_title)
            if not ok:
                player.send_message(self.language_manager.GetText('OP_TITLE_RENAME_FAIL'))
                return self.show_op_title_attr_list_panel(player)

            # 同步管理员头衔配置（OP_TITLE）
            current_op_title = self.setting_manager.GetSetting('OP_TITLE')
            if current_op_title and str(current_op_title).strip() == old_title:
                self.setting_manager.SetSetting('OP_TITLE', new_title)

            # 同步默认头衔配置（DEFAULT_TITLE），避免列表仍显示旧名字
            default_raw = self.setting_manager.GetSetting('DEFAULT_TITLE') or ""
            default_list = [t.strip() for t in str(default_raw).split(",") if t.strip()]
            if old_title in default_list:
                default_list = [new_title if t == old_title else t for t in default_list]
                self.setting_manager.SetSetting('DEFAULT_TITLE', ",".join(default_list))

            player.send_message(self.language_manager.GetText('OP_TITLE_RENAME_SUCCESS').format(old_title, new_title))
        except Exception as e:
            if self.logger:
                self.logger.error(f"[ARC Core]Rename title error: {e}")
            player.send_message(self.language_manager.GetText('OP_TITLE_RENAME_FAIL'))
        self.show_op_title_attr_list_panel(player)

    def _parse_reward_items(self, text: str) -> list:
        """解析 '物品ID 数量; 物品ID 数量' 为 [{"item_name": id, "count": n}, ...]"""
        result = []
        for part in (text or "").split(";"):
            part = part.strip()
            if not part:
                continue
            tokens = part.split()
            if len(tokens) >= 2:
                try:
                    result.append({"item_name": tokens[0], "count": int(tokens[1])})
                except ValueError:
                    pass
            elif len(tokens) == 1:
                result.append({"item_name": tokens[0], "count": 1})
        return result

    def _do_op_title_save_attr(self, player: Player, json_str: str, title_name: str):
        try:
            data = json.loads(json_str)
            if len(data) < 4:
                self.show_op_title_attr_list_panel(player)
                return
            rarity = str(data[0]).strip() if data[0] else "普通"
            if rarity not in ("普通", "稀有", "史诗", "传奇", "神话"):
                rarity = "普通"
            description = str(data[1]).strip() if data[1] else ""
            try:
                reward_money = float(data[2]) if data[2] is not None and str(data[2]).strip() else 0.0
            except (ValueError, TypeError):
                reward_money = 0.0
            reward_items = self._parse_reward_items(str(data[3]) if data[3] else "")
            self.title_system.set_title_definition(title_name, rarity, description, reward_money, reward_items)
            player.send_message(self.language_manager.GetText('OP_TITLE_ATTR_SAVED'))
        except Exception as e:
            if self.logger:
                self.logger.error(f"[ARC Core]Save title attr error: {e}")
        self.show_op_title_attr_list_panel(player)

    def show_op_title_create_panel(self, player: Player):
        """OP 创建新头衔：名称、稀有度、介绍、解锁奖励。"""
        name_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_CREATE_NAME_LABEL'),
            placeholder=self.language_manager.GetText('OP_TITLE_CREATE_NAME_PLACEHOLDER')
        )
        rarity_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_ATTR_RARITY_LABEL'),
            placeholder="普通/稀有/史诗/传奇/神话",
            default_value="普通"
        )
        desc_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_ATTR_DESC_LABEL'),
            placeholder=self.language_manager.GetText('OP_TITLE_ATTR_DESC_PLACEHOLDER')
        )
        money_input = TextInput(label=self.language_manager.GetText('OP_TITLE_ATTR_REWARD_MONEY_LABEL'), placeholder="0")
        items_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_ATTR_REWARD_ITEMS_LABEL'),
            placeholder="minecraft:diamond 2; minecraft:emerald 1"
        )
        form = ModalForm(
            title=self.language_manager.GetText('OP_TITLE_CREATE_TITLE'),
            controls=[name_input, rarity_input, desc_input, money_input, items_input],
            on_close=self.show_op_title_manage_panel,
            on_submit=lambda p, json_str: self._do_op_title_create(p, json_str)
        )
        player.send_form(form)

    def _do_op_title_create(self, player: Player, json_str: str):
        try:
            data = json.loads(json_str)
            if not data or not str(data[0]).strip():
                player.send_message(self.language_manager.GetText('OP_TITLE_CREATE_FAIL_EMPTY'))
                self.show_op_title_manage_panel(player)
                return
            title_name = str(data[0]).strip()
            rarity = str(data[1]).strip() if len(data) > 1 and data[1] else "普通"
            if rarity not in ("普通", "稀有", "史诗", "传奇", "神话"):
                rarity = "普通"
            description = str(data[2]).strip() if len(data) > 2 and data[2] else ""
            try:
                reward_money = float(data[3]) if len(data) > 3 and data[3] is not None and str(data[3]).strip() else 0.0
            except (ValueError, TypeError):
                reward_money = 0.0
            reward_items = self._parse_reward_items(str(data[4]) if len(data) > 4 and data[4] else "")
            self.title_system.set_title_definition(title_name, rarity, description, reward_money, reward_items)
            player.send_message(self.language_manager.GetText('OP_TITLE_CREATE_SUCCESS').format(title_name))
        except Exception as e:
            if self.logger:
                self.logger.error(f"[ARC Core]Create title error: {e}")
            player.send_message(self.language_manager.GetText('OP_TITLE_CREATE_FAIL'))
        self.show_op_title_manage_panel(player)

    def show_op_grant_title_to_all_panel(self, player: Player):
        """OP 给所有玩家添加头衔：选择已有头衔（按钮列表）。"""
        titles = self.title_system.get_all_title_names()
        if not titles:
            player.send_message(self.language_manager.GetText('OP_TITLE_NO_TITLES'))
            self.show_op_title_manage_panel(player)
            return
        panel = ActionForm(
            title=self.language_manager.GetText('OP_TITLE_GRANT_TO_ALL_TITLE'),
            content=self.language_manager.GetText('OP_TITLE_GRANT_TO_ALL_SELECT_HINT'),
            on_close=self.show_op_title_manage_panel
        )
        for t in titles:
            panel.add_button(t, on_click=lambda p, title=t: self._do_op_grant_title_to_all(p, title))
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_title_manage_panel)
        player.send_form(panel)

    def _do_op_grant_title_to_all(self, player: Player, title: str):
        """为当前数据库内所有玩家添加指定头衔（新人不会自动获得，需再次添加）。"""
        try:
            rows = self.database_manager.query_all("SELECT xuid FROM player_basic_info", ())
            count = 0
            for row in rows:
                xuid = row.get('xuid')
                if not xuid:
                    continue
                unlock_ok, was_new_unlock = self.title_system.unlock_title_by_xuid(xuid, title)
                if unlock_ok and was_new_unlock:
                    count += 1
            player.send_message(self.language_manager.GetText('OP_TITLE_GRANT_TO_ALL_SUCCESS').format(count, title))
        except Exception as e:
            if self.logger:
                self.logger.error(f"[ARC Core]Grant title to all error: {e}")
            player.send_message(self.language_manager.GetText('OP_TITLE_GRANT_TO_ALL_FAIL'))
        self.show_op_title_manage_panel(player)

    def show_op_grant_title_to_single_player_input(self, player: Player):
        """OP 给单独玩家添加头衔：先输入玩家名。"""
        player_input = TextInput(
            label=self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_PLAYER_LABEL'),
            placeholder=self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_PLAYER_PLACEHOLDER')
        )
        form = ModalForm(
            title=self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_TITLE'),
            controls=[player_input],
            on_close=self.show_op_title_manage_panel,
            on_submit=lambda p, json_str: self._op_grant_single_on_player_entered(p, json_str)
        )
        player.send_form(form)

    def _op_grant_single_on_player_entered(self, player: Player, json_str: str):
        try:
            data = json.loads(json_str)
            if not data or not str(data[0]).strip():
                player.send_message(self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_FAIL_EMPTY'))
                self.show_op_title_manage_panel(player)
                return
            target_name = str(data[0]).strip()
            xuid = self.get_player_xuid_by_name(target_name)
            if not xuid:
                player.send_message(self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_FAIL_NOT_FOUND').format(target_name))
                self.show_op_title_manage_panel(player)
                return
            self.show_op_grant_title_to_single_select_title(player, target_name, xuid)
        except Exception:
            self.show_op_title_manage_panel(player)

    def show_op_grant_title_to_single_select_title(self, player: Player, target_name: str, target_xuid: str):
        """选择要授予的头衔（按钮列表）。"""
        titles = self.title_system.get_all_title_names()
        if not titles:
            player.send_message(self.language_manager.GetText('OP_TITLE_NO_TITLES'))
            self.show_op_title_manage_panel(player)
            return
        panel = ActionForm(
            title=self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_TITLE'),
            content=self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_SELECT_HINT').format(target_name),
            on_close=self.show_op_title_manage_panel
        )
        for t in titles:
            panel.add_button(t, on_click=lambda p, title=t, name=target_name, xuid=target_xuid: self._do_op_grant_title_to_single(p, name, xuid, title))
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_title_manage_panel)
        player.send_form(panel)

    def _do_op_grant_title_to_single(self, player: Player, target_name: str, target_xuid: str, title: str):
        unlock_ok, was_new_unlock = self.title_system.unlock_title_by_xuid(target_xuid, title)
        if unlock_ok:
            target_online = None
            for p in (self.server.online_players or []):
                if str(p.xuid) == target_xuid:
                    target_online = p
                    break
            if target_online and was_new_unlock:
                self._grant_title_unlock_reward(target_online, title)
            player.send_message(self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_SUCCESS').format(target_name, title))
        else:
            player.send_message(self.language_manager.GetText('OP_TITLE_GRANT_TO_SINGLE_FAIL'))
        self.show_op_title_manage_panel(player)

    def show_op_land_at_pos(self, player: Player):
        """OP 直接获取脚下领地（含公共领地）并进入管理面板"""
        pos = self.get_player_position_vector(player)
        if not pos:
            self.report_arc_error(
                "OP1",
                f"show_op_land_at_pos get_player_position_vector None player={player.name!r}",
                player,
            )
            return
        x, y, z = pos
        dimension = player.location.dimension.name

        land_id = self.get_land_at_pos(dimension, x, z, y)
        if land_id is None:
            result_panel = ActionForm(
                title=self.language_manager.GetText('OP_LAND_AT_POS_TITLE'),
                content=self.language_manager.GetText('OP_LAND_AT_POS_NOT_FOUND').format(x, y, z),
                on_close=self.show_op_land_manage_panel
            )
            result_panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'),
                                    on_click=self.show_op_land_manage_panel)
            player.send_form(result_panel)
            return

        self.show_op_land_detail_panel(player, land_id, from_page=0)

    def show_op_rebuild_chunk_mapping_confirm(self, player: Player):
        """OP 确认重建领地区块映射"""
        confirm = ActionForm(
            title=self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_TITLE'),
            content=self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_CONFIRM_CONTENT'),
            on_close=self.show_op_land_manage_panel
        )
        confirm.add_button(
            self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_CONFIRM_BUTTON'),
            on_click=self._do_op_rebuild_chunk_mapping
        )
        confirm.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_op_land_manage_panel
        )
        player.send_form(confirm)

    def _do_op_rebuild_chunk_mapping(self, player: Player):
        """执行重建区块映射并反馈结果"""
        success, message = self.rebuild_chunk_land_mapping()
        result_panel = ActionForm(
            title=self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_TITLE'),
            content=message,
            on_close=self.show_op_land_manage_panel
        )
        result_panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_land_manage_panel)
        player.send_form(result_panel)
        if success:
            player.send_message(self.language_manager.GetText('OP_REBUILD_CHUNK_MAPPING_DONE'))

    def show_op_force_delete_land_confirm(self, player: Player, land_id: int, from_page: int):
        """OP 强制删除领地确认面板（私人领地全额退款给主人，公共领地不退款）"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "OP2",
                f"show_op_force_delete_land_confirm get_land_info empty land_id={land_id!r}",
                player,
            )
            self.show_op_land_detail_panel(player, land_id, from_page)
            return

        is_public = self.is_public_land(land_id)
        owner_xuid = land_info['owner_xuid']
        owner_name = self.get_player_name_by_xuid(owner_xuid) or owner_xuid if not is_public else ''
        refund = 0.0
        if not is_public:
            owner_paid = land_info.get('owner_paid_money')
            if owner_paid is not None:
                refund = round(float(owner_paid), 2)
            else:
                land_volume = ((land_info['max_x'] - land_info['min_x'] + 1) *
                               (land_info.get('max_y', 255) - land_info.get('min_y', 0) + 1) *
                               (land_info['max_z'] - land_info['min_z'] + 1))
                refund = round(float(land_volume) * self.land_price, 2)

        if is_public:
            content = self.language_manager.GetText('OP_FORCE_DELETE_LAND_CONFIRM_CONTENT_PUBLIC').format(
                land_id, land_info['land_name']
            )
        else:
            content = self.language_manager.GetText('OP_FORCE_DELETE_LAND_CONFIRM_CONTENT').format(
                land_id, land_info['land_name'], owner_name,
                self._format_money_display(refund)
            )

        confirm_panel = ActionForm(
            title=self.language_manager.GetText('OP_FORCE_DELETE_LAND_CONFIRM_TITLE').format(land_id),
            content=content,
            on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg)
        )
        confirm_panel.add_button(
            self.language_manager.GetText('OP_FORCE_DELETE_LAND_CONFIRM_BUTTON'),
            on_click=lambda p=player, l_id=land_id, o_name=owner_name, r=refund, pg=from_page: self._do_op_force_delete_land(p, l_id, o_name, r, pg)
        )
        confirm_panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg)
        )
        player.send_form(confirm_panel)

    def _do_op_force_delete_land(self, player: Player, land_id: int, owner_name: str, refund: float, from_page: int):
        """OP 执行强制删除领地；私人领地全额退款给主人，公共领地不退款"""
        if self.delete_land(land_id):
            if refund > 0 and owner_name:
                self.increase_player_money_by_name(owner_name, refund, notify=True)
            if refund > 0:
                player.send_message(self.language_manager.GetText('OP_FORCE_DELETE_LAND_SUCCESS').format(
                    land_id, owner_name, self._format_money_display(refund)
                ))
            else:
                player.send_message(self.language_manager.GetText('OP_FORCE_DELETE_LAND_SUCCESS_PUBLIC').format(land_id))
            self.show_op_all_lands_panel(player, from_page)
        else:
            player.send_message(self.language_manager.GetText('OP_FORCE_DELETE_LAND_FAILED').format(land_id))
            self.show_op_land_detail_panel(player, land_id, from_page)

    def op_reload_config(self, player: Player):
        """OP 重载配置文件：设置、广播、迎新指令/文案、语言文件"""
        try:
            self.setting_manager.Reload()
            self._reapply_cached_settings()
            self._load_broadcast_messages()
            self.language_manager.ReloadCurrentLanguage()
            self.entity_display_name_manager.reload()
            self.kill_reward_config.reload()
            player.send_message(self.language_manager.GetText('OP_RELOAD_CONFIG_SUCCESS'))
            self.show_op_main_panel(player)
        except Exception as e:
            self.logger.error(f"{ColorFormat.RED}[ARC Core]Reload config error: {str(e)}")
            player.send_message(self.language_manager.GetText('OP_RELOAD_CONFIG_FAILED'))
            self.show_op_main_panel(player)

    def _reapply_cached_settings(self):
        """重载配置后重新应用从 core_setting 读取的缓存项"""
        try:
            self.broadcast_interval = self.setting_manager.GetSetting('BROADCAST_INTERVAL')
            try:
                self.broadcast_interval = int(self.broadcast_interval)
            except (ValueError, TypeError):
                self.broadcast_interval = 300
            self.spawn_protect_range = self.setting_manager.GetSetting('SPAWN_PROTECT_RANGE')
            if self.spawn_protect_range is None:
                self.spawn_protect_range = 8
            else:
                try:
                    self.spawn_protect_range = int(self.spawn_protect_range)
                except ValueError:
                    self.spawn_protect_range = 8
            self.if_protect_spawn = self.setting_manager.GetSetting('IF_PROTECT_SPAWN')
            if self.if_protect_spawn is None:
                self.if_protect_spawn = False
            else:
                try:
                    self.if_protect_spawn = str(self.if_protect_spawn).lower() in ['true', '1', 'yes']
                except (ValueError, AttributeError):
                    self.if_protect_spawn = False
            land_price_raw = self.setting_manager.GetSetting('LAND_PRICE')
            try:
                self.land_price = int(land_price_raw)
            except (ValueError, TypeError):
                self.land_price = 1000
            try:
                self.land_sell_refund_coefficient = float(self.setting_manager.GetSetting('LAND_SELL_REFUND_COEFFICIENT'))
            except (ValueError, TypeError):
                self.land_sell_refund_coefficient = 0.9
            try:
                self.land_min_size = int(self.setting_manager.GetSetting('LAND_MIN_SIZE'))
            except (ValueError, TypeError):
                self.land_min_size = 5
            try:
                self.land_min_distance = int(self.setting_manager.GetSetting('MIN_LAND_DISTANCE'))
            except (ValueError, TypeError):
                self.land_min_distance = 0
            self.teleport_system.reload_config()
            self.land_system.reload_config()
            self._refresh_disabled_blocks()
            self._refresh_land_only_place_blocks()
            self.hide_op_in_money_ranking = self.setting_manager.GetSetting('HIDE_OP_IN_MONEY_RANKING')
            if self.hide_op_in_money_ranking is None:
                self.hide_op_in_money_ranking = True
            else:
                try:
                    self.hide_op_in_money_ranking = str(self.hide_op_in_money_ranking).lower() in ['true', '1', 'yes']
                except (ValueError, AttributeError):
                    self.hide_op_in_money_ranking = True
            self.force_login = self.setting_manager.GetSetting('FORCE_LOGIN')
            if self.force_login is None:
                self.force_login = False
            else:
                try:
                    self.force_login = str(self.force_login).lower() in ['true', '1', 'yes']
                except (ValueError, AttributeError):
                    self.force_login = False
            self.small_horn_price_per_hour = self.setting_manager.GetSetting('SMALL_HORN_PRICE_PER_HOUR')
            try:
                self.small_horn_price_per_hour = int(self.small_horn_price_per_hour)
                if self.small_horn_price_per_hour < 0:
                    self.small_horn_price_per_hour = 60
            except (ValueError, TypeError):
                self.small_horn_price_per_hour = 60
            self._init_cleaner_system()
        except Exception as e:
            self.logger.error(f"[ARC Core]Reapply cached settings error: {str(e)}")

    def show_invite_reward_config_panel(self, player: Player):
        """OP 配置邀请奖励"""
        reward_config = self.get_invite_reward_config()

        item_name_input = TextInput(
            label=self.language_manager.GetText('INVITE_REWARD_ITEM_NAME_LABEL'),
            placeholder=self.language_manager.GetText('INVITE_REWARD_ITEM_NAME_PLACEHOLDER'),
            default_value=str(reward_config.get('item_name', ''))
        )
        item_count_input = TextInput(
            label=self.language_manager.GetText('INVITE_REWARD_ITEM_COUNT_LABEL'),
            placeholder=self.language_manager.GetText('INVITE_REWARD_ITEM_COUNT_PLACEHOLDER'),
            default_value=str(reward_config.get('item_count', 0))
        )
        money_input = TextInput(
            label=self.language_manager.GetText('INVITE_REWARD_MONEY_LABEL'),
            placeholder=self.language_manager.GetText('INVITE_REWARD_MONEY_PLACEHOLDER'),
            default_value=str(reward_config.get('money', 0))
        )
        free_blocks_input = TextInput(
            label=self.language_manager.GetText('INVITE_REWARD_FREE_BLOCKS_LABEL'),
            placeholder=self.language_manager.GetText('INVITE_REWARD_FREE_BLOCKS_PLACEHOLDER'),
            default_value=str(reward_config.get('free_blocks', 0))
        )

        def try_save_reward_config(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception as parse_exc:
                self.report_arc_error(
                    "OP_INV1",
                    "show_invite_reward_config_panel json.loads failed",
                    p,
                    exception=parse_exc,
                )
                result_panel = ActionForm(
                    title=self.language_manager.GetText('INVITE_REWARD_CONFIG_TITLE'),
                    content=self.language_manager.GetText('FILL_INVITER_FAIL_SYSTEM_ERROR'),
                    on_close=self.show_op_main_panel
                )
                p.send_form(result_panel)
                return

            item_name_value = str(data[0]).strip() if len(data) > 0 else ''
            item_count_raw = str(data[1]).strip() if len(data) > 1 else '0'
            money_raw = str(data[2]).strip() if len(data) > 2 else '0'
            free_blocks_raw = str(data[3]).strip() if len(data) > 3 else '0'

            def parse_int_non_negative(raw_value: str) -> int:
                try:
                    value = int(raw_value)
                    if value < 0:
                        value = 0
                    return value
                except (ValueError, TypeError):
                    return 0

            item_count_value = parse_int_non_negative(item_count_raw)
            money_value = parse_int_non_negative(money_raw)
            free_blocks_value = parse_int_non_negative(free_blocks_raw)

            self.setting_manager.SetSetting('INVITE_REWARD_ITEM_NAME', item_name_value)
            self.setting_manager.SetSetting('INVITE_REWARD_ITEM_COUNT', item_count_value)
            self.setting_manager.SetSetting('INVITE_REWARD_MONEY', money_value)
            self.setting_manager.SetSetting('INVITE_REWARD_FREE_LAND_BLOCKS', free_blocks_value)

            result_panel = ActionForm(
                title=self.language_manager.GetText('INVITE_REWARD_CONFIG_TITLE'),
                content=self.language_manager.GetText('INVITE_REWARD_CONFIG_SAVED'),
                on_close=self.show_op_main_panel
            )
            p.send_form(result_panel)

        config_panel = ModalForm(
            title=self.language_manager.GetText('INVITE_REWARD_CONFIG_TITLE'),
            controls=[item_name_input, item_count_input, money_input, free_blocks_input],
            on_close=self.show_op_main_panel,
            on_submit=try_save_reward_config
        )
        player.send_form(config_panel)

    def switch_player_game_mode(self, player: Player):
        if player.game_mode == GameMode.CREATIVE:
            self.server.dispatch_command(self.server.command_sender, f'gamemode 0 {player.name}')
        else:
            self.server.dispatch_command(self.server.command_sender, f'gamemode 1 {player.name}')

    def clear_drop_item(self, player: Player):
        self.server.scheduler.run_task(self, self.delay_drop_item, delay=150)
        self.server.broadcast_message(self.language_manager.GetText('READY_TO_CLEAR_DROP_ITEM_BROADCAST'))

    def delay_drop_item(self):
        self.execute_cleaner()

    def _send_op_debug_message(self, player: Optional[Player], event_type: str, target_desc: str, dimension: str, x: float, y: float, z: float):
        """若该玩家开启了 OP 调试模式，则发送一条调试聊天消息"""
        if player is None or player.name not in self.op_debug_mode:
            return
        try:
            msg = self.language_manager.GetText('OP_DEBUG_MSG').format(
                event_type, target_desc, dimension,
                int(x) if x == math.floor(x) else x,
                int(y) if y == math.floor(y) else y,
                int(z) if z == math.floor(z) else z
            )
            player.send_message(msg)
        except Exception:
            pass

    def toggle_op_debug_mode(self, player: Player):
        """切换 OP 调试模式：开启后会在方块破坏/放置、方块交互、生物攻击、生物交互时向该玩家发送调试消息"""
        if player.name in self.op_debug_mode:
            self.op_debug_mode.discard(player.name)
            player.send_message(self.language_manager.GetText('OP_DEBUG_MODE_TOGGLED_OFF'))
        else:
            self.op_debug_mode.add(player.name)
            player.send_message(self.language_manager.GetText('OP_DEBUG_MODE_TOGGLED_ON'))
        self.show_op_tools_panel(player)

    def record_coordinate_1(self, player: Player):
        if not player.name in self.op_coordinate1_dict:
            self.op_coordinate1_dict[player.name] = None
        self.op_coordinate1_dict[player.name] = self.get_player_position_vector(player)

    def record_coordinate_2(self, player: Player):
        if not player.name in self.op_coordinate2_dict:
            self.op_coordinate2_dict[player.name] = None
        self.op_coordinate2_dict[player.name] = self.get_player_position_vector(player)
        self.show_op_tools_panel(player)

    def get_op_record_coor1(self, player: Player):
        if not player.name in self.op_coordinate1_dict or self.op_coordinate1_dict[player.name] is None:
            return self.get_player_position_vector(player)
        else:
            return self.op_coordinate1_dict[player.name]

    def get_op_record_coor2(self, player: Player):
        if not player.name in self.op_coordinate2_dict or self.op_coordinate2_dict[player.name] is None:
            return self.get_player_position_vector(player)
        else:
            return self.op_coordinate2_dict[player.name]

    def run_command_as_self(self, player: Player):
        command_input = TextInput(
            label=self.language_manager.GetText('RUN_COMMAND_PANEL_COMMAND_INPUT_LABEL'),
            placeholder=self.language_manager.GetText('RUN_COMMAND_PANEL_COMMAND_INPUT_PLACEHOLDER').format(player.name),
            default_value=''
        )

        def try_execute_command(player: Player, json_str: str):
            data = json.loads(json_str)
            command_str = (data[0].strip() if len(data) and data[0] is not None else '')
            if not command_str:
                command_str = self.op_last_command_dict.get(player.name, '')
            if not command_str:
                player.send_message(self.language_manager.GetText('RUN_COMMAND_PANEL_NO_LAST_COMMAND'))
                return
            self.op_last_command_dict[player.name] = command_str
            if '@p1' in command_str:
                command_str = command_str.replace('@p1', ' '.join([str(_) for _ in self.get_op_record_coor1(player)]))
            if '@p2' in command_str:
                command_str = command_str.replace('@p2', ' '.join([str(_) for _ in self.get_op_record_coor2(player)]))
            player.perform_command(command_str)

        command_input_form = ModalForm(
            title=self.language_manager.GetText('RUN_COMMAND_PANEL_TITLE'),
            controls=[command_input],
            on_close=self.show_op_tools_panel,
            on_submit=try_execute_command
        )
        player.send_form(command_input_form)
    
    def show_economy_manage_panel(self, player: Player):
        """OP 经济管理：在线玩家存款调整 + 经济相关配置。"""
        panel = ActionForm(
            title=self.language_manager.GetText('OP_ECONOMY_MANAGE_TITLE'),
            content=self.language_manager.GetText('OP_ECONOMY_MANAGE_CONTENT'),
            on_close=self.show_op_main_panel,
        )
        panel.add_button(
            self.language_manager.GetText('OP_ECONOMY_ADJUST_MONEY_BUTTON'),
            on_click=self.show_money_manage_menu,
        )
        panel.add_button(
            self.language_manager.GetText('OP_ECONOMY_SETTINGS_BUTTON'),
            on_click=self.show_economy_settings_panel,
        )
        panel.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_op_main_panel)
        player.send_form(panel)

    def show_economy_settings_panel(self, player: Player):
        """OP 配置 PLAYER_INIT_MONEY_NUM、HIDE_OP_IN_MONEY_RANKING、RICHEST_TITLE_NAME。"""
        def _raw(key: str, fallback: str) -> str:
            v = self.setting_manager.GetSetting(key)
            if v is None or str(v).strip() == "":
                return fallback
            return str(v).strip()

        in_init_money = TextInput(
            label=self.language_manager.GetText('OP_ECONOMY_SET_INIT_MONEY_LABEL'),
            placeholder="2000",
            default_value=_raw("PLAYER_INIT_MONEY_NUM", "0"),
        )
        in_hide_op_rank = TextInput(
            label=self.language_manager.GetText('OP_ECONOMY_SET_HIDE_OP_RANK_LABEL'),
            placeholder="true / false",
            default_value="true" if self.hide_op_in_money_ranking else "false",
        )
        richest_default = self.setting_manager.GetSetting("RICHEST_TITLE_NAME")
        if richest_default is None or not str(richest_default).strip():
            richest_default = "首富"
        else:
            richest_default = str(richest_default).strip()
        in_richest_title = TextInput(
            label=self.language_manager.GetText('OP_ECONOMY_SET_RICHEST_TITLE_LABEL'),
            placeholder="首富",
            default_value=richest_default,
        )

        def try_save(p: Player, json_str: str):
            try:
                data = json.loads(json_str)
            except Exception:
                p.send_message(self.language_manager.GetText('OP_ECONOMY_SETTINGS_SAVE_FAIL'))
                return self.show_economy_manage_panel(p)
            if not data or len(data) < 3:
                p.send_message(self.language_manager.GetText('OP_ECONOMY_SETTINGS_SAVE_FAIL'))
                return self.show_economy_manage_panel(p)

            try:
                init_money = self._round_money(float(str(data[0]).strip()))
            except (ValueError, TypeError):
                p.send_message(self.language_manager.GetText('OP_ECONOMY_SETTINGS_SAVE_FAIL'))
                return self.show_economy_manage_panel(p)
            if init_money < 0:
                init_money = 0.0

            hide_raw = str(data[1]).strip().lower()
            hide_op = hide_raw in ("true", "1", "yes", "on")

            new_richest = str(data[2]).strip() if data[2] is not None else ""
            if not new_richest:
                new_richest = "首富"

            raw_old_r = self.setting_manager.GetSetting("RICHEST_TITLE_NAME")
            old_richest = (str(raw_old_r).strip() if raw_old_r else "") or "首富"

            if old_richest != new_richest and self.current_richest_xuid:
                try:
                    self.title_system.revoke_title_by_xuid(self.current_richest_xuid, old_richest)
                    old_name = self.get_player_name_by_xuid(self.current_richest_xuid, return_with_title=False)
                    if old_name:
                        pl = self.server.get_player(old_name)
                        if pl is not None:
                            self._update_player_name_tag(pl)
                except Exception:
                    pass

            self.setting_manager.SetSetting("PLAYER_INIT_MONEY_NUM", init_money)
            self.setting_manager.SetSetting(
                "HIDE_OP_IN_MONEY_RANKING", "true" if hide_op else "false"
            )
            self.setting_manager.SetSetting("RICHEST_TITLE_NAME", new_richest)

            self.hide_op_in_money_ranking = hide_op
            self._ensure_richest_title_definition()
            try:
                self._update_richest_title_if_needed()
            except Exception:
                pass

            # 仅修改首富头衔名称时财富榜第一人 xuid 不变，_update 会早退；此处补发新名称下的头衔
            if old_richest != new_richest and self.current_richest_xuid:
                try:
                    grant_title = self._get_richest_title_name()
                    rx = self.current_richest_xuid
                    pname = self.get_player_name_by_xuid(rx, return_with_title=False)
                    online_player = self.server.get_player(pname) if pname else None
                    if online_player is not None:
                        self.api_unlock_title(online_player, grant_title)
                        self._update_player_name_tag(online_player)
                    else:
                        _, _ = self.title_system.unlock_title_by_xuid(rx, grant_title)
                except Exception:
                    pass

            result = ActionForm(
                title=self.language_manager.GetText('OP_ECONOMY_SETTINGS_TITLE'),
                content=self.language_manager.GetText('OP_ECONOMY_SETTINGS_SAVED'),
                on_close=self.show_economy_manage_panel,
            )
            result.add_button(self.language_manager.GetText('RETURN_BUTTON_TEXT'), on_click=self.show_economy_manage_panel)
            p.send_form(result)

        form = ModalForm(
            title=self.language_manager.GetText('OP_ECONOMY_SETTINGS_TITLE'),
            controls=[in_init_money, in_hide_op_rank, in_richest_title],
            on_close=self.show_economy_manage_panel,
            on_submit=try_save,
        )
        player.send_form(form)

    # Money Management UI（经济管理子菜单：调整在线玩家存款）
    def show_money_manage_menu(self, player: Player):
        """选择增加或减少在线玩家存款"""
        money_menu = ActionForm(
            title=self.language_manager.GetText('MONEY_MANAGE_MENU_TITLE'),
            content=self.language_manager.GetText('MONEY_MANAGE_MENU_CONTENT'),
            on_close=self.show_economy_manage_panel
        )
        money_menu.add_button(
            self.language_manager.GetText('MONEY_MANAGE_ADD_BUTTON'),
            on_click=lambda p=player, op_type='add': self.show_money_manage_select_player(p, op_type)
        )
        money_menu.add_button(
            self.language_manager.GetText('MONEY_MANAGE_REMOVE_BUTTON'),
            on_click=lambda p=player, op_type='remove': self.show_money_manage_select_player(p, op_type)
        )
        player.send_form(money_menu)
    
    def show_money_manage_select_player(self, player: Player, operation_type: str):
        """显示选择玩家面板"""
        online_players = [p for p in self.server.online_players]
        if not online_players:
            no_players_panel = ActionForm(
                title=self.language_manager.GetText('MONEY_MANAGE_SELECT_PLAYER_TITLE'),
                content=self.language_manager.GetText('NO_OTHER_PLAYERS_ONLINE'),
                on_close=self.show_money_manage_menu
            )
            player.send_form(no_players_panel)
            return
        
        select_player_menu = ActionForm(
            title=self.language_manager.GetText('MONEY_MANAGE_SELECT_PLAYER_TITLE'),
            content=self.language_manager.GetText('MONEY_MANAGE_SELECT_PLAYER_CONTENT'),
            on_close=self.show_money_manage_menu
        )
        
        for target_player in online_players:
            # 显示玩家名称和当前余额
            player_info = f"{target_player.name} (余额: {self._format_money_display(self.get_player_money(target_player))})"
            select_player_menu.add_button(
                player_info,
                on_click=lambda p=player, t=target_player, op=operation_type: self.show_money_manage_input_amount(p, t, op)
            )
        
        player.send_form(select_player_menu)
    
    def show_money_manage_input_amount(self, player: Player, target_player: Player, operation_type: str):
        """显示输入金额面板"""
        amount_input = TextInput(
            label=self.language_manager.GetText('MONEY_MANAGE_INPUT_AMOUNT_LABEL'),
            placeholder=self.language_manager.GetText('MONEY_MANAGE_INPUT_AMOUNT_PLACEHOLDER')
        )
        
        def try_change_money(player: Player, json_str: str):
            data = json.loads(json_str)
            if not len(data) or not data[0]:
                player.send_message(self.language_manager.GetText('MONEY_MANAGE_AMOUNT_EMPTY'))
                return
            
            try:
                amount = self._round_money(float(data[0]))
                if amount <= 0:
                    raise ValueError
            except (ValueError, TypeError):
                player.send_message(self.language_manager.GetText('MONEY_MANAGE_INVALID_AMOUNT'))
                return
            
            # 执行金钱操作
            if operation_type == 'add':
                if self.increase_player_money(target_player, amount):
                    player.send_message(self.language_manager.GetText('MONEY_SYSTEM_ADD_MONEY_SUCCESS').format(
                        target_player.name,
                        self._format_money_display(amount),
                        self._format_money_display(self.get_player_money(target_player))
                    ))
                else:
                    player.send_message(self.language_manager.GetText('MONEY_SYSTEM_ADD_MONEY_FAILED'))
            else:  # remove
                if self.decrease_player_money(target_player, amount):
                    player.send_message(self.language_manager.GetText('MONEY_SYSTEM_REMOVE_MONEY_SUCCESS').format(
                        target_player.name,
                        self._format_money_display(amount),
                        self._format_money_display(self.get_player_money(target_player))
                    ))
                else:
                    player.send_message(self.language_manager.GetText('MONEY_SYSTEM_REMOVE_MONEY_FAILED'))
            
            self.show_economy_manage_panel(player)
        
        amount_input_form = ModalForm(
            title=self.language_manager.GetText('MONEY_MANAGE_INPUT_AMOUNT_TITLE'),
            controls=[amount_input],
            on_close=lambda p=player: self.show_money_manage_select_player(p, operation_type),
            on_submit=try_change_money
        )
        player.send_form(amount_input_form)
    
    # OP Manage All Lands
    OP_ALL_LANDS_PAGE_SIZE = 15
    
    def show_op_all_lands_panel(self, player: Player, page: int = 0):
        """显示全服领地列表（分页）"""
        all_lands = self.get_all_lands()
        if not all_lands:
            empty_panel = ActionForm(
                title=self.language_manager.GetText('OP_ALL_LANDS_MENU_TITLE'),
                content=self.language_manager.GetText('OP_ALL_LANDS_EMPTY'),
                on_close=self.show_op_land_manage_panel
            )
            player.send_form(empty_panel)
            return
        
        land_ids = sorted(all_lands.keys())
        total_pages = max(1, (len(land_ids) + self.OP_ALL_LANDS_PAGE_SIZE - 1) // self.OP_ALL_LANDS_PAGE_SIZE)
        page = max(0, min(page, total_pages - 1))
        start = page * self.OP_ALL_LANDS_PAGE_SIZE
        end = min(start + self.OP_ALL_LANDS_PAGE_SIZE, len(land_ids))
        page_land_ids = land_ids[start:end]
        
        menu = ActionForm(
            title=self.language_manager.GetText('OP_ALL_LANDS_MENU_TITLE'),
            content=self.language_manager.GetText('OP_ALL_LANDS_MENU_CONTENT').format(len(land_ids), page + 1),
            on_close=self.show_op_land_manage_panel
        )
        
        for land_id in page_land_ids:
            land_info = all_lands[land_id]
            owner_name = self.get_land_display_owner_name(land_id)
            btn_text = self.language_manager.GetText('OP_ALL_LANDS_BUTTON_TEXT').format(
                land_id,
                land_info['land_name'],
                owner_name,
                land_info['dimension']
            )
            menu.add_button(
                btn_text,
                on_click=lambda p=player, l_id=land_id, pg=page: self.show_op_land_detail_panel(p, l_id, pg)
            )
        
        if page > 0:
            menu.add_button(
                self.language_manager.GetText('OP_ALL_LANDS_PREV_PAGE'),
                on_click=lambda p=player, pg=page: self.show_op_all_lands_panel(p, pg - 1)
            )
        if page < total_pages - 1:
            menu.add_button(
                self.language_manager.GetText('OP_ALL_LANDS_NEXT_PAGE'),
                on_click=lambda p=player, pg=page: self.show_op_all_lands_panel(p, pg + 1)
            )
        menu.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=self.show_op_land_manage_panel
        )
        player.send_form(menu)
    
    def show_op_land_detail_panel(self, player: Player, land_id: int, from_page: int = 0):
        """OP 查看单个领地详情（可传送前往）"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "OP3",
                f"show_op_land_detail_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            self.show_op_all_lands_panel(player, from_page)
            return
        
        if len(land_info['shared_users']):
            shared_user_names = [self.get_player_name_by_xuid(uid) or uid for uid in land_info['shared_users']]
            shared_user_name_str = '\n'.join(shared_user_names)
        else:
            shared_user_name_str = self.language_manager.GetText('LAND_DETAIL_NO_SHARED_USER_TEXT')
        
        owner_name = self.get_land_display_owner_name(land_id)
        
        content = self.language_manager.GetText('LAND_DETAIL_PANEL_CONTENT').format(
            land_id,
            land_info['land_name'],
            land_info['dimension'],
            (int(land_info['min_x']), int(land_info['min_z'])),
            (int(land_info['max_x']), int(land_info['max_z'])),
            (int(land_info['tp_x']), int(land_info['tp_y']), int(land_info['tp_z'])),
            shared_user_name_str
        )
        content = f"所有者: {owner_name}\n\n" + content
        
        detail_panel = ActionForm(
            title=self.language_manager.GetText('OP_LAND_DETAIL_TITLE').format(land_id),
            content=content,
            on_close=lambda p=player, pg=from_page: self.show_op_all_lands_panel(p, pg)
        )
        # 传送前往
        detail_panel.add_button(
            self.language_manager.GetText('OP_LAND_TELEPORT_BUTTON'),
            on_click=lambda p=player, l_id=land_id: self.op_teleport_to_land(p, l_id)
        )
        # 强制修改领地名称（所有领地均可用）
        detail_panel.add_button(
            self.language_manager.GetText('OP_LAND_RENAME_BUTTON'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_rename_land_panel(p, l_id, pg)
        )
        # 管理授权（添加/移除授权玩家）
        detail_panel.add_button(
            self.language_manager.GetText('OP_LAND_MANAGE_AUTH_BUTTON'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_auth_manage_panel(p, l_id, pg)
        )
        if self.is_public_land(land_id):
            detail_panel.add_button(
                self.language_manager.GetText('OP_PUBLIC_LAND_SETTINGS_BUTTON'),
                on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_settings_panel(p, l_id, pg)
            )
        else:
            detail_panel.add_button(
                self.language_manager.GetText('OP_SET_LAND_PUBLIC_BUTTON'),
                on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_confirm_set_land_public(p, l_id, pg)
            )
        detail_panel.add_button(
            self.language_manager.GetText('OP_FORCE_DELETE_LAND_BUTTON'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_force_delete_land_confirm(p, l_id, pg)
        )
        detail_panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, pg=from_page: self.show_op_all_lands_panel(p, pg)
        )
        player.send_form(detail_panel)
    
    def op_teleport_to_land(self, player: Player, land_id: int):
        """OP 传送到领地（不扣费）"""
        tp_target_pos = self.get_land_teleport_point(land_id)
        if tp_target_pos is None:
            self.report_arc_error(
                "OP4",
                f"op_teleport_to_land get_land_teleport_point None land_id={land_id!r}",
                player,
            )
            return
        self.server.scheduler.run_task(
            self,
            lambda: self.delay_teleport_to_land(player, land_id, tp_target_pos),
            delay=45
        )
        player.send_message(self.language_manager.GetText('READY_TELEPORT_TO_LAND').format(land_id))
    
    def show_op_confirm_set_land_public(self, player: Player, land_id: int, from_page: int):
        """OP 确认设为公共领地面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "OP5",
                f"show_op_confirm_set_land_public get_land_info empty land_id={land_id!r}",
                player,
            )
            self.show_op_all_lands_panel(player, from_page)
            return
        confirm_panel = ActionForm(
            title=self.language_manager.GetText('OP_CONFIRM_SET_PUBLIC_TITLE'),
            content=self.language_manager.GetText('OP_CONFIRM_SET_PUBLIC_CONTENT').format(land_id),
            on_close=lambda p=player, pg=from_page: self.show_op_land_detail_panel(p, land_id, pg)
        )
        confirm_panel.add_button(
            self.language_manager.GetText('OP_CONFIRM_SET_PUBLIC_BUTTON'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.op_do_set_land_public(p, l_id, pg)
        )
        confirm_panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg)
        )
        player.send_form(confirm_panel)
    
    def op_do_set_land_public(self, player: Player, land_id: int, from_page: int):
        """OP 执行设为公共领地"""
        if self.set_land_as_public(land_id):
            player.send_message(self.language_manager.GetText('OP_SET_LAND_PUBLIC_SUCCESS').format(land_id))
            self.show_op_land_detail_panel(player, land_id, from_page)
        else:
            player.send_message(self.language_manager.GetText('OP_SET_LAND_PUBLIC_FAILED'))
            self.show_op_land_detail_panel(player, land_id, from_page)
    
    def show_op_rename_land_panel(self, player: Player, land_id: int, from_page: int):
        """OP 修改领地名称面板（用于公共领地等）"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "OP6",
                f"show_op_rename_land_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            self.show_op_all_lands_panel(player, from_page)
            return
        current_name = land_info['land_name']
        new_name_input = TextInput(
            label=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_INPUT_LABEL').format(land_id),
            placeholder=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_INPUT_PLACEHOLDER').format(player.name),
            default_value=current_name
        )
        
        def try_change_name(player: Player, json_str: str):
            data = json.loads(json_str)
            if not data or not data[0]:
                player.send_message(self.language_manager.GetText('CREATE_HOME_EMPTY_NAME_ERROR'))
                return
            success, msg = self.rename_land(land_id, data[0])
            player.send_message(msg)
            self.show_op_land_detail_panel(player, land_id, from_page)
        
        rename_panel = ModalForm(
            title=self.language_manager.GetText('RENAME_OWN_LAND_PANEL_TITLE'),
            controls=[new_name_input],
            on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg),
            on_submit=try_change_name
        )
        player.send_form(rename_panel)

    def show_op_land_auth_manage_panel(self, player: Player, land_id: int, from_page: int):
        """OP 领地授权管理面板（添加/移除授权玩家）"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "OP7",
                f"show_op_land_auth_manage_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            self.show_op_all_lands_panel(player, from_page)
            return
        auth_panel = ActionForm(
            title=self.language_manager.GetText('OP_LAND_MANAGE_AUTH_BUTTON'),
            content=self.language_manager.GetText('LAND_AUTH_MANAGE_TITLE'),
            on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg)
        )
        auth_panel.add_button(
            self.language_manager.GetText('LAND_AUTH_ADD_BUTTON'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_add_land_auth_panel(p, l_id, pg)
        )
        if land_info['shared_users']:
            auth_panel.add_button(
                self.language_manager.GetText('LAND_AUTH_REMOVE_BUTTON'),
                on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_remove_land_auth_panel(p, l_id, pg)
            )
        auth_panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg)
        )
        player.send_form(auth_panel)

    def show_op_add_land_auth_panel(self, player: Player, land_id: int, from_page: int):
        """OP 添加领地授权：选择在线玩家"""
        online_players = [p for p in self.server.online_players]
        if not online_players:
            no_players_panel = ActionForm(
                title=self.language_manager.GetText('LAND_AUTH_ADD_PANEL_TITLE'),
                content=self.language_manager.GetText('NO_OTHER_PLAYERS_ONLINE'),
                on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_auth_manage_panel(p, l_id, pg)
            )
            player.send_form(no_players_panel)
            return
        add_panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_ADD_PANEL_TITLE'),
            content=self.language_manager.GetText('LAND_AUTH_SELECT_PLAYER_CONTENT'),
            on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_auth_manage_panel(p, l_id, pg)
        )
        for target_player in online_players:
            add_panel.add_button(
                self.language_manager.GetText('LAND_AUTH_ADD_TARGET_BUTTON').format(target_player.name),
                on_click=lambda p=player, l_id=land_id, t=target_player, pg=from_page: self.op_add_land_auth(p, l_id, t, pg)
            )
        player.send_form(add_panel)

    def show_op_remove_land_auth_panel(self, player: Player, land_id: int, from_page: int):
        """OP 移除领地授权：选择要移除的授权玩家"""
        land_info = self.get_land_info(land_id)
        if not land_info or not land_info['shared_users']:
            no_auth_panel = ActionForm(
                title=self.language_manager.GetText('LAND_AUTH_REMOVE_PANEL_TITLE'),
                content=self.language_manager.GetText('LAND_AUTH_NO_SHARED_USERS'),
                on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_auth_manage_panel(p, l_id, pg)
            )
            player.send_form(no_auth_panel)
            return
        remove_panel = ActionForm(
            title=self.language_manager.GetText('LAND_AUTH_REMOVE_PANEL_TITLE'),
            content=self.language_manager.GetText('LAND_AUTH_SELECT_REMOVE_CONTENT'),
            on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_auth_manage_panel(p, l_id, pg)
        )
        for shared_xuid in land_info['shared_users']:
            raw_name = self.get_player_name_by_xuid(shared_xuid, return_with_title=False)
            if not raw_name:
                continue
            display_name = self.get_player_name_by_xuid(shared_xuid, return_with_title=True) or raw_name
            remove_panel.add_button(
                self.language_manager.GetText('LAND_AUTH_REMOVE_TARGET_BUTTON').format(display_name),
                on_click=lambda p=player, l_id=land_id, uid=shared_xuid, name=raw_name, pg=from_page: self.op_remove_land_auth(p, l_id, uid, name, pg)
            )
        player.send_form(remove_panel)

    def op_add_land_auth(self, player: Player, land_id: int, target_player: Player, from_page: int):
        """OP 执行添加领地授权"""
        try:
            land_info = self.get_land_info(land_id)
            if not land_info:
                self.report_arc_error(
                    "OP8",
                    f"op_add_land_auth get_land_info empty land_id={land_id!r}",
                    player,
                )
                self.show_op_land_auth_manage_panel(player, land_id, from_page)
                return
            target_xuid = str(target_player.xuid)
            if target_xuid in land_info['shared_users']:
                player.send_message(self.language_manager.GetText('LAND_AUTH_ALREADY_EXISTS').format(target_player.name))
                self.show_op_land_auth_manage_panel(player, land_id, from_page)
                return
            success = self.land_system.add_land_shared_user(land_id, target_xuid)
            if success:
                player.send_message(self.language_manager.GetText('LAND_AUTH_SUCCESS_ADD').format(land_id, target_player.name))
                target_player.send_message(self.language_manager.GetText('LAND_AUTH_NOTIFICATION').format(
                    player.name, land_id, land_info['land_name']
                ))
            else:
                player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_ADD'))
        except Exception as e:
            self.logger.error(f"OP add land auth error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_ADD'))
        self.show_op_land_auth_manage_panel(player, land_id, from_page)

    def op_remove_land_auth(self, player: Player, land_id: int, target_xuid: str, target_name: str, from_page: int):
        """OP 执行移除领地授权"""
        try:
            land_info = self.get_land_info(land_id)
            if not land_info:
                self.report_arc_error(
                    "OP9",
                    f"op_remove_land_auth get_land_info empty land_id={land_id!r}",
                    player,
                )
                self.show_op_land_auth_manage_panel(player, land_id, from_page)
                return
            if target_xuid not in land_info['shared_users']:
                player.send_message(self.language_manager.GetText('LAND_AUTH_NOT_EXISTS').format(target_name))
                self.show_op_land_auth_manage_panel(player, land_id, from_page)
                return
            success = self.land_system.remove_land_shared_user(land_id, target_xuid)
            if success:
                player.send_message(self.language_manager.GetText('LAND_AUTH_SUCCESS_REMOVE').format(target_name, land_id))
                target_player = self.server.get_player(target_name)
                if target_player:
                    target_player.send_message(self.language_manager.GetText('LAND_AUTH_REMOVE_NOTIFICATION').format(
                        player.name, land_id, land_info['land_name']
                    ))
            else:
                player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_REMOVE'))
        except Exception as e:
            self.logger.error(f"OP remove land auth error: {str(e)}")
            player.send_message(self.language_manager.GetText('LAND_AUTH_FAILED_REMOVE'))
        self.show_op_land_auth_manage_panel(player, land_id, from_page)

    def show_op_public_land_settings_panel(self, player: Player, land_id: int, from_page: int):
        """OP 公共领地设置面板：开放互动/开放爆炸/开放生物互动/开放生物伤害"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "OP10",
                f"show_op_public_land_settings_panel get_land_info empty land_id={land_id!r}",
                player,
            )
            self.show_op_all_lands_panel(player, from_page)
            return
        status_lines = []
        status_lines.append('开放方块互动: ' + (self.language_manager.GetText('LAND_PUBLIC_INTERACT_STATUS_ENABLED') if land_info.get('allow_public_interact') else self.language_manager.GetText('LAND_PUBLIC_INTERACT_STATUS_DISABLED')))
        status_lines.append('开放爆炸: ' + (self.language_manager.GetText('LAND_EXPLOSION_STATUS_ENABLED') if land_info.get('allow_explosion') else self.language_manager.GetText('LAND_EXPLOSION_STATUS_DISABLED')))
        status_lines.append('开放生物互动: ' + (self.language_manager.GetText('LAND_ACTOR_INTERACTION_STATUS_ENABLED') if land_info.get('allow_actor_interaction') else self.language_manager.GetText('LAND_ACTOR_INTERACTION_STATUS_DISABLED')))
        status_lines.append('展示框: ' + (self.language_manager.GetText('LAND_FRAME_STATUS_ENABLED') if land_info.get('allow_frame') else self.language_manager.GetText('LAND_FRAME_STATUS_DISABLED')))
        status_lines.append('开放生物伤害: ' + (self.language_manager.GetText('LAND_ACTOR_DAMAGE_STATUS_ENABLED') if land_info.get('allow_actor_damage') else self.language_manager.GetText('LAND_ACTOR_DAMAGE_STATUS_DISABLED')))
        anpl_enabled = self.language_manager.GetText('ALLOW_NON_PUBLIC_LAND_STATUS_ENABLED') if land_info.get('allow_non_public_land') else self.language_manager.GetText('ALLOW_NON_PUBLIC_LAND_STATUS_DISABLED')
        status_lines.append(self.language_manager.GetText('ALLOW_NON_PUBLIC_LAND_CURRENT_STATUS').format(anpl_enabled))
        content = '\n'.join(status_lines)
        settings_panel = ActionForm(
            title=self.language_manager.GetText('OP_PUBLIC_LAND_SETTINGS_BUTTON'),
            content=content,
            on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg)
        )
        settings_panel.add_button(
            self.language_manager.GetText('LAND_PUBLIC_INTERACT_SETTING_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_toggle_panel(p, l_id, 'allow_public_interact', pg)
        )
        settings_panel.add_button(
            self.language_manager.GetText('LAND_EXPLOSION_SETTING_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_toggle_panel(p, l_id, 'allow_explosion', pg)
        )
        settings_panel.add_button(
            self.language_manager.GetText('LAND_ACTOR_INTERACTION_SETTING_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_toggle_panel(p, l_id, 'allow_actor_interaction', pg)
        )
        settings_panel.add_button(
            self.language_manager.GetText('LAND_FRAME_SETTING_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_toggle_panel(p, l_id, 'allow_frame', pg)
        )
        settings_panel.add_button(
            self.language_manager.GetText('LAND_ACTOR_DAMAGE_SETTING_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_toggle_panel(p, l_id, 'allow_actor_damage', pg)
        )
        settings_panel.add_button(
            self.language_manager.GetText('ALLOW_NON_PUBLIC_LAND_SETTING_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_toggle_panel(p, l_id, 'allow_non_public_land', pg)
        )
        settings_panel.add_button(
            self.language_manager.GetText('RETURN_BUTTON_TEXT'),
            on_click=lambda p=player, l_id=land_id, pg=from_page: self.show_op_land_detail_panel(p, l_id, pg)
        )
        player.send_form(settings_panel)
    
    def show_op_public_land_toggle_panel(self, player: Player, land_id: int, setting_key: str, from_page: int):
        """OP 公共领地单项设置切换面板"""
        land_info = self.get_land_info(land_id)
        if not land_info:
            self.report_arc_error(
                "OP11",
                f"show_op_public_land_toggle_panel get_land_info empty land_id={land_id!r} key={setting_key!r}",
                player,
            )
            self.show_op_all_lands_panel(player, from_page)
            return
        current = land_info.get(setting_key, False)
        if setting_key == 'allow_public_interact':
            status_text = self.language_manager.GetText('LAND_PUBLIC_INTERACT_STATUS_ENABLED') if current else self.language_manager.GetText('LAND_PUBLIC_INTERACT_STATUS_DISABLED')
            title = self.language_manager.GetText('LAND_PUBLIC_INTERACT_SETTING_TITLE')
        elif setting_key == 'allow_explosion':
            status_text = self.language_manager.GetText('LAND_EXPLOSION_STATUS_ENABLED') if current else self.language_manager.GetText('LAND_EXPLOSION_STATUS_DISABLED')
            title = self.language_manager.GetText('LAND_EXPLOSION_SETTING_TITLE')
        elif setting_key == 'allow_actor_interaction':
            status_text = self.language_manager.GetText('LAND_ACTOR_INTERACTION_STATUS_ENABLED') if current else self.language_manager.GetText('LAND_ACTOR_INTERACTION_STATUS_DISABLED')
            title = self.language_manager.GetText('LAND_ACTOR_INTERACTION_SETTING_TITLE')
        elif setting_key == 'allow_frame':
            status_text = self.language_manager.GetText('LAND_FRAME_STATUS_ENABLED') if current else self.language_manager.GetText('LAND_FRAME_STATUS_DISABLED')
            title = self.language_manager.GetText('LAND_FRAME_SETTING_TITLE')
        elif setting_key == 'allow_non_public_land':
            status_text = self.language_manager.GetText('ALLOW_NON_PUBLIC_LAND_STATUS_ENABLED') if current else self.language_manager.GetText('ALLOW_NON_PUBLIC_LAND_STATUS_DISABLED')
            title = self.language_manager.GetText('ALLOW_NON_PUBLIC_LAND_SETTING_BUTTON_TEXT')
        else:  # allow_actor_damage
            status_text = self.language_manager.GetText('LAND_ACTOR_DAMAGE_STATUS_ENABLED') if current else self.language_manager.GetText('LAND_ACTOR_DAMAGE_STATUS_DISABLED')
            title = self.language_manager.GetText('LAND_ACTOR_DAMAGE_SETTING_TITLE')
        toggle_panel = ActionForm(
            title=title,
            content=status_text,
            on_close=lambda p=player, l_id=land_id, pg=from_page: self.show_op_public_land_settings_panel(p, l_id, pg)
        )
        enable_key = {
            'allow_public_interact': ('LAND_PUBLIC_INTERACT_TOGGLE_ENABLE_BUTTON', 'LAND_PUBLIC_INTERACT_TOGGLE_DISABLE_BUTTON'),
            'allow_explosion': ('LAND_EXPLOSION_TOGGLE_ENABLE_BUTTON', 'LAND_EXPLOSION_TOGGLE_DISABLE_BUTTON'),
            'allow_actor_interaction': ('LAND_ACTOR_INTERACTION_TOGGLE_ENABLE_BUTTON', 'LAND_ACTOR_INTERACTION_TOGGLE_DISABLE_BUTTON'),
            'allow_frame': ('LAND_FRAME_TOGGLE_ENABLE_BUTTON', 'LAND_FRAME_TOGGLE_DISABLE_BUTTON'),
            'allow_actor_damage': ('LAND_ACTOR_DAMAGE_TOGGLE_ENABLE_BUTTON', 'LAND_ACTOR_DAMAGE_TOGGLE_DISABLE_BUTTON'),
            'allow_non_public_land': ('ALLOW_NON_PUBLIC_LAND_TOGGLE_ENABLE_BUTTON', 'ALLOW_NON_PUBLIC_LAND_TOGGLE_DISABLE_BUTTON'),
        }[setting_key]
        btn_text = self.language_manager.GetText(enable_key[0]) if not current else self.language_manager.GetText(enable_key[1])
        toggle_panel.add_button(
            btn_text,
            on_click=lambda p=player, l_id=land_id, key=setting_key, enable=not current, pg=from_page: self.op_toggle_land_setting(p, l_id, key, enable, pg)
        )
        player.send_form(toggle_panel)
    
    def op_toggle_land_setting(self, player: Player, land_id: int, setting_key: str, enable: bool, from_page: int):
        """OP 切换公共领地某项设置并返回设置面板"""
        setter_map = {
            'allow_public_interact': self.land_system.set_land_allow_public_interact,
            'allow_explosion': self.land_system.set_land_allow_explosion,
            'allow_actor_interaction': self.land_system.set_land_allow_actor_interaction,
            'allow_frame': self.land_system.set_land_allow_frame,
            'allow_actor_damage': self.land_system.set_land_allow_actor_damage,
            'allow_non_public_land': self.land_system.set_land_allow_non_public_land,
        }
        msg_map = {
            'allow_public_interact': ('LAND_PUBLIC_INTERACT_SETTING_UPDATED_ENABLE', 'LAND_PUBLIC_INTERACT_SETTING_UPDATED_DISABLE', 'LAND_PUBLIC_INTERACT_SETTING_FAILED'),
            'allow_explosion': ('LAND_EXPLOSION_SETTING_UPDATED_ENABLE', 'LAND_EXPLOSION_SETTING_UPDATED_DISABLE', 'LAND_EXPLOSION_SETTING_FAILED'),
            'allow_actor_interaction': ('LAND_ACTOR_INTERACTION_SETTING_UPDATED_ENABLE', 'LAND_ACTOR_INTERACTION_SETTING_UPDATED_DISABLE', 'LAND_ACTOR_INTERACTION_SETTING_FAILED'),
            'allow_frame': ('LAND_FRAME_SETTING_UPDATED_ENABLE', 'LAND_FRAME_SETTING_UPDATED_DISABLE', 'LAND_FRAME_SETTING_FAILED'),
            'allow_actor_damage': ('LAND_ACTOR_DAMAGE_SETTING_UPDATED_ENABLE', 'LAND_ACTOR_DAMAGE_SETTING_UPDATED_DISABLE', 'LAND_ACTOR_DAMAGE_SETTING_FAILED'),
            'allow_non_public_land': ('ALLOW_NON_PUBLIC_LAND_UPDATED_ENABLE', 'ALLOW_NON_PUBLIC_LAND_UPDATED_DISABLE', 'ALLOW_NON_PUBLIC_LAND_FAILED'),
        }
        msg_enable, msg_disable, msg_fail = msg_map[setting_key]
        try:
            success = setter_map[setting_key](land_id, enable)
            if success:
                player.send_message(self.language_manager.GetText(msg_enable if enable else msg_disable).format(land_id))
            else:
                player.send_message(self.language_manager.GetText(msg_fail))
            self.show_op_public_land_settings_panel(player, land_id, from_page)
        except Exception as e:
            self.logger.error(f"OP toggle land setting error: {str(e)}")
            self.report_arc_error(
                "OP12",
                f"op_toggle_land_setting exception land_id={land_id!r} setting_key={setting_key!r}",
                player,
                exception=e,
            )
            self.show_op_public_land_settings_panel(player, land_id, from_page)
    
    # DTWT Plugin related functions
    def show_dtwt_panel(self, player: Player):
        player.perform_command('dtwt')
    
    # Stock Market Plugin related functions
    def show_stock_ui(self, player: Player):
        player.perform_command('stock ui')

    # Tool
    @staticmethod
    def get_player_position_vector(player: Player):
        """
        获取玩家所在方块的坐标
        使用 math.floor() 确保负坐标也能正确计算方块位置
        """
        return (math.floor(player.location.x), math.floor(player.location.y), math.floor(player.location.z))

    # API methods for other plugins
    def api_get_all_money_data(self) -> dict:
        money_data = {}
        for entry in self.economy.get_all_money_raw():
            try:
                player_name = self.get_player_name_by_xuid(entry['xuid'], return_with_title=False)
                if player_name:
                    money_data[player_name] = entry['money']
            except Exception:
                continue
        return money_data

    def api_get_player_money(self, player_name: str) -> float:
        """
        获取目标玩家的金钱（API封装器）
        :param player_name: 玩家名称
        :return: 玩家金钱数量（支持小数，精确到分）
        """
        return self.get_player_money_by_name(player_name)

    def api_get_richest_player_money_data(self) -> list:
        result = self.economy.get_richest_one()
        if result:
            player_name = self.get_player_name_by_xuid(result['xuid'], return_with_title=False)
            if player_name:
                return [player_name, self._round_money(result['money'])]
        return ["", 0.0]

    def api_get_poorest_player_money_data(self) -> list:
        result = self.economy.get_poorest_one()
        if result:
            player_name = self.get_player_name_by_xuid(result['xuid'], return_with_title=False)
            if player_name:
                return [player_name, self._round_money(result['money'])]
        return ["", 0.0]

    def api_change_player_money(self, player_name: str, money_to_change: float) -> bool:
        if self._round_money(money_to_change) == 0:
            if self.logger:
                self.logger.error(f'{ColorFormat.RED}[ARC Core]Money change cannot be zero...')
            return False
        return self.change_player_money_by_name(player_name, money_to_change, notify=True)
    
    def api_if_position_in_land(self, dimension: str, position: tuple) -> int:
        """
        判断位置是否在玩家领地内，不在的话返回None，存在的话返回领地id
        """
        return self.get_land_at_pos(dimension, math.floor(position[0]), math.floor(position[2]))
    
    def api_get_land_info(self, land_id: int) -> dict:
        """
        获取领地信息
        :return: 领地信息字典 {
            'land_name': 领地名称,
            'dimension': 维度,
            'min_x': 最小X坐标,
            'max_x': 最大X坐标,
            'min_z': 最小Z坐标,
            'max_z': 最大Z坐标,
            'tp_x': 传送点X坐标,
            'tp_y': 传送点Y坐标,
            'tp_z': 传送点Z坐标,
            'shared_users': 共享玩家XUID列表,
            'owner_xuid': 拥有者XUID
        } 不存在则返回空字典
        """
        return self.get_land_info(land_id)

    # 公告系统
    def _load_broadcast_messages(self):
        """从broadcast.txt文件加载公告消息"""
        try:
            broadcast_file = Path(MAIN_PATH) / "broadcast.txt"
            if not broadcast_file.exists():
                self.logger.warning(f"[ARC Core]broadcast.txt not found, creating empty file")
                broadcast_file.parent.mkdir(exist_ok=True)
                broadcast_file.touch()
                return

            with broadcast_file.open("r", encoding="utf-8") as f:
                lines = f.readlines()
                self.broadcast_messages = [line.strip() for line in lines if line.strip()]

            if not self.broadcast_messages:
                self.logger.warning(f"[ARC Core]broadcast.txt is empty")
            else:
                self.logger.info(f"[ARC Core]Loaded {len(self.broadcast_messages)} broadcast messages")
        except Exception as e:
            self.logger.error(f"[ARC Core]Load broadcast messages error: {str(e)}")

    def send_broadcast_message(self):
        """发送公告消息"""
        try:
            if not self.broadcast_messages:
                return

            # 获取当前公告消息
            message = self.broadcast_messages[self.current_broadcast_index]
            
            # 替换特殊符号
            message = self._process_broadcast_placeholders(message)
            
            # 发送给所有在线玩家
            for player in self.server.online_players:
                player.send_message(f"{self.language_manager.GetText('BROADCAST_MESSAGE_PREFIX')}: {message}")
            
            # 更新索引
            self.current_broadcast_index = (self.current_broadcast_index + 1) % len(self.broadcast_messages)
            
        except Exception as e:
            self.logger.error(f"[ARC Core]Send broadcast message error: {str(e)}")

    def _process_broadcast_placeholders(self, message: str) -> str:
        """处理公告消息中的占位符"""
        try:
            current_time = datetime.now()
            
            # 替换{date}为当前日期 (年-月-日)
            date_str = current_time.strftime("%Y-%m-%d")
            message = message.replace("{date}", date_str)
            
            # 替换{time}为当前时间 (小时:分钟)
            time_str = current_time.strftime("%H:%M")
            message = message.replace("{time}", time_str)
            
            # 替换{online_player_number}为当前在线玩家数量
            online_player_count = len(self.server.online_players)
            message = message.replace("{online_player_number}", str(online_player_count))
            
            return message
        except Exception as e:
            self.logger.error(f"[ARC Core]Process broadcast placeholders error: {str(e)}")
            return message  # 如果处理失败，返回原消息

    def send_small_horn_messages(self):
        """每10分钟轮询并广播所有有效小喇叭。"""
        try:
            now_iso = datetime.now().isoformat(timespec='seconds')
            active_orders = self.database_manager.query_all(
                "SELECT id, xuid, content, end_time FROM small_horn_orders "
                "WHERE start_time <= ? AND end_time > ? "
                "ORDER BY created_at ASC",
                (now_iso, now_iso)
            )
            if not active_orders:
                return

            for order in active_orders:
                player_xuid = str(order.get('xuid') or '').strip()
                content = str(order.get('content') or '').strip()
                if not player_xuid or not content:
                    continue
                display_name = (
                    self.get_player_name_by_xuid(player_xuid, return_with_title=True)
                    or self.get_player_name_by_xuid(player_xuid, return_with_title=False)
                    or player_xuid
                )
                self.server.broadcast_message(f"[小喇叭]玩家{display_name}：{content}")

            self.database_manager.execute(
                "DELETE FROM small_horn_orders WHERE end_time <= ?",
                (now_iso,)
            )
        except Exception as e:
            self.logger.error(f"[ARC Core]Send small horn messages error: {str(e)}")

    def _format_death_broadcast_player_display(self, player: Player) -> str:
        """死亡播报中的玩家展示名：与聊天/头顶名一致（含公会前缀）。"""
        equipped = self.title_system.get_equipped_title(player)
        raw_name = getattr(player, "name", "") or ""
        base = self.format_player_display_label_with_guild(
            raw_name, equipped, str(player.xuid)
        )
        return f"{base}§r"

    def _announce_achievement_unlock(self, player: Player, achievement_name: str, unlock_title: str) -> None:
        """
        成就解锁全服通告 + QQ 群/跨服广播（通过 qqsync）。

        文案：
        玩家[头衔]名字解锁了成就【成就名】，获得头衔奖励【奖励头衔】
        其中【成就名】与【奖励头衔】使用“奖励头衔”的稀有色。
        """
        try:
            achievement_name = str(achievement_name or "").strip()
            unlock_title = str(unlock_title or "").strip()
            if not player or not achievement_name or not unlock_title:
                return

            player_display = self._format_death_broadcast_player_display(player)
            rarity_color = self.title_system.get_title_rarity_color(unlock_title)
            colored_achievement = f"{rarity_color}【{achievement_name}】§r"
            colored_title = f"{rarity_color}【{unlock_title}】§r"
            msg = f"玩家{player_display}解锁了成就{colored_achievement}，获得头衔奖励{colored_title}"

            # 游戏内全服广播
            try:
                self.server.broadcast_message(msg)
            except Exception:
                # 兼容部分端：broadcast_message 不存在则退化为遍历在线玩家
                for p in getattr(self.server, "online_players", []) or []:
                    try:
                        p.send_message(msg)
                    except Exception:
                        pass

            # QQ 群/跨服广播：交给 qqsync（多服部署时由 qqsync/机器人实现跨服同步）
            try:
                equipped = self.title_system.get_equipped_title(player)
                display_name = self.format_player_display_label_with_guild(
                    getattr(player, "name", "") or "", equipped, str(player.xuid)
                )
                self._notify_qqsync("custom", display_name, getattr(player, "name", "") or "", msg)
            except Exception:
                pass
        except Exception as e:
            try:
                self.logger.error(f"[ARC Core]Announce achievement unlock error: {e}")
            except Exception:
                pass

    def _send_death_broadcast(self, event: PlayerDeathEvent):
        """发送死亡播报消息"""
        try:
            player_name = self._format_death_broadcast_player_display(event.player)
            dimension_raw = event.player.location.dimension.name
            dimension = self._translate_dimension_name(dimension_raw)
            x = int(event.player.location.x)
            y = int(event.player.location.y)
            z = int(event.player.location.z)
            
            # 尝试获取死亡原因
            death_cause_raw = self._get_death_cause(event)
            death_cause_translated = self._translate_death_cause(death_cause_raw) if death_cause_raw else ""
            
            # 尝试获取攻击者信息
            attacker_name = self._get_entity_name_from_damage_source(event)
            # 由生物/玩家造成的死亡原因（原始类型，用于判断是否显示攻击者；与语言文件“生物殴打”等对应）
            is_entity_cause = self._is_entity_attack_death_cause(death_cause_raw)
            
            # 根据死亡原因和攻击者信息选择消息格式
            if attacker_name and is_entity_cause:
                # 被生物或玩家杀死：根据死因使用更有梗的文案
                game_key, qq_key = self._pick_entity_kill_message_keys(death_cause_raw)
                game_message = self.language_manager.GetText(game_key).format(
                    player_name, dimension, x, y, z, attacker_name
                )
                qq_message = self.language_manager.GetText(qq_key).format(
                    player_name, dimension, x, y, z, attacker_name
                )
            elif death_cause_translated:
                # 只有死亡原因
                game_message = self.language_manager.GetText('DEATH_BROADCAST_MESSAGE_WITH_CAUSE').format(
                    player_name, dimension, x, y, z, death_cause_translated
                )
                qq_message = self.language_manager.GetText('DEATH_QQ_MESSAGE_WITH_CAUSE').format(
                    player_name, dimension, x, y, z, death_cause_translated
                )
            else:
                # 没有死亡原因
                game_message = self.language_manager.GetText('DEATH_BROADCAST_MESSAGE').format(
                    player_name, dimension, x, y, z
                )
                qq_message = self.language_manager.GetText('DEATH_QQ_MESSAGE').format(
                    player_name, dimension, x, y, z
                )
            
            # 发送给所有在线玩家
            for player in self.server.online_players:
                player.send_message(game_message)

            # 发送到QQ群（通过 qqsync API）
            try:
                qqsync = self.server.plugin_manager.get_plugin('qqsync_plugin')
                if qqsync:
                    qqsync.api_send_raw(qq_message)
                else:
                    self.logger.warning("[ARC Core] QQSync 插件未找到，无法发送死亡消息到群")
            except Exception as e:
                self.logger.error(f"[ARC Core] 发送死亡消息到QQ群失败: {e}")
                
        except Exception as e:
            self.logger.error(f"[ARC Core]Send death broadcast error: {str(e)}")

    def _get_death_cause(self, event: PlayerDeathEvent) -> str:
        """获取死亡原因"""
        try:
            # 根据EndStone文档，PlayerDeathEvent有damage_source属性
            if hasattr(event, 'damage_source') and event.damage_source:
                damage_source = event.damage_source
                
                # 尝试获取伤害源类型
                if hasattr(damage_source, 'damage_type'):
                    return str(damage_source.damage_type)
                elif hasattr(damage_source, 'type'):
                    return str(damage_source.type)
                else:
                    return str(damage_source)
            # 兼容性检查其他可能的属性
            elif hasattr(event, 'death_cause'):
                return str(event.death_cause)
            elif hasattr(event, 'cause'):
                return str(event.cause)
            else:
                return ""
        except Exception as e:
            self.logger.error(f"[ARC Core]Get death cause error: {str(e)}")
            return ""

    def _is_entity_attack_death_cause(self, death_cause_raw: str) -> bool:
        """判断是否为生物/玩家攻击类死亡原因（有明确攻击者时可显示“被xx殴打致死”）。"""
        if not death_cause_raw or not str(death_cause_raw).strip():
            return False
        cause = str(death_cause_raw).strip().lower()
        if ":" in cause:
            cause = cause.split(":")[-1]
        entity_attack_causes = {
            "entity_attack", "mob_attack", "player_attack",
            "arrow", "trident", "thrown", "mob_projectile", "projectile",
            "entity_explosion", "mob_explosion", "entity_explosion",
            "ram_attack", "spit", "sting", "sweep_attack",
        }
        return cause in entity_attack_causes

    def _pick_entity_kill_message_keys(self, death_cause_raw: str) -> tuple[str, str]:
        """根据死因选择“带击杀者”的播报文案 key。"""
        cause = str(death_cause_raw or "").strip().lower()
        if ":" in cause:
            cause = cause.split(":")[-1]

        if cause in {"entity_explosion", "mob_explosion"}:
            return "DEATH_BROADCAST_BY_ENTITY_EXPLOSION", "DEATH_QQ_BY_ENTITY_EXPLOSION"

        if cause in {"arrow", "trident", "thrown", "mob_projectile", "projectile"}:
            return "DEATH_BROADCAST_BY_ENTITY_PROJECTILE", "DEATH_QQ_BY_ENTITY_PROJECTILE"

        # 默认近战/其他可归因到实体的情况
        return "DEATH_BROADCAST_BY_ENTITY", "DEATH_QQ_BY_ENTITY"

    def _translate_death_cause(self, death_cause: str) -> str:
        """翻译死亡原因"""
        try:
            if not death_cause:
                return ""
            
            # 将死亡原因转换为大写并添加前缀
            death_cause_key = f"DEATH_CAUSE_{death_cause.upper()}"
            
            # 使用 LanguageManager 获取翻译
            translation = self.language_manager.GetText(death_cause_key)
            
            # 如果找到了翻译，返回翻译结果
            if translation:
                return translation
            
            # 如果没找到翻译，尝试部分匹配
            # 处理一些特殊情况，比如 minecraft:fall 这样的格式
            if ':' in death_cause:
                simple_cause = death_cause.split(':')[-1]
                simple_key = f"DEATH_CAUSE_{simple_cause.upper()}"
                simple_translation = self.language_manager.GetText(simple_key)
                if simple_translation:
                    return simple_translation
            
            # 如果找不到翻译，返回原字符串
            return death_cause
            
        except Exception as e:
            self.logger.error(f"[ARC Core] 翻译死亡原因错误: {str(e)}")
            return death_cause

    def _get_entity_name_from_damage_source(self, event: PlayerDeathEvent) -> str:
        """从伤害源获取生物/玩家名称（用于“被xx殴打致死”播报）。"""
        try:
            # 先尝试事件自身的攻击者属性（部分引擎把 killer/damager 放在 event 上）
            if hasattr(event, "killer") and event.killer:
                name = self._translate_entity_name(event.killer)
                if name:
                    return name
            if hasattr(event, "damager") and event.damager:
                name = self._translate_entity_name(event.damager)
                if name:
                    return name
            if hasattr(event, "damage_source") and event.damage_source:
                damage_source = event.damage_source
                # 优先 actor（造成伤害的实体，近战为生物本身）
                if hasattr(damage_source, "actor") and damage_source.actor:
                    name = self._translate_entity_name(damage_source.actor)
                    if name:
                        return name
                if hasattr(damage_source, "damaging_actor") and damage_source.damaging_actor:
                    name = self._translate_entity_name(damage_source.damaging_actor)
                    if name:
                        return name
                if hasattr(damage_source, "damaging_entity") and damage_source.damaging_entity:
                    name = self._translate_entity_name(damage_source.damaging_entity)
                    if name:
                        return name
                if hasattr(damage_source, "entity") and damage_source.entity:
                    name = self._translate_entity_name(damage_source.entity)
                    if name:
                        return name
                if hasattr(damage_source, "attacker") and damage_source.attacker:
                    name = self._translate_entity_name(damage_source.attacker)
                    if name:
                        return name
            return ""
        except Exception as e:
            self.logger.error(f"[ARC Core] 获取生物名称错误: {str(e)}")
            return ""

    def _translate_entity_name(self, entity) -> str:
        """翻译生物名称。若名称为 MC 未翻译键（含 ':'，如 entity.ns_ab:vfx_dragon_fire.name），则用 EntityDisplayNameManager 从 entity_display_name.txt 读取。"""
        try:
            if not entity:
                return ""
            raw = (
                getattr(entity, "name_tag", None)
                or getattr(entity, "type", None)
                or getattr(entity, "name", None)
            )
            raw = str(raw).strip() if raw else str(type(entity).__name__)
            if ":" in raw:
                return self.entity_display_name_manager.get_display_name(raw)
            return raw
        except Exception as e:
            if self.logger:
                self.logger.error(f"[ARC Core] 翻译生物名称错误: {str(e)}")
            return str(entity) if entity else ""

    def _translate_dimension_name(self, dimension_name: str) -> str:
        """翻译维度名称"""
        try:
            if not dimension_name:
                return ""
            
            # 将维度名称转换为大写并添加前缀
            dimension_key = f"DIMENSION_{dimension_name.upper()}"
            
            # 使用 LanguageManager 获取翻译
            translation = self.language_manager.GetText(dimension_key)
            
            # 如果找到了翻译，返回翻译结果
            if translation:
                return translation
            
            # 如果没找到翻译，返回原字符串
            return dimension_name
            
        except Exception as e:
            self.logger.error(f"[ARC Core] 翻译维度名称错误: {str(e)}")
            return dimension_name

    def _send_to_qq_group(self, message: str):
        """
        发送消息到QQ群（旧接口，保持兼容）
        :param message: 要发送的消息
        """
        try:
            qqsync = self.server.plugin_manager.get_plugin('qqsync_plugin')
            if qqsync is None:
                self.logger.warning("[ARC Core] QQSync 插件未找到，无法发送群消息")
                return
            success = qqsync.api_send_message(message)
            if not success:
                self.logger.warning(f"[ARC Core] QQ群消息发送失败: {message}")
        except Exception as e:
            self.logger.error(f"[ARC Core] QQ群消息发送异常: {str(e)}")

    def _notify_qqsync(self, event_type: str, display_name: str,
                        raw_player_name: str, message: str = ""):
        """
        通知 qqsync 插件发送事件消息到 QQ 群。
        :param event_type: "join" | "quit" | "chat" | "death" | "custom"
        :param display_name: 带头衔的显示名 (含 § 颜色码)
        :param raw_player_name: 原始玩家名
        :param message: 额外消息内容
        """
        try:
            qqsync = self.server.plugin_manager.get_plugin('qqsync_plugin')
            if qqsync is None:
                return
            qqsync.api_send_event(event_type, display_name, raw_player_name, message)
        except Exception as e:
            self.logger.error(f"[ARC Core]Notify qqsync error: {e}")

    # 清道夫系统
    def _init_cleaner_system(self):
        """初始化清道夫系统"""
        try:
            # 获取清道夫设置
            self.enable_cleaner = self.setting_manager.GetSetting('ENABLE_CLEANER')
            if self.enable_cleaner is None or self.enable_cleaner.lower() not in ['true', 'false']:
                self.enable_cleaner = False
            else:
                self.enable_cleaner = self.enable_cleaner.lower() == 'true'

            self.cleaner_interval = self.setting_manager.GetSetting('CLEANER_INTERVAL')
            try:
                self.cleaner_interval = int(self.cleaner_interval)
            except (ValueError, TypeError):
                self.cleaner_interval = 600  # 默认10分钟

            if self.enable_cleaner:
                self.logger.info(f"[ARC Core]Cleaner system enabled, interval: {self.cleaner_interval} seconds")
            else:
                self.logger.info(f"[ARC Core]Cleaner system disabled")

        except Exception as e:
            self.logger.error(f"[ARC Core]Init cleaner system error: {str(e)}")

    def start_cleaner_warning(self):
        """开始清道夫警告倒计时"""
        try:
            if not self.enable_cleaner:
                return

            # 发送10秒后清理警告
            for player in self.server.online_players:
                player.send_message(self.language_manager.GetText('READY_TO_CLEAR_DROP_ITEM_BROADCAST'))

            # 10秒后执行清理
            self.server.scheduler.run_task(self, self.execute_cleaner, delay=200)  # 10秒 = 200 ticks

        except Exception as e:
            self.logger.error(f"[ARC Core]Start cleaner warning error: {str(e)}")

    def execute_cleaner(self):
        """执行清理掉落物"""
        try:
            if not self.enable_cleaner:
                return

            # 发送正在清理消息
            for player in self.server.online_players:
                player.send_message(self.language_manager.GetText('CLEAR_DROP_ITEM_BROADCAST'))

            # 执行清理命令
            self.server.dispatch_command(self.server.command_sender, "kill @e[type=item,name=!\"Trial Key\",name=!\"Ominous Trial Key\"]")

            # 发送清理完成消息
            self.server.scheduler.run_task(self, self.cleaner_complete_message, delay=20)  # 1秒后发送完成消息

        except Exception as e:
            self.logger.error(f"[ARC Core]Execute cleaner error: {str(e)}")

    def cleaner_complete_message(self):
        """发送清理完成消息"""
        try:
            for player in self.server.online_players:
                player.send_message(self.language_manager.GetText('CLEAR_DROP_ITEM_COMPLETE'))
        except Exception as e:
            self.logger.error(f"[ARC Core]Cleaner complete message error: {str(e)}")