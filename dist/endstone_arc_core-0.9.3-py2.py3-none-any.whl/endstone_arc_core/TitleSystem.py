# -*- coding: utf-8 -*-
"""头衔系统：稀有度、介绍、解锁时间、解锁奖励；玩家解锁/佩戴，聊天展示。"""
import json
from datetime import datetime
from typing import List, Optional, Dict, Any, Tuple

from endstone import Player


# 稀有度 -> MC 颜色码（§0-§f）
RARITY_COLORS = {
    "普通": "§h",
    "稀有": "§9",
    "史诗": "§u",
    "传奇": "§6",
    "神话": "§c",
}
DEFAULT_RARITY = "普通"

# 稀有度比较顺序（数值越大越高）
RARITY_ORDER = {
    "普通": 0,
    "稀有": 1,
    "史诗": 2,
    "传奇": 3,
    "神话": 4,
}


class TitleSystem:
    """头衔系统：头衔定义（稀有度、介绍、奖励）、解锁时间、佩戴与聊天展示。"""

    def __init__(self, database_manager, setting_manager):
        self.database_manager = database_manager
        self.setting_manager = setting_manager
        self._table_def = "title_definitions"
        self._table_unlock_time = "player_title_unlock_time"
        self._table_equipped = "player_title_equipped"

    def ensure_tables(self) -> bool:
        """创建头衔相关表"""
        try:
            self.database_manager.execute(
                "CREATE TABLE IF NOT EXISTS title_definitions (title TEXT PRIMARY KEY, rarity TEXT, description TEXT, reward_money REAL DEFAULT 0, reward_items TEXT DEFAULT '[]')"
            )
            self.database_manager.execute(
                "CREATE TABLE IF NOT EXISTS player_title_unlock_time (xuid TEXT NOT NULL, title TEXT NOT NULL, unlocked_at TEXT, UNIQUE(xuid, title))"
            )
            self.database_manager.execute(
                "CREATE TABLE IF NOT EXISTS player_title_equipped (xuid TEXT PRIMARY KEY, title TEXT)"
            )
            self._seed_default_title_definitions()
            return True
        except Exception:
            return False

    def _seed_default_title_definitions(self) -> None:
        """确保配置中的默认头衔和 OP 头衔在 title_definitions 中存在（默认稀有度、空介绍、无奖励）。"""
        for t in self.get_default_titles():
            self.ensure_title_definition(t, DEFAULT_RARITY, "", 0.0, [])
        op_t = self.get_op_title()
        if op_t:
            self.ensure_title_definition(op_t, DEFAULT_RARITY, "", 0.0, [])

    def ensure_title_definition(self, title: str, rarity: str = DEFAULT_RARITY, description: str = "", reward_money: float = 0.0, reward_items: Optional[List] = None) -> bool:
        """若头衔不存在则插入默认定义。"""
        if not title or not title.strip():
            return False
        title = title.strip()
        if reward_items is None:
            reward_items = []
        try:
            self.database_manager.execute(
                "INSERT OR IGNORE INTO title_definitions (title, rarity, description, reward_money, reward_items) VALUES (?, ?, ?, ?, ?)",
                (title, rarity, description, reward_money, json.dumps(reward_items, ensure_ascii=False))
            )
            return True
        except Exception:
            return False

    def get_title_definition(self, title: str) -> Optional[Dict[str, Any]]:
        """获取头衔定义：rarity, description, reward_money, reward_items。"""
        row = self.database_manager.query_one(
            "SELECT title, rarity, description, reward_money, reward_items FROM title_definitions WHERE title = ?",
            (title.strip(),)
        )
        if not row:
            return None
        reward_items = []
        if row.get("reward_items"):
            try:
                reward_items = json.loads(row["reward_items"])
            except (TypeError, ValueError, json.JSONDecodeError):
                reward_items = []
        return {
            "title": row["title"],
            "rarity": row.get("rarity") or DEFAULT_RARITY,
            "description": row.get("description") or "",
            "reward_money": float(row.get("reward_money") or 0),
            "reward_items": reward_items,
        }

    def set_title_definition(self, title: str, rarity: str, description: str, reward_money: float, reward_items: List) -> bool:
        """更新头衔定义（OP 编辑或创建新头衔）。"""
        if not title or not title.strip():
            return False
        title = title.strip()
        try:
            self.database_manager.execute(
                "INSERT OR REPLACE INTO title_definitions (title, rarity, description, reward_money, reward_items) VALUES (?, ?, ?, ?, ?)",
                (title, rarity, description, reward_money, json.dumps(reward_items, ensure_ascii=False))
            )
            return True
        except Exception:
            return False

    def rename_title(self, old_title: str, new_title: str) -> bool:
        """重命名头衔：同时更新定义/解锁记录/佩戴记录。"""
        try:
            old_title = (old_title or "").strip()
            new_title = (new_title or "").strip()
            if not old_title or not new_title:
                return False
            if old_title == new_title:
                return True

            old_defn = self.get_title_definition(old_title)
            if not old_defn:
                return False

            # 新名字已存在则不允许（防止覆盖/数据冲突）
            if self.get_title_definition(new_title):
                return False

            # 复制旧定义到新定义
            ok = self.set_title_definition(
                new_title,
                old_defn.get("rarity") or DEFAULT_RARITY,
                old_defn.get("description") or "",
                float(old_defn.get("reward_money") or 0.0),
                old_defn.get("reward_items") or [],
            )
            if not ok:
                return False

            # 同步玩家解锁记录
            self.database_manager.execute(
                "UPDATE player_title_unlock_time SET title = ? WHERE title = ?",
                (new_title, old_title),
            )

            # 同步玩家佩戴记录
            self.database_manager.execute(
                "UPDATE player_title_equipped SET title = ? WHERE title = ?",
                (new_title, old_title),
            )

            # 删除旧定义（玩家记录已迁移到新名字）
            self.database_manager.execute(
                "DELETE FROM title_definitions WHERE title = ?",
                (old_title,),
            )

            return True
        except Exception:
            return False

    def get_all_title_names(self) -> List[str]:
        """所有头衔名：配置默认 + OP 头衔 + 数据库中自定义头衔（去重）。"""
        default = self.get_default_titles()
        op_t = self.get_op_title()
        rows = self.database_manager.query_all("SELECT title FROM title_definitions", ())
        db_titles = [r["title"] for r in rows if r.get("title")]
        seen = set()
        result = []
        for t in default + ([op_t] if op_t else []) + db_titles:
            if t and t not in seen:
                result.append(t)
                seen.add(t)
        return result

    def rarity_rank(self, rarity: str) -> int:
        """稀有度排序用权重，未知稀有度视为最低档。"""
        if not rarity:
            return RARITY_ORDER[DEFAULT_RARITY]
        return RARITY_ORDER.get(rarity.strip(), RARITY_ORDER[DEFAULT_RARITY])

    def pick_highest_rarity_title(self, title_names: List[str]) -> Optional[str]:
        """从已解锁头衔名列表中选出稀有度最高的一条；同稀有度时保留先出现的。"""
        if not title_names:
            return None
        best_name: Optional[str] = None
        best_rank = -1
        for title_name in title_names:
            if not title_name:
                continue
            defn = self.get_title_definition(title_name.strip())
            rarity = (defn.get("rarity") if defn else None) or DEFAULT_RARITY
            rank = self.rarity_rank(rarity)
            if rank > best_rank:
                best_rank = rank
                best_name = title_name.strip()
        return best_name

    def get_title_rarity_color(self, title: str) -> str:
        """根据头衔稀有度返回 MC 颜色码，如 §f、§9。"""
        defn = self.get_title_definition(title)
        rarity = (defn.get("rarity") or DEFAULT_RARITY) if defn else DEFAULT_RARITY
        return RARITY_COLORS.get(rarity, "§f")

    def get_normal_rarity_color(self) -> str:
        """「普通」稀有度对应颜色（用于公会名等与默认头衔一致的着色）。"""
        return RARITY_COLORS.get(DEFAULT_RARITY, "§f")

    def _get_default_titles_raw(self) -> str:
        raw = self.setting_manager.GetSetting("DEFAULT_TITLE")
        return (raw or "").strip()

    def get_default_titles(self) -> List[str]:
        """配置中的默认头衔列表（逗号分隔）。"""
        raw = self._get_default_titles_raw()
        if not raw:
            return []
        return [t.strip() for t in raw.split(",") if t.strip()]

    def get_op_title(self) -> Optional[str]:
        """配置中的 OP 专属头衔（仅一个）。"""
        raw = self.setting_manager.GetSetting("OP_TITLE")
        if not raw or not str(raw).strip():
            return None
        return str(raw).strip()

    def _xuid(self, player: Player) -> str:
        return str(player.xuid)

    def get_unlocked_titles(self, player: Player) -> List[str]:
        """玩家当前拥有的全部头衔（来自 player_title_unlock_time）。"""
        xuid = self._xuid(player)
        rows = self.database_manager.query_all(
            "SELECT title FROM player_title_unlock_time WHERE xuid = ? ORDER BY title",
            (xuid,)
        )
        return [r["title"] for r in rows if r.get("title")]

    def get_unlocked_titles_by_xuid(self, xuid: str) -> List[str]:
        xs = str(xuid or "").strip()
        if not xs:
            return []
        rows = self.database_manager.query_all(
            "SELECT title FROM player_title_unlock_time WHERE xuid = ? ORDER BY title",
            (xs,),
        )
        return [r["title"] for r in rows if r.get("title")]

    def get_title_unlock_time(self, player: Player, title: str) -> Optional[str]:
        """玩家某头衔的解锁时间（ISO 字符串），未解锁返回 None。"""
        row = self.database_manager.query_one(
            "SELECT unlocked_at FROM player_title_unlock_time WHERE xuid = ? AND title = ?",
            (self._xuid(player), title.strip())
        )
        return row.get("unlocked_at") if row else None

    def get_equipped_title(self, player: Player) -> Optional[str]:
        """当前佩戴的头衔，未佩戴返回 None。"""
        row = self.database_manager.query_one(
            "SELECT title FROM player_title_equipped WHERE xuid = ?",
            (self._xuid(player),)
        )
        if not row or row.get("title") is None:
            return None
        return row["title"]

    def get_equipped_title_by_xuid(self, xuid: str) -> Optional[str]:
        """按 xuid 查询当前佩戴头衔；无记录或未佩戴返回 None。"""
        xs = (xuid or "").strip()
        if not xs:
            return None
        row = self.database_manager.query_one(
            "SELECT title FROM player_title_equipped WHERE xuid = ?",
            (xs,),
        )
        if not row or row.get("title") is None:
            return None
        t = row["title"]
        return str(t).strip() if t else None

    def format_player_display_label(self, raw_player_name: str, equipped_title: Optional[str]) -> str:
        """展示用：有佩戴头衔时为 [稀有色][头衔]§r名字（稀有色不延伸到名字），否则为裸名。"""
        name = (raw_player_name or "").strip() or "?"
        et = (equipped_title or "").strip() if equipped_title else ""
        if not et:
            return name
        color = self.get_title_rarity_color(et)
        return color + "[" + et + "]" + "§r" + name

    def set_equipped_title_by_xuid(self, xuid: str, title: Optional[str]) -> bool:
        """按 xuid 设置佩戴头衔。仅当 title 在解锁列表中或为 None 时才允许。"""
        xs = (xuid or "").strip()
        if not xs:
            return False
        if title is None or title == "":
            return self.database_manager.execute(
                "DELETE FROM player_title_equipped WHERE xuid = ?", (xs,)
            )
        title_s = str(title).strip()
        if not title_s:
            return False
        unlocked = self.get_unlocked_titles_by_xuid(xs)
        if title_s not in unlocked:
            return False
        self.database_manager.execute("DELETE FROM player_title_equipped WHERE xuid = ?", (xs,))
        return self.database_manager.execute(
            "INSERT INTO player_title_equipped (xuid, title) VALUES (?, ?)", (xs, title_s)
        )

    def set_equipped_title(self, player: Player, title: Optional[str]) -> bool:
        """设置佩戴头衔。仅当 title 在解锁列表中或为 None 时才允许。"""
        return self.set_equipped_title_by_xuid(self._xuid(player), title)

    def unlock_title(self, player: Player, title: str) -> Tuple[bool, bool]:
        """为玩家解锁头衔（API）。返回 (是否成功, 是否本次新解锁)；已拥有该头衔时成功为 True、新解锁为 False。"""
        if not title or not title.strip():
            return False, False
        return self.unlock_title_by_xuid(self._xuid(player), title.strip())

    def unlock_title_by_xuid(self, xuid: str, title: str, unlocked_at: Optional[str] = None) -> Tuple[bool, bool]:
        """按 xuid 为玩家解锁头衔并记录解锁时间。返回 (是否成功, 是否本次新解锁)。

        已解锁时返回 (True, False)，避免重复发放头衔解锁奖励。
        """
        if not xuid or not title or not title.strip():
            return False, False
        title = title.strip()
        if unlocked_at is None:
            unlocked_at = datetime.now().isoformat()
        try:
            if self.has_unlocked_title_by_xuid(xuid, title):
                return True, False
            ok = bool(
                self.database_manager.execute(
                    "INSERT INTO player_title_unlock_time (xuid, title, unlocked_at) VALUES (?, ?, ?)",
                    (xuid, title, unlocked_at),
                )
            )
            if ok:
                return True, True
            if self.has_unlocked_title_by_xuid(xuid, title):
                return True, False
            return False, False
        except Exception:
            return False, False

    def has_unlocked_title_by_xuid(self, xuid: str, title: str) -> bool:
        """查询玩家是否已在头衔解锁表中拥有该头衔。"""
        xs = str(xuid or "").strip()
        tt = str(title or "").strip()
        if not xs or not tt:
            return False
        row = self.database_manager.query_one(
            "SELECT 1 FROM player_title_unlock_time WHERE xuid = ? AND title = ?",
            (xs, tt),
        )
        return row is not None

    def revoke_title_by_xuid(self, xuid: str, title: str) -> Tuple[bool, bool]:
        """按 xuid 撤销玩家头衔（从解锁记录移除；若正在佩戴则取消佩戴）。

        返回 (是否成功, 撤销前是否正佩戴该头衔)。
        """
        try:
            xuid = (xuid or "").strip()
            title = (title or "").strip()
            if not xuid or not title:
                return False, False

            was_equipped = False
            row = self.database_manager.query_one(
                "SELECT title FROM player_title_equipped WHERE xuid = ?",
                (xuid,),
            )
            if row and row.get("title") == title:
                was_equipped = True
                self.database_manager.execute(
                    "DELETE FROM player_title_equipped WHERE xuid = ?",
                    (xuid,),
                )

            self.database_manager.execute(
                "DELETE FROM player_title_unlock_time WHERE xuid = ? AND title = ?",
                (xuid, title),
            )
            return True, was_equipped
        except Exception:
            return False, False

    def revoke_title(self, player: Player, title: str) -> Tuple[bool, bool]:
        """撤销玩家头衔（在线玩家版）。返回 (是否成功, 撤销前是否正佩戴)。"""
        if not player:
            return False, False
        return self.revoke_title_by_xuid(str(player.xuid), title)

    def on_player_join(self, player: Player) -> None:
        """进服时：1) 确保默认头衔与 OP 头衔有解锁记录（无则插入，时间为当前）；2) 若非 OP 且佩戴 OP 头衔则解除佩戴。"""
        xuid = self._xuid(player)
        default_titles = self.get_default_titles()
        op_title = self.get_op_title()
        to_ensure = list(default_titles)
        if op_title and getattr(player, "is_op", False):
            to_ensure.append(op_title)
        now_iso = datetime.now().isoformat()
        for t in to_ensure:
            if not t:
                continue
            self.ensure_title_definition(t)
            self.database_manager.execute(
                "INSERT OR IGNORE INTO player_title_unlock_time (xuid, title, unlocked_at) VALUES (?, ?, ?)",
                (xuid, t, now_iso)
            )
        if op_title and not getattr(player, "is_op", False):
            equipped = self.get_equipped_title(player)
            if equipped == op_title:
                self.set_equipped_title(player, None)

    def format_chat_message(self, player: Player, original_message: str) -> str:
        """根据佩戴头衔格式化聊天（含稀有度颜色）。返回形如 §f[头衔]§r名字: 消息。"""
        equipped = self.get_equipped_title(player)
        name = player.name
        if equipped:
            color = self.get_title_rarity_color(equipped)
            return color + "[" + equipped + "]" + "§r" + name + ": " + original_message
        return name + ": " + original_message
